"""Fresh synthetic controls for the narrow HDUT publication-manifest adapter.
No project model, scene, or formal PNG is used. Original test inputs stay intact.
"""
from pathlib import Path
import argparse,copy,hashlib,json,subprocess,sys

VIEWS=['front','rear','west','east','south','north','top','courtyard-gallery','courtyard-arcade']
def require(value,message):
    if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--tool',type=Path,required=True);ap.add_argument('--png',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();require(not a.out.exists(),'Fresh output required');a.out.mkdir(parents=True)
    tool=a.tool.resolve();core=tool.with_name('png_exact_compare.py');initial={str(p):sha(p) for p in [tool,core,a.png]};stl='1'*64;pixel=a.png.read_bytes();rows=[]
    sys.path.insert(0,str(tool.parent));from png_exact_compare import parse,SANITIZE_TEXT_KEYS
    manifest={'stl_sha256':stl,'views':{name:{'sha256':sha(a.png),'camera':[[1,2,3],[0,0,0],40],'projection':'PERSP' if name.startswith('courtyard-') else 'ORTHO','lens_mm':20 if name.startswith('courtyard-') else 50} for name in VIEWS}}
    cases=[('valid_exact_nine',True,None,None,None)]
    for name in VIEWS:
        cases.extend([
            ('missing_'+name,False,lambda d,n=name:d['views'].pop(n),'Manifest candidate/view set differs',None),
            ('projection_'+name,False,lambda d,n=name:d['views'][n].__setitem__('projection','ORTHO' if n.startswith('courtyard-') else 'PERSP'),'Manifest projection/lens differs from fixed nine-view policy',None),
            ('lens_'+name,False,lambda d,n=name:d['views'][n].__setitem__('lens_mm',26),'Manifest projection/lens differs from fixed nine-view policy',None)])
    cases.extend([
        ('extra_view',False,lambda d:d['views'].__setitem__('extra',copy.deepcopy(d['views']['front'])),'Manifest candidate/view set differs',None),
        ('missing_projection',False,lambda d:d['views']['courtyard-gallery'].pop('projection'),'Manifest projection/lens differs from fixed nine-view policy',None),
        ('missing_lens',False,lambda d:d['views']['courtyard-arcade'].pop('lens_mm'),'Manifest projection/lens differs from fixed nine-view policy',None),
        ('wrong_stl',False,lambda d:d.__setitem__('stl_sha256','2'*64),'Manifest candidate/view set differs',None),
        ('wrong_manifest_hash',False,None,'Manifest hash mismatch','0'*64),
        ('wrong_png_hash',False,lambda d:d['views']['front'].__setitem__('sha256','0'*64),'Original PNG differs from frozen hash',None)])
    for name,expected,mutate,needle,expected_manifest in cases:
        folder=a.out/name;folder.mkdir();source=folder/'input';source.mkdir();data=copy.deepcopy(manifest)
        if mutate:mutate(data)
        for view in VIEWS:(source/(view+'.png')).write_bytes(pixel)
        mf=source/'render-manifest.json';write(mf,data);inputs={p.name:sha(p) for p in source.iterdir()};output=folder/'output'
        command=[sys.executable,'-B',*(['-O'] if sys.flags.optimize else []),str(tool),'--manifest',str(mf),'--expected-manifest-sha256',expected_manifest or sha(mf),'--expected-stl-sha256',stl,'--out',str(output)]
        result=subprocess.run(command,capture_output=True,text=True);(folder/'stdout.txt').write_text(result.stdout);(folder/'stderr.txt').write_text(result.stderr);report=json.loads((output/'metadata-cleanup-binding.json').read_text())
        accepted=report.get('passed') is True;verified=accepted is expected and result.returncode==(0 if expected else 1) and (expected or needle in report.get('error',''))
        if expected:
            public=json.loads((output/'render-manifest.json').read_text());require(set(public['views'])==set(VIEWS),'Positive view set differs')
            for view in VIEWS:
                src=data['views'][view];dst=public['views'][view];before=parse(source/(view+'.png'));after=parse(output/(view+'.png'))
                require(all(src[k]==dst[k] for k in ['camera','projection','lens_mm']),'Camera fields changed')
                require(before['rgba_bytes']==after['rgba_bytes'] and before['idat_sha256']==after['idat_sha256'] and before['color_metadata']==after['color_metadata'],'PNG visual bytes changed')
                require(all(report['views'][view]['checks'].values()) and set(report['removal_whitelist'])==set(SANITIZE_TEXT_KEYS),'Metadata-only proof differs')
        require(all(sha(source/k)==v for k,v in inputs.items()),'Synthetic inputs changed')
        row={'case':name,'expected_accept':expected,'accepted':accepted,'returncode':result.returncode,'expected_rejection_reason':needle,'passed':verified,'input_manifest_sha256':sha(mf),'output_report_sha256':sha(output/'metadata-cleanup-binding.json'),'all_input_bytes_unchanged':True};rows.append(row);write(folder/'result.json',row);require(verified,'Batch control failed: '+name)
    require(all(sha(p)==h for p,h in initial.items()),'Input or tool changed')
    report={'passed':True,'case_count':len(rows),'optimization_level':sys.flags.optimize,'batch_source_sha256':sha(tool),'png_core_sha256':sha(core),'test_source_sha256':sha(__file__),'source_synthetic_png_sha256':sha(a.png),'no_project_input_used':True,'no_image_rendering':True,'all_input_bytes_unchanged':True,'cases':rows}
    write(a.out/'results.json',report);print(json.dumps({'passed':True,'case_count':len(rows),'optimization_level':sys.flags.optimize}))
if __name__=='__main__':main()
