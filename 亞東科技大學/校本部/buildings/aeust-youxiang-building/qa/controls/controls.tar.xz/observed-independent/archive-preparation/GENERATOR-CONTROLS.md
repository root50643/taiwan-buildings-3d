# Final-inventory generator synthetic controls

**Prepared only; not executed.** This supersedes the proposed-controls section
of `FINAL-INVENTORY-GENERATOR.md`. The generator itself remains the original
56,044 bytes with SHA256
`60633de97fbb0e39e565b44e94cc6f8174eb81405eca6ba246ff4fc11695d786`.

`test_generate_final_inventory.py` defines exactly **45 cases per mode**:

- 14 roster/identity/format gates: actual roster CLI, canonical overlapping
  frozen root, stage-specific metadata, missing and separately retained
  historical bytecode, source mutation, ancestor and leaf no-follow, nonblocking
  FIFO, link descriptor, duplicate JSON key, float overflow, helper hash and
  failed terminal gate.
- 8 exact Blend-exclusion cases: positive and seven unapproved, changed raw,
  result, generator, rejection or source-evidence negatives.
- 5 small final-selection cases: direct function and actual finalize CLI
  positives, unknown malformed HOLD, exact private-marker omission and missing
  Blend-profile HOLD.
- 6 profile-binding cases: positive two-mode synthetic metadata, missing mode,
  missing candidate, mutated diagnostic hash, wrong batch source and wrong
  original candidate identity.
- 12 duplicate-evidence cases: regular and strict-archive positives; unrelated
  passing report; six still-readable generator/index/verifier/builder/member/
  selection inputs excluded from the source selection; missing tracked binding;
  wrong member mapping; wrong generator-report hash.

The duplicate positives use the actual controlled v2 packager and original
archive tools on one tiny text payload. They retain the archive's exact
`ARCHIVE-SCOPE.json` from the verifier's in-memory records, so all-member
evidence is complete. Only these tiny synthetic archives are built.

The profile case uses the existing minimal SDNA fixture and the actual v2
independent parser. Its two-mode diagnostic metadata is deliberately synthetic:
this checks the generator's coverage and binding logic, not execution of the
independent batch decoder. No final model, geometry, Blender or model GO is
claimed. Both the helper-level checks and true CLI cases use `require`, not
optimizable assertions.

## Scheduled CLI

Use the parent's shared lock and single allowed CPU after the formal pipeline.
`P` is `Q/archive-preparation`. Both output directories must be fresh and inside
`P`, as required by the generator's output policy.

```sh
taskset -c "$CPU" python -B "$P/test_generate_final_inventory.py" \
  --out "$P/generator-controls-normal-v1"

taskset -c "$CPU" python -B -O "$P/test_generate_final_inventory.py" \
  --out "$P/generator-controls-optimized-v1"
```

The test pins the generator, v2 scanner and v2 fixture-helper source hashes. It
defaults to the frozen r2 public helper SHA
`75f1604d4f67e87906325c7394d39b96fad98e1c44ca59db862307b4a35b935a`.
An explicitly reviewed replacement uses both `--public-helper` and
`--public-helper-sha256`; this is a new controlled input, never an automatic
hash bypass. Original generator/helper/tool bytes are checked again at the end.

## Results and source accounting

Each case retains its original synthetic files and `control-result.json`.
Full exception text that can contain a local path is retained in
`negative-error.stderr.txt`; the result contains its hash and a relative name,
not the effective local path. CLI stdout/stderr are likewise retained. FIFO
testing records its typed descriptor and removes the live endpoint after the
bounded subprocess check; no FIFO payload exists to preserve.

`fixture-inventory.json` lists every regular fixture with exact bytes/SHA and
every symlink's target-descriptor hash. It intentionally excludes only itself
and the subsequently written `results.json`; the final full QA inventory must
account for those too. `results.json` records `passed`, `case_count: 45`, actual
`optimization_level`, exact generator/test/helper hashes, all original-source
unchanged status and `model_go: false`.

A successful synthetic suite proves only these specified generator branches.
The real final roster, profile batch, complete per-file disposition, archive
replay, original source accounting and assembly checks remain separate gates.
