"""Static metadata/identity joins only; never decode, scan, extract or run controls."""
import collections
import copy
import hashlib
import json
import os
from pathlib import Path
import stat

P = Path(__file__).resolve().parent
Q = P.parent
O = P / 'final-inventory-r1'
ROOTS = {'independent': Q, 'author': Q / 'final-v15-r1/frozen'}
READS = {}

def need(value, message):
    if not value:
        raise RuntimeError(message)

def raw(path):
    path = Path(path)
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.absolute().parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        leaf = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        try:
            before = os.fstat(leaf)
            need(stat.S_ISREG(before.st_mode), 'Nonregular static evidence')
            data = b''
            while True:
                block = os.read(leaf, 1024 * 1024)
                if not block:
                    break
                data += block
            after = os.fstat(leaf)
            fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
            need(all(getattr(before, f) == getattr(after, f) for f in fields), 'Evidence changed during read')
        finally:
            os.close(leaf)
    finally:
        os.close(fd)
    identity = (len(data), hashlib.sha256(data).hexdigest())
    need(path not in READS or READS[path] == identity, 'Evidence changed between reads')
    READS[path] = identity
    return data

def path_for(name):
    label, rel = name.split('/', 1)
    need(label in ROOTS and all(p not in ('', '.', '..') for p in rel.split('/')), 'Unsafe source name')
    return ROOTS[label] / rel

def ref(path):
    data = raw(path)
    path = Path(path)
    name = 'independent/' + path.relative_to(Q).as_posix()
    return {'source_relative_path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def read(path):
    return json.loads(raw(path))

def source_ref(name):
    row = snapshot[name]
    data = raw(path_for(name))
    need(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'Snapshot evidence identity differs: ' + name)
    return {k: row[k] for k in ('source_relative_path', 'bytes', 'sha256')}

def write_new(name, obj):
    data = (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    with (P / name).open('xb') as stream:
        stream.write(data)
    return {'source_relative_path': 'independent/archive-preparation/' + name,
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

inventory = read(O / 'private-original-payload-inventory-FINAL.json')
snapshot = {r['source_relative_path']: r for r in inventory['files']}
findings = read(O / 'private-inventory-findings-FINAL.json')
selection = read(O / 'controls-selection-FINAL.json')
selected = {r['source_relative_path']: r for r in selection['files']}
plan = read(P / 'final-selection-plan-r1.json')
seed = read(P / 'controls-selection-v1.json')['files']
required = set(plan['replay_required_sources']) | {r['source_relative_path'] for r in seed}
direct = {r['source_relative_path'] for r in read(Q / 'public-preparation/PUBLIC-DIRECT-PATH-CONTRACT.json')['files']}
tables = {
    'malformed': read(O / 'malformed-fixture-allowlist-FINAL.json')['files'],
    'negative_archive': read(O / 'negative-archive-allowlist-FINAL.json')['files']}
by_identity = collections.defaultdict(list)
for kind, rows in tables.items():
    for row in rows:
        by_identity[(row['bytes'], row['sha256'])].append((kind, row))
        required.add(row['source_relative_path'])
        required.update(row['proof'][key] for key in ('result_path', 'generator_path', 'local_result_path') if key in row['proof'])

expanded = {'malformed': [], 'negative_archive': []}
classified = []
private_proposals = []

def result_binding(suite, case, test_source, case_key='case'):
    result_name = 'independent/' + suite + '/results.json'
    result_ref = source_ref(result_name)
    result = read(path_for(result_name))
    source = source_ref(test_source)
    need(result.get('passed') is True and result.get('test_source_sha256', result.get('source_sha256')) == source['sha256'], 'Control source/result binding differs')
    matches = [(i, c) for i, c in enumerate(result['cases']) if c.get(case_key) == case]
    need(len(matches) == 1 and matches[0][1].get('passed') is True, 'Case proof absent or failed')
    index, case_row = matches[0]
    return {'result': result_ref, 'generator_source': source, 'case_index': index,
            'case_key': case_key, 'case': copy.deepcopy(case_row)}

private_cases = {
    'absolute-path.zip': 'absolute_path_rejected',
    'archive-before-swap.zip': 'archive_decode_uses_identical_hash_verified_bytes',
    'archive-replacement.zip': 'archive_decode_uses_identical_hash_verified_bytes',
    'bad-crc.zip': 'actual_zip_crc_failure_rejected',
    'changed-link.zip': 'changed_link_descriptor_rejected',
    'duplicate-member.zip': 'duplicate_zip_member_rejected',
    'duplicate-path.zip': 'duplicate_restore_path_rejected',
    'extra-member.zip': 'extra_archive_member_rejected',
    'immutable-archive-restore/bad.zip': 'archive_decode_uses_identical_hash_verified_bytes',
    'missing-dir.zip': 'missing_parent_directory_rejected',
    'original/bad.zip': 'opaque_private_payloads_empty_directory_and_owner_only_restore',
    'original/checkpoint/aeust-independent-final-private-v15.zip': 'exact_complete_checkpoint_and_restore',
    'original/checkpoint/restored/bad.zip': 'opaque_private_payloads_empty_directory_and_owner_only_restore',
    'orphan-dir.zip': 'orphan_empty_directory_rejected',
    'parent-path.zip': 'parent_path_escape_rejected',
    'restore-directory-swap/bad.zip': 'restore_directory_symlink_swap_rejected',
    'restore-readback-swap/bad.zip': 'restore_readback_symlink_swap_rejected',
    'restore-root-swap/bad.zip': 'restore_root_replacement_rejected_without_following',
    'wrong-size.zip': 'wrong_reference_size_rejected'}

for hold in findings['holds']:
    if 'source_relative_path' not in hold:
        classified.append({'classification': 'exact_historical_metadata_gap', 'hold': hold})
        continue
    name = hold['source_relative_path']
    row = source_ref(name)
    item = {**row, 'scan_rejection': hold['error'],
            'required_archive_dependency': name in required, 'mandatory_direct': name in direct}
    matches = [(kind, original) for kind, original in by_identity[(row['bytes'], row['sha256'])]
               if original['proof']['proof_kind'] != 'archive_verifier_expected_failure'
               or Path(name).parent.name == original['proof']['expected_rejection_case']]
    if matches:
        chosen = {}
        for kind, original in sorted(matches, key=lambda pair: pair[1]['source_relative_path']):
            chosen.setdefault(kind, original)
        proofs = []
        for kind, original in chosen.items():
            clone = copy.deepcopy(original)
            clone['source_relative_path'] = name
            clone.pop('archive_path', None)
            clone['same_original_payload_binding'] = source_ref(original['source_relative_path'])
            bindings = []
            for key in ('result_path', 'generator_path', 'local_result_path'):
                if key not in clone['proof']:
                    continue
                dependency = clone['proof'][key]
                binding = source_ref(dependency)
                need(binding['sha256'] == clone['proof'][key.replace('_path', '_sha256')], 'Original proof bytes differ')
                need(dependency in selected and all(selected[dependency][k] == binding[k] for k in ('bytes', 'sha256')), 'Original proof is not selected')
                bindings.append(binding)
            expanded[kind].append(clone)
            proofs.append({'kind': kind, 'original_payload': clone['same_original_payload_binding'],
                           'original_proof': clone['proof'], 'all_proof_sources_currently_selected': True,
                           'dependencies': bindings})
        item.update(classification='exact_same_payload_and_original_failure_proof', proposals=proofs)
    elif '/package-controls-' in name and '/package/controls.tar.xz' in name:
        item['classification'] = 'v2_reproduction_archive_requires_complete_scope_member_proof'
    elif '/handoff-controls-' in name:
        item['classification'] = 'large_science_identity_copy_requires_reviewed_dependency_and_duplicate_proof'
    elif '/public-bundle-controls-' in name:
        item['classification'] = 'public_suite_exact_fixture_case_binding_review_pending'
    elif '/generator-controls-' in name:
        suite = name.removeprefix('independent/').split('/unknown_malformed_payload_keeps_hold/', 1)[0]
        proof = result_binding(suite, 'unknown_malformed_payload_keeps_hold',
                               'independent/archive-preparation/test_generate_final_inventory.py', 'name')
        details = proof['case']['details']
        need(details['passed'] is False and details['hold_count'] == 1 and details['private_omission_count'] == 0
             and details['expected_hold'] == 'Unapproved malformed compressed payload', 'Unknown-malformed HOLD proof differs')
        item.update(classification='generator_intentional_unknown_stream_negative', control_proof=proof)
        private_proposals.append({**row, 'approved': False, 'category': 'private_control_fixture',
            'reason': 'Original intentional unknown compressed-stream fixture retained privately; its exact generator control proves the public inventory remains HOLD with no automatic private omission. No public malformed-stream allowance is inferred.',
            'control_proof': proof})
    elif '/private-checkpoint-controls-' in name:
        suite, relative = name.removeprefix('independent/').split('/', 1)
        need(relative in private_cases, 'Unclassified private-checkpoint path')
        proof = result_binding(suite, private_cases[relative],
                               'independent/independent-tools/test_private_final_checkpoint.py', 'name')
        item.update(classification='private_checkpoint_opaque_or_rejection_fixture', control_proof=proof)
        private_proposals.append({**row, 'approved': False, 'category': 'private_control_fixture',
            'reason': 'Exact synthetic private-checkpoint fixture retained privately with its generating case and original result. The backup suite intentionally stores opaque malformed ZIP data or mutated restore metadata; a valid outer checkpoint is not misrepresented as a malformed outer archive or public scientific evidence.',
            'control_proof': proof})
    elif '/package-controls-' in name:
        suite, case, remaining = name.removeprefix('independent/').split('/', 2)
        need(remaining.startswith('input/'), 'Unexpected new packager fixture path')
        proof = result_binding(suite, case, 'independent/archive-preparation/test_package_controls_v2.py')
        need(proof['case']['expected_accept'] is False and proof['case']['returncode'] == 1,
             'New packager fixture is not a verified rejection case')
        selection_name = 'independent/' + suite + '/' + case + '/selection.json'
        proof['case_selection'] = source_ref(selection_name)
        case_selection = read(path_for(selection_name))
        relative = remaining.removeprefix('input/')
        input_rows = [r for r in case_selection['files'] if r['source_relative_path'].split('/', 1)[1] == relative
                      and r['bytes'] == row['bytes'] and r['sha256'] == row['sha256']]
        need(len(input_rows) == 1, 'New fixture has no exact case selection input binding')
        proof['case_input_row'] = input_rows[0]
        item.update(classification='new_packager_exact_rejection_fixture', control_proof=proof)
        private_proposals.append({**row, 'approved': False, 'category': 'private_control_fixture',
            'reason': 'Original exact synthetic rejection fixture retained privately with its input selection, generating source and successful expected-failure case. The rejected byte stream or nested-container structure receives no public malformed allowance and is never extracted.',
            'control_proof': proof})
    else:
        raise RuntimeError('Unclassified HOLD: ' + name)
    classified.append(item)

for path in list(READS):
    raw(path)
common = {'schema': 'aeust-static-exact-hold-evidence-v1', 'approved_for_final_plan': False,
          'scanner_executed': False, 'archive_decoded_or_extracted': False, 'model_go': False,
          'source_findings': ref(O / 'private-inventory-findings-FINAL.json'),
          'scope': 'Exact existing-byte and original proof joins only. Parent review and a fresh controlled finalize are required; no new fixture is waived by filename, scope or hash alone.'}
outputs = {}
for kind, filename in [('malformed', 'expanded-malformed-fixture-candidates-r1.json'),
                       ('negative_archive', 'expanded-negative-archive-candidates-r1.json')]:
    outputs[kind] = write_new(filename, {**common, 'files': expanded[kind]})
outputs['private_proposals'] = write_new('new-private-control-fixture-proposals-r1.json', {**common, 'files': private_proposals})
outputs['classification'] = write_new('finalize-hold-classification-r1.json', {**common,
    'hold_count': len(classified), 'classification_counts': dict(collections.Counter(r['classification'] for r in classified)),
    'files': classified, 'derived_proposal_inputs': outputs,
    'all_read_original_bytes_unchanged': True})
print(json.dumps(outputs, indent=2))
