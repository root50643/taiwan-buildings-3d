# synthetic helper verification/check_intersection_controls.py
