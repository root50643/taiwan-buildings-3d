"""Packaging unit tests: synthetic subprocess emits current-schema copies of
previously computed genuine positive-fixture results; no geometry is re-claimed.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import argparse,gzip,lzma,json,shutil,sys,os
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,os.environ.get('BWBC_VERIFICATION_DIR',str(ROOT.parent/'final-v17/frozen/verification')))
import run_qa
from qa_common import sha256,checker_inventory,write_json
NAMES={'raw':'raw-mesh-check.json','sections':'section-check.json','dense':'dense-check.json','controls':'control-check.json'}
DIRS={'raw':'check_raw_mesh','sections':'check_sections','dense':'check_dense_surface'}
controls=ROOT/'generic-controls';positive=controls/'python_B'/'normal_box';fixture=positive/'fixture.stl'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(exist_ok=False)
 rows=[]
 def trial(name,expected=False,mutate=None,stale=False,rc=0,raise_error=None,no_output=False):
  out=a.out/name;out.mkdir()
  def emit(cmd,**kwargs):
   if raise_error:raise raise_error
   dest=Path(cmd[cmd.index('--out')+1]);gate=dest.name
   if no_output:return SimpleNamespace(returncode=rc,stdout='',stderr='')
   if gate in DIRS:shutil.copytree(positive/DIRS[gate],dest)
   else:dest.mkdir();shutil.copy2(controls/'control-check.json',dest/NAMES[gate])
   p=dest/NAMES[gate];d=json.loads(p.read_text());d['checker_sources_sha256']=checker_inventory();write_json(p,d)
   if mutate:mutate(gate,p,d)
   return SimpleNamespace(returncode=rc,stdout='',stderr='')
  if stale:(out/'qa-summary.json').write_text('{"passed": true}')
  with patch.object(run_qa.subprocess,'run',side_effect=emit):
   try:report=run_qa.inspect(fixture,out,None);accepted=report['passed'];error=None
   except Exception as e:report={};accepted=False;error=f'{type(e).__name__}: {e}'
  row={'case':name,'expected_accept':expected,'accepted':accepted,'expectation_verified':accepted==expected,'checks':report.get('checks'),'error':error};rows.append(row);write_json(out/'unit-test-result.json',row)
 def change(target,func):
  def mutate(gate,p,d):
   if gate==target:func(d);write_json(p,d)
  return mutate
 trial('positive_current_schema',True)
 trial('reject_stale_output',stale=True)
 trial('reject_zero_exit_missing_reports',no_output=True)
 for gate,key in [('raw','all_original_faces_nondegenerate'),('sections','all_original_sections_valid_without_repair'),('dense','all_original_ray_intervals_and_controls_valid'),('controls','both_python_modes_tested')]:
  trial('reject_missing_'+gate+'_check',mutate=change(gate,lambda d,k=key:d['checks'].pop(k)))
 trial('reject_unknown_extra_check',mutate=change('raw',lambda d:d['checks'].update(invented=True)))
 trial('reject_missing_strict',mutate=change('raw',lambda d:d.pop('strict_passed')))
 trial('reject_empty_checks',mutate=change('raw',lambda d:d.update(checks={})))
 trial('reject_false_check',mutate=change('raw',lambda d:d['checks'].update(all_original_faces_nondegenerate=False)))
 trial('reject_wrong_stl_hash',mutate=change('raw',lambda d:d.update(stl_sha256='0'*64)))
 trial('reject_wrong_checker_inventory',mutate=change('raw',lambda d:d.update(checker_sources_sha256={})))
 trial('reject_wrong_compressed_hash',mutate=change('dense',lambda d:d.update(csv_compressed_sha256='0'*64)))
 trial('reject_wrong_decoded_hash',mutate=change('dense',lambda d:d.update(uncompressed_csv_sha256='0'*64)))
 trial('reject_missing_compression',mutate=change('dense',lambda d:d.pop('csv_compression')))
 trial('reject_wrong_container',mutate=change('dense',lambda d:d.update(csv_compression='gzip')))
 def corrupt(gate,p,d):
  if gate=='dense':
   path=p.parent/d['csv_file'];b=bytearray(path.read_bytes());b[len(b)//2]^=1;path.write_bytes(b);d['csv_compressed_sha256']=sha256(path);write_json(p,d)
 trial('reject_corrupt_xz_even_with_matching_container_hash',mutate=corrupt)
 def gz(gate,p,d):
  if gate=='dense':
   old=p.parent/d['csv_file'];data=lzma.decompress(old.read_bytes());new=p.parent/'dense-original.csv.gz';new.write_bytes(gzip.compress(data,mtime=0));d.update(csv_file=new.name,csv_compression='gzip',csv_compressed_sha256=sha256(new));write_json(p,d)
 trial('positive_lossless_gzip_container',True,mutate=gz)
 trial('reject_nonzero_exit',rc=2)
 trial('reject_subprocess_exception',raise_error=RuntimeError('Injected child launch error'))
 result={'passed':all(r['expectation_verified'] for r in rows),'optimization_level':sys.flags.optimize,'case_count':len(rows),'checker_sources_sha256':checker_inventory(),'cases':rows}
 write_json(a.out/'unit-test-summary.json',result);print(json.dumps({'passed':result['passed'],'cases':len(rows)}));return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
