# synthetic helper independent-tools/exact_ray_diagnosis.py
