"""Task-scoped self-contained deduplicated ZIP of completed independent evidence.
No source is changed and no symlink is followed or restored.
"""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,zipfile
Q=Path(__file__).resolve().parents[1]
OUT=Q/'aeust-independent-controls-private-v1.zip'
INDEX=Q/'CONTROLS-PRIVATE-RESTORE-INDEX-v1.json'
REPORT=Q/'CHECKPOINT-controls-private-v1.json'
EXCLUDED={OUT.name,INDEX.name,REPORT.name}
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return (json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def safe(name):
 p=PurePosixPath(name);return bool(name) and not p.is_absolute() and p.as_posix()==name and all(x not in ('','.','..') for x in name.split('/')) and '\\' not in name and '\0' not in name
for p in [OUT,INDEX,REPORT]:require(not p.exists() and not p.is_symlink(),'Fresh private checkpoint required')
require(json.loads((Q/'TOOL-CONTROLS-SUMMARY-v1.json').read_text())['passed'] is True,'Fresh tool controls must pass')
files=[];symlinks=[];blobs={};omissions=[]
for p in sorted(Q.rglob('*')):
 rel=p.relative_to(Q).as_posix();require(safe(rel),'Unexpected source path')
 if rel in EXCLUDED:continue
 if p.is_symlink():
  target=os.readlink(p);symlinks.append({'path':rel,'target_descriptor':target,'target_descriptor_sha256':sha(target.encode()),'policy':'Negative extraction-control artifact. Preserve this descriptor only; do not follow or automatically create the link.'});continue
 if not p.is_file():continue
 if '__pycache__' in p.parts or p.suffix=='.pyc' or p.name.endswith('.lock'):
  omissions.append({'path':rel,'reason':'Transient bytecode/cache/lock; not source science.'});continue
 b=p.read_bytes();h=sha(b);member='blobs/'+h;files.append({'path':rel,'bytes':len(b),'sha256':h,'member':member,'mode':stat.S_IMODE(p.stat().st_mode)});blobs.setdefault(h,p)
index={'complete':True,'format':'aeust-independent-controls-private-deduplicated-zip-v1','scope':'Self-contained exact snapshot of all completed independent-task regular files, with equal-content files stored once. Each regular path is reconstructed only from its referenced blob after verifying bytes/SHA. Every source path is relative to the independent QA root. No negative-control symlink is dereferenced or automatically restored. The index, subsequent verification report and this ZIP are excluded to avoid self-reference.','regular_file_count':len(files),'regular_file_bytes':sum(r['bytes'] for r in files),'unique_blob_count':len(blobs),'symlink_descriptor_count':len(symlinks),'files':files,'symlink_descriptors':symlinks,'transient_omissions':omissions,'self_reference_exclusions':sorted(EXCLUDED),'restoration':'Use a fresh user-owned destination with no symlink ancestors; reject absolute, backslash and dot/parent path components. Verify the ZIP hash from the handoff first. Read only listed blobs, verify each blob size/SHA, then write regular files exclusively to their indexed relative paths. Existing destinations must be rejected. Never blindly extract indexed path names or recreate negative-control symlinks.'}
ib=encoded(index)
def info(name):
 z=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));z.compress_type=zipfile.ZIP_DEFLATED;z.create_system=3;z.external_attr=(stat.S_IFREG|0o644)<<16;return z
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
 z.writestr(info('RESTORE-INDEX.json'),ib)
 for h,p in sorted(blobs.items()):
  b=p.read_bytes();require(sha(b)==h,'Input changed during backup');z.writestr(info('blobs/'+h),b)
with zipfile.ZipFile(OUT) as z:
 require(z.testzip() is None,'ZIP CRC failure');require(set(z.namelist())=={'RESTORE-INDEX.json'}|{'blobs/'+h for h in blobs} and len(z.namelist())==len(blobs)+1,'Unexpected ZIP member set');require(z.read('RESTORE-INDEX.json')==ib,'Index readback differs')
 cache={}
 for h in blobs:
  b=z.read('blobs/'+h);require(sha(b)==h,'Blob readback differs');cache[h]=len(b)
 for row in files:
  require(cache[row['sha256']]==row['bytes'],'Restore reference size differs');p=Q/row['path'];require(not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'],'Snapshot source changed')
INDEX.write_bytes(ib)
report={'passed':True,'zip_file':OUT.name,'zip_bytes':OUT.stat().st_size,'zip_sha256':sha(OUT.read_bytes()),'restore_index_sha256':sha(ib),'regular_file_count':len(files),'regular_file_bytes':index['regular_file_bytes'],'unique_blob_count':len(blobs),'zip_members':len(blobs)+1,'symlink_descriptor_count':len(symlinks),'all_zip_crc_verified':True,'all_blob_sha256_verified':True,'all_restore_references_resolve_exactly':True,'all_sources_unchanged_after_readback':True,'scope':'Private backup only. This is not a public allowlist; use FINAL-PUBLIC-COPYLIST.json for publication.'}
REPORT.write_bytes(encoded(report));print(json.dumps(report))
