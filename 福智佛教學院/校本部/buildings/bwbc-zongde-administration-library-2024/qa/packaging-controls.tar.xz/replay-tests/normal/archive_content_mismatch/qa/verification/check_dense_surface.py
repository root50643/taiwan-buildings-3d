# synthetic helper verification/check_dense_surface.py
