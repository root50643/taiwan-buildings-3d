"""A narrowly bound historical metadata acknowledgment, never a model verdict.

No import-time I/O. The production CLI accepts only a separately reviewed,
SHA-bound plan after the original frozen generator leaves exactly one HOLD.
It does not modify original evidence, execute scanners, or restore missing data.
"""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

sys.dont_write_bytecode = True
GAP = {'source_relative_path': 'independent/WORK-STATE.json', 'bytes': 3814,
       'sha256': '6e3f0b0e1e31a2e0385ecf3b66bad84158d4d1afaa0a231e60096740f8f17faf'}
HISTORICAL_REASON = 'Prior original payload versions not found in current preserved sources, including logs and bytecode fixtures'
GENERATOR_SHA = '60633de97fbb0e39e565b44e94cc6f8174eb81405eca6ba246ff4fc11695d786'
SCANNER_SHA = '1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c'
HELPER_SHA = '75f1604d4f67e87906325c7394d39b96fad98e1c44ca59db862307b4a35b935a'
BASELINE_SHA = '80c942e0c36610cbfc02bb38b8d2b557164e8fc33d2e550160c9517afcc3f636'
ANCHORS = {
    'science': ('author/qa/V15-SCIENTIFIC-HANDOFF-FREEZE.json', 'a46bf5d5eba7ba570dd0bd4adb832663f43146858751118d619b18f2ceab6224'),
    'runner': ('independent/V15-RUNNER-FREEZE-ADAPTER.json', '11794b224ea898237e21a54b387956ba2cfbab26c8161e2da1be467f0474d368'),
    'tooling': ('independent/FINAL-INDEPENDENT-TOOLING-FREEZE.json', '68c9fa4e5a0f9fb555b4b48d6ca37545711a2eac467d56e03f8ecaeaf29c05fa'),
    'public_base': ('independent/public-preparation/PUBLIC-DIRECT-PATH-CONTRACT.json', '508bf1f9ae233f221952e45f6e550e44f881849125210a4e8e82ce7ea8a7235d')}
ORIGINAL_OUTPUTS = {
    'private-original-payload-inventory-FINAL.json', 'controls-selection-FINAL.json',
    'private-omissions-FINAL.json', 'private-inventory-findings-FINAL.json',
    'private-duplicate-candidates-FINAL.json', 'malformed-fixture-allowlist-FINAL.json',
    'negative-archive-allowlist-FINAL.json', 'privacy-allowlist-FINAL.json'}
DERIVED = {'inventory': 'private-original-payload-inventory-GAP-ACK.json',
           'selection': 'controls-selection-GAP-ACK.json',
           'omissions': 'private-omissions-GAP-ACK.json'}
RESULT_NAME = 'metadata-gap-acknowledgment-result.json'
SET_NAMES = {'science', 'runner', 'tooling', 'public_base', 'public_active',
             'seed', 'replay', 'malformed_proofs', 'negative_proofs', 'other_proofs'}
DISPOSITIONS = {'preserve_original_bytes', 'public_direct_identity', 'private_original_retained'}
CATEGORIES = {'private_execution_log', 'raw_png_private_metadata', 'historical_or_failed_evidence',
              'private_path_report', 'duplicate_reproduction_or_scratch', 'private_source_reference',
              'outside_independent_publication_scope', 'private_control_fixture'}
CONTROL_CASE_NAMES = (
    'exact_gap_preserves_original_evidence', 'same_path_current_bytes_remain_separately_retained',
    'wrong_gap_path_rejected', 'wrong_gap_size_rejected', 'wrong_gap_hash_rejected',
    'second_historical_missing_rejected', 'science_dependency_rejected',
    'runner_dependency_rejected', 'public_dependency_rejected', 'replay_dependency_rejected',
    'malformed_and_negative_proof_dependency_rejected', 'extra_hold_rejected',
    'current_unresolved_rejected', 'mutated_exact_binding_rejected',
    'source_changed_or_replaced_rejected', 'unsafe_read_and_strict_metadata_rejected')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def parse(data):
    def pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'Duplicate JSON key')
            value[key] = item
        return value
    def number(value):
        result = float(value)
        require(math.isfinite(result), 'Nonfinite JSON value')
        return result
    def constant(value):
        raise ValueError('Nonfinite JSON value')
    return json.loads(data, object_pairs_hook=pairs, parse_float=number, parse_constant=constant)


def safe(name):
    require(type(name) is str and name and '\\' not in name, 'Unsafe logical path')
    require(not PurePosixPath(name).is_absolute() and not re.match(r'^[A-Za-z]:', name)
            and PurePosixPath(name).as_posix() == name
            and all(x not in ('', '.', '..') for x in name.split('/'))
            and all(ord(c) >= 32 and ord(c) != 127 for c in name), 'Unsafe logical path')
    return name


def identity(row):
    require(type(row) is dict and type(row.get('bytes')) is int and row['bytes'] >= 0
            and type(row.get('sha256')) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']),
            'Invalid exact identity')
    return row['bytes'], row['sha256']


def ref(row):
    identity(row)
    return {'source_relative_path': safe(row['source_relative_path']),
            'bytes': row['bytes'], 'sha256': row['sha256']}


def same(row, other):
    return identity(row) == identity(other)


def stat_id(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def directory_fd(path):
    path = Path(os.path.abspath(path))
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_at(parent, leaf, keep=True):
    fd = os.open(leaf, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode), 'Unsafe nonregular source')
        chunks, total, h = [], 0, hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            h.update(chunk)
            if keep:
                chunks.append(chunk)
        after = os.fstat(fd)
        named = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
        require(stat_id(before) == stat_id(after) == stat_id(named) and total == before.st_size,
                'Source changed during read')
        return (b''.join(chunks) if keep else None,
                {'bytes': total, 'sha256': h.hexdigest()}, stat_id(after))
    finally:
        os.close(fd)


def read_path(path, keep=True):
    path = Path(os.path.abspath(path))
    fd = directory_fd(path.parent)
    try:
        return read_at(fd, path.name, keep)
    finally:
        os.close(fd)


class Sources:
    def __init__(self, roots, aliases):
        self.roots = {k: Path(os.path.abspath(v)) for k, v in roots.items()}
        self.aliases = dict(aliases)
        self.observed = {}
        self.cache = {}
        require(set(self.roots) == {'author', 'independent'}, 'Exactly author and independent roots required')
        for label, path in self.roots.items():
            safe(label)
            fd = directory_fd(path)
            os.close(fd)
        nested = self.roots['author'].relative_to(self.roots['independent']).as_posix()
        require(self.aliases.get('independent/' + nested) == 'author', 'Canonical author root alias missing')
        for key, value in self.aliases.items():
            safe(key); safe(value)
            require(not any(value == other or value.startswith(other + '/') for other in self.aliases),
                    'Recursive aliases forbidden')

    def normalize(self, name):
        safe(name)
        choices = [k for k in self.aliases if name == k or name.startswith(k + '/')]
        if choices:
            key = max(choices, key=len)
            name = self.aliases[key] + name[len(key):]
        return safe(name)

    def path(self, name):
        name = self.normalize(name)
        root, slash, rest = name.partition('/')
        require(root in self.roots and slash, 'Unknown source root')
        return self.roots[root] / rest

    def data(self, row):
        row = ref(row)
        name = self.normalize(row['source_relative_path'])
        if name in self.cache:
            data, actual, sid = self.cache[name]
        else:
            data, actual, sid = read_path(self.path(name))
            self.cache[name] = (data, actual, sid)
        require(same(row, actual), 'Mutated exact binding')
        self.observed[name] = (actual, sid)
        return data

    def document(self, row):
        value = parse(self.data(row))
        require(type(value) is dict, 'JSON object required')
        return value

    def bind(self, row):
        row = ref(row)
        name = self.normalize(row['source_relative_path'])
        if name in self.observed:
            actual, sid = self.observed[name]
        else:
            _, actual, sid = read_path(self.path(name), keep=False)
        require(same(row, actual), 'Mutated exact binding')
        self.observed[name] = (actual, sid)

    def snapshot(self, scopes, excluded):
        rows, stats = {}, {}
        def visit(fd, logical):
            for leaf in sorted(os.listdir(fd)):
                name = self.normalize(logical + '/' + leaf)
                if name in excluded:
                    continue
                before = os.stat(leaf, dir_fd=fd, follow_symlinks=False)
                if stat.S_ISDIR(before.st_mode):
                    child = os.open(leaf, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                    try:
                        require(stat_id(before) == stat_id(os.fstat(child)), 'Directory changed')
                        visit(child, name)
                        require(stat_id(before) == stat_id(os.fstat(child))
                                == stat_id(os.stat(leaf, dir_fd=fd, follow_symlinks=False)), 'Directory changed')
                    finally:
                        os.close(child)
                elif stat.S_ISREG(before.st_mode):
                    _, bound, sid = read_at(fd, leaf, keep=False)
                    require(stat_id(before) == sid, 'Source changed before read')
                    value = {'source_relative_path': name, 'type': 'regular', **bound}
                    require(name not in rows or rows[name] == value, 'Conflicting scope overlap')
                    rows[name], stats[name] = value, sid
                elif stat.S_ISLNK(before.st_mode):
                    target = os.readlink(leaf, dir_fd=fd)
                    after = os.stat(leaf, dir_fd=fd, follow_symlinks=False)
                    require(stat_id(before) == stat_id(after), 'Link changed')
                    value = {'source_relative_path': name, 'type': 'symlink',
                             'target_descriptor_sha256': digest(os.fsencode(target))}
                    require(name not in rows or rows[name] == value, 'Conflicting link overlap')
                    rows[name], stats[name] = value, stat_id(after)
                else:
                    raise ValueError('Unsafe special source in snapshot')
        require(scopes == ['independent', 'author'], 'Complete two-root inventory required')
        for scope in scopes:
            fd = directory_fd(self.roots[scope])
            try:
                visit(fd, scope)
            finally:
                os.close(fd)
        return rows, stats

    def unchanged(self):
        for name, (bound, sid) in self.observed.items():
            _, current, current_sid = read_path(self.path(name), keep=False)
            require(same(bound, current) and sid == current_sid, 'Source changed after binding')


def indexed(rows):
    require(type(rows) is list, 'File list required')
    result = {}
    for row in rows:
        name = safe(row['source_relative_path'])
        require(name not in result, 'Duplicate source path')
        result[name] = row
    return result


def no_gap_dependencies(required_sets):
    require(set(required_sets) == SET_NAMES, 'Incomplete required-set families')
    for family, rows in required_sets.items():
        require(type(rows) is list and rows, 'Empty required-set family: ' + family)
        for row in rows:
            name = safe(row['source_relative_path'])
            require(name != GAP['source_relative_path'], 'Historical path is a required dependency: ' + family)
            require(identity(row) != identity(GAP), 'Historical identity is a required dependency: ' + family)


def validate_only_gap(result, inventory, selection, omissions, findings, required_sets):
    """Pure acceptance gate, also exercised by the explicitly helper-level suite."""
    require(result.get('passed') is False and result.get('model_go') is False
            and type(result.get('hold_count')) is int and result['hold_count'] == 1,
            'Original result must have exactly one remaining HOLD')
    require(result.get('all_source_bytes_unchanged') is True
            and result.get('scanner_source_sha256') == SCANNER_SHA
            and result.get('public_scanner_helper_sha256') == HELPER_SHA,
            'Original unchanged/scanner binding differs')
    require(findings.get('holds') == [{'reason': HISTORICAL_REASON, 'files': [GAP]}],
            'Only the exact historical missing HOLD may remain')
    require(inventory.get('historical_nonroutine_versions_missing') == [GAP], 'Missing descriptors differ')
    history = inventory.get('historical_original_version_accounting')
    require(type(history) is list and history, 'Complete historical accounting required')
    missing = [row for row in history if row.get('status') == 'historical_descriptor_only'
               or ('retained_at' in row and row['retained_at'] is None)]
    require(len(missing) == 1 and ref(missing[0]) == GAP
            and missing[0].get('status') == 'historical_descriptor_only'
            and 'retained_at' in missing[0] and missing[0]['retained_at'] is None,
            'Historical descriptor-only row differs')
    require(inventory.get('all_snapshot_paths_accounted') is True
            and inventory.get('source_changes_during_static_read') == [], 'Snapshot closure not complete')
    require(selection.get('passed') is False and selection.get('model_go') is False
            and omissions.get('ready_for_final_assembly') is False, 'Original metadata readiness differs')
    current = indexed(inventory['files'])
    selected = indexed(selection['files'])
    omitted = indexed(omissions['files'])
    require(not (set(selected) & set(omitted)), 'Selected/private overlap')
    regular = {n: r for n, r in current.items() if r.get('type') == 'regular'}
    require(type(inventory.get('regular_file_count')) is int
            and inventory['regular_file_count'] == len(regular)
            and result.get('source_inventory_regular_count') == len(regular), 'Current count differs')
    require(result.get('selected_count') == len(selected)
            and result.get('private_omission_count') == len(omitted), 'Disposition counts differ')
    for name, row in current.items():
        if row.get('type') == 'symlink':
            require(row.get('disposition') == 'omit_nonregular_descriptor', 'Link disposition differs')
            continue
        require(row.get('type') == 'regular' and row.get('disposition') in DISPOSITIONS,
                'Current source unresolved')
        identity(row)
        require(identity(row) != identity(GAP), 'Acknowledged original bytes are now retained')
        if row['disposition'] == 'preserve_original_bytes':
            require(name in selected and same(row, selected[name])
                    and row.get('archive_path') == selected[name].get('archive_path')
                    and selected[name].get('transformation') == 'identity', 'Selected disposition differs')
        elif row['disposition'] == 'private_original_retained':
            require(name in omitted and same(row, omitted[name])
                    and row.get('category') == omitted[name].get('category')
                    and row.get('reason') == omitted[name].get('reason')
                    and row.get('category') in CATEGORIES, 'Private disposition differs')
        else:
            require(type(row.get('public_relative_path')) is str, 'Direct mapping absent')
    for name, row in omitted.items():
        require(name in regular and same(row, regular[name])
                and regular[name]['disposition'] == 'private_original_retained', 'Unaccounted omission')
    for name, row in selected.items():
        identity(row)
        require(row.get('transformation') == 'identity', 'Nonidentity selection')
        if name in regular:
            require(same(row, regular[name]) and regular[name]['disposition'] == 'preserve_original_bytes',
                    'Unaccounted selection')
    no_gap_dependencies(required_sets)
    return {'all_historical_retained': False, 'gap_acknowledged': True, 'model_go': False,
            'acknowledged_gap': copy.deepcopy(GAP), 'original_hold_count': 1, 'original_passed': False,
            'current_regular_dispositions_complete': True,
            'science_and_required_dependencies_exclude_gap': True}


def evaluate_assertions(doc, assertions):
    require(type(assertions) is list and assertions, 'Empty terminal assertions')
    for assertion in assertions:
        pointer = assertion['pointer']
        require(type(pointer) is str and pointer.startswith('/'), 'Invalid JSON pointer')
        value = doc
        for part in pointer[1:].split('/'):
            part = part.replace('~1', '/').replace('~0', '~')
            value = value[int(part)] if type(value) is list else value[part]
        expected = assertion['equals']
        require(type(value) is type(expected) and value == expected, 'Terminal assertion differs')


def build_required_sets(sources, plan, original_plan, inventory, originals):
    current = indexed(inventory['files'])
    sets = {name: [] for name in SET_NAMES}
    evidence = []
    def add(family, row):
        row = ref(row)
        row['source_relative_path'] = sources.normalize(row['source_relative_path'])
        name = row['source_relative_path']
        require(name in current and current[name]['type'] == 'regular' and same(row, current[name]),
                'Required identity not in current inventory')
        sources.bind(row)
        sets[family].append(row)
    def by_name(family, name, expected_sha=None):
        name = sources.normalize(name)
        require(name != GAP['source_relative_path'], 'Historical path is required')
        require(name in current and current[name]['type'] == 'regular', 'Required dependency absent')
        if expected_sha is not None:
            require(current[name]['sha256'] == expected_sha, 'Proof dependency SHA differs')
        add(family, current[name])
    anchors = plan['frozen_sets']
    require(set(anchors) == set(ANCHORS), 'Frozen-set anchors differ')
    docs = {}
    for family, (path, expected_sha) in ANCHORS.items():
        anchor = ref(anchors[family])
        require(anchor['source_relative_path'] == path and anchor['sha256'] == expected_sha,
                'Frozen-set anchor identity differs')
        docs[family] = sources.document(anchor)
        evidence.append(anchor)
    science = docs['science']['files']
    require(type(science) is dict and len(science) == 3690
            and docs['science'].get('file_count') == 3690, 'Science set count differs')
    for name, row in science.items():
        add('science', {'source_relative_path': 'author/' + safe(name), **row})
    runner = docs['runner']['files']
    require(type(runner) is list and len(runner) == 3691, 'Runner set count differs')
    for row in runner:
        add('runner', {'source_relative_path': 'author/' + safe(row['path']),
                       'bytes': row['bytes'], 'sha256': row['sha256']})
    tooling = docs['tooling']['files']
    require(type(tooling) is dict and tooling, 'Tooling set absent')
    for name, row in tooling.items():
        add('tooling', {'source_relative_path': 'independent/' + safe(name), **row})
    base = indexed(docs['public_base']['files'])
    active_ref = original_plan['direct_path_contract']
    active_doc = sources.document(active_ref)
    active = indexed(active_doc['files'])
    require(len(base) == 181 and all(name in active and active[name] == row for name, row in base.items()),
            'Active direct mapping must preserve every base181 row exactly')
    deferred = {sources.normalize(n) for n in original_plan['deferred_direct_sources']}
    require(deferred <= set(base), 'Only original base181 future outputs may be deferred')
    expected_deferred = set(inventory['deferred_future_direct_generated_sources'])
    require(expected_deferred == {n for n in deferred if n not in current}, 'Deferred direct set differs')
    for family, rows in [('public_base', base), ('public_active', active)]:
        for name, row in rows.items():
            name = sources.normalize(name)
            require(name != GAP['source_relative_path'], 'Historical path appears in direct contract')
            if name in expected_deferred:
                continue
            by_name(family, name)
            original = current[name]
            if original['disposition'] == 'public_direct_identity':
                require(original['public_relative_path'] == row['public_relative_path'], 'Direct destination differs')
    evidence.append(ref(active_ref))
    for input_ref in original_plan['seed_selections']:
        doc = sources.document(input_ref)
        evidence.append(ref(input_ref))
        for row in doc['files']:
            add('seed', row)
    for name in original_plan['replay_required_sources']:
        by_name('replay', name)
    def dependencies(family, node):
        if type(node) is list:
            for child in node:
                dependencies(family, child)
        elif type(node) is dict:
            if all(key in node for key in ('source_relative_path', 'bytes', 'sha256')):
                add(family, node)
            for key in ('result_path', 'generator_path', 'local_result_path'):
                if key in node:
                    sha_key = key[:-5] + '_sha256'
                    require(sha_key in node, 'Unbound proof path')
                    by_name(family, node[key], node[sha_key])
            for child in node.values():
                if type(child) in (list, dict):
                    dependencies(family, child)
    for family, plan_key, output_name in [
            ('malformed_proofs', 'malformed_allowlists', 'malformed-fixture-allowlist-FINAL.json'),
            ('negative_proofs', 'negative_archive_allowlists', 'negative-archive-allowlist-FINAL.json')]:
        for input_ref in original_plan[plan_key]:
            evidence.append(ref(input_ref))
            dependencies(family, sources.document(input_ref))
        dependencies(family, originals[output_name])
    for key in ('privacy_allowlists', 'reviewed_private_omissions', 'reviewed_blend_profile_exclusions'):
        for input_ref in original_plan.get(key, []):
            evidence.append(ref(input_ref))
            dependencies('other_proofs', sources.document(input_ref))
    for key in ('archive_builder_source', 'archive_verifier_source', 'blend_decoder_source', 'blend_batch_source'):
        add('other_proofs', original_plan[key])
    no_gap_dependencies(sets)
    return sets, evidence, sorted(expected_deferred)


def derive_documents(inventory, selection, omissions, disclosure):
    documents = {'inventory': copy.deepcopy(inventory), 'selection': copy.deepcopy(selection),
                 'omissions': copy.deepcopy(omissions)}
    for obj in documents.values():
        obj.update(all_historical_retained=False, gap_acknowledged=True, model_go=False,
                   gap_acknowledgment=copy.deepcopy(disclosure))
    documents['selection'].update(passed=True, all_selected_dependencies_publicly_mapped=True,
                                  ready_for_final_assembly=True)
    documents['omissions']['ready_for_final_assembly'] = True
    documents['inventory']['ready_for_final_assembly'] = True
    for key, original in [('inventory', inventory), ('selection', selection), ('omissions', omissions)]:
        require(documents[key]['files'] == original['files'], 'Original rows may not be rewritten')
    require(documents['inventory']['historical_nonroutine_versions_missing'] == [GAP]
            and documents['inventory']['historical_original_version_accounting']
            == inventory['historical_original_version_accounting'], 'Historical accounting may not be rewritten')
    return documents


def write_fresh_bundle(out, files, before_commit=None):
    """Create a new directory only; refusal never writes a success report."""
    out = Path(os.path.abspath(out))
    parent = directory_fd(out.parent)
    try:
        os.mkdir(out.name, mode=0o700, dir_fd=parent)
        fd = os.open(out.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            for name, data in files.items():
                require('/' not in safe(name), 'Output basename required')
                if name == RESULT_NAME and before_commit is not None:
                    before_commit()
                target = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                 0o600, dir_fd=fd)
                try:
                    remaining = memoryview(data)
                    while remaining:
                        written = os.write(target, remaining)
                        require(written > 0, 'Output write failed')
                        remaining = remaining[written:]
                    os.fsync(target)
                finally:
                    os.close(target)
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def run(plan, sources, plan_binding, out, own_binding, test_binding, verify_invocation):
    require(plan.get('schema') == 'aeust-metadata-gap-acknowledgment-plan-v1'
            and plan.get('ready_for_gap_acknowledgment') is True and plan.get('model_go') is False
            and plan.get('acknowledged_gap') == GAP, 'Inactive or different adapter plan')
    require(ref(plan['adapter_source']) == own_binding
            and ref(plan['adapter_test_source']) == test_binding, 'Adapter source/test binding differs')
    generator = plan['original_generator']
    require(generator['source_relative_path'] == 'independent/archive-preparation/generate_final_inventory.py'
            and generator['sha256'] == GENERATOR_SHA, 'Frozen generator differs')
    sources.data(generator)
    original_plan = sources.document(plan['original_plan'])
    require(original_plan.get('schema') == 'aeust-final-inventory-plan-v1'
            and original_plan.get('ready_for_terminal_inventory') is True
            and original_plan.get('model_go') is False
            and original_plan.get('logical_alias_prefixes') == sources.aliases, 'Original plan differs')
    result = sources.document(plan['original_result'])
    require(set(result['outputs']) == ORIGINAL_OUTPUTS, 'Original output coverage differs')
    prefix = plan['original_result']['source_relative_path'].rsplit('/', 1)[0]
    require(original_plan.get('planned_output_source_prefix') == prefix, 'Original output location differs')
    original_refs, originals = {}, {}
    for name, bound in result['outputs'].items():
        original_refs[name] = ref({'source_relative_path': prefix + '/' + name, **bound})
        originals[name] = sources.document(original_refs[name])
    inventory = originals['private-original-payload-inventory-FINAL.json']
    selection = originals['controls-selection-FINAL.json']
    omissions = originals['private-omissions-FINAL.json']
    findings = originals['private-inventory-findings-FINAL.json']
    # Refuse the existing 409-HOLD first-round result before an expensive snapshot.
    require(result.get('hold_count') == 1 and findings.get('holds') == [
        {'reason': HISTORICAL_REASON, 'files': [GAP]}], 'Other original HOLDs remain')
    require(result.get('terminal_requirements_verified') == original_plan['terminal_requirements']
            and original_plan['terminal_requirements'], 'Terminal closure differs')
    for gate in original_plan['terminal_requirements']:
        evaluate_assertions(sources.document(gate['reference']), gate['assertions'])
    source_inventory_refs = original_plan['baseline_inventories'] + [original_plan['source_roster']]
    require(plan['source_inventories'] == source_inventory_refs, 'Source-inventory reference coverage differs')
    historical_inputs = []
    for input_ref in source_inventory_refs:
        historical_inputs.append(sources.document(input_ref))
    baseline_refs = [r for r in source_inventory_refs if r['sha256'] == BASELINE_SHA]
    require(len(baseline_refs) == 1 and baseline_refs[0]['source_relative_path']
            == 'independent/archive-preparation/private-original-payload-inventory-v1.json', 'Original baseline absent')
    baseline = sources.document(baseline_refs[0])
    require(any(ref(row) == GAP and row.get('type') == 'regular' for row in baseline['files']
                if row.get('type') == 'regular'), 'Gap not recorded in exact original baseline')
    current = indexed(inventory['files'])
    for name, expected_sha in [
            ('independent/archive-preparation/package_controls_v2.py', SCANNER_SHA),
            ('independent/public-preparation/public_bundle_common_v15.py', HELPER_SHA)]:
        require(name in current and current[name].get('sha256') == expected_sha,
                'Current frozen scanner/helper source differs')
        sources.bind(current[name])
    for row in plan['preinventoried_adapter_files']:
        binding = ref(row)
        require(binding['source_relative_path'] in current
                and same(binding, current[binding['source_relative_path']]), 'Adapter evidence was not finalized')
        sources.data(binding)
    controls = plan['adapter_controls']
    require(type(controls) is list and len(controls) == 2, 'Both control modes required')
    pre = {r['source_relative_path']: ref(r) for r in plan['preinventoried_adapter_files']}
    mandatory = [own_binding, test_binding] + [ref(r) for r in controls]
    require(all(pre.get(r['source_relative_path']) == r for r in mandatory), 'Preinventory omits adapter evidence')
    for mode, control_ref in enumerate(controls):
        control = sources.document(control_ref)
        require(control.get('schema') == 'aeust-metadata-gap-synthetic-controls-v1'
                and control.get('passed') is True and control.get('case_count') == 16
                and control.get('positive_count') == 2 and control.get('negative_count') == 14
                and control.get('optimization_level') == mode
                and control.get('adapter_source_sha256') == own_binding['sha256']
                and control.get('test_source_sha256') == test_binding['sha256']
                and control.get('scope') == 'synthetic_helper_level_not_real_cli'
                and control.get('real_cli_success_exercised') is False
                and control.get('all_original_input_and_tool_bytes_unchanged') is True
                and control.get('model_go') is False, 'Control proof differs')
        cases = control.get('cases')
        require(type(cases) is list and len(cases) == 16 and all(r.get('passed') is True for r in cases)
                and tuple(r['name'] for r in cases) == CONTROL_CASE_NAMES
                and [r.get('expected') for r in cases] == ['accept'] * 2 + ['reject'] * 14,
                'Control case coverage differs')
    required_sets, required_evidence, deferred = build_required_sets(sources, plan, original_plan, inventory, originals)
    disclosure = validate_only_gap(result, inventory, selection, omissions, findings, required_sets)
    # Every selected output outside snapshot must be one of the original three exact derived sidecars.
    sidecar_names = {'malformed-fixture-allowlist-FINAL.json', 'negative-archive-allowlist-FINAL.json',
                     'privacy-allowlist-FINAL.json'}
    sidecars = {original_refs[n]['source_relative_path']: original_refs[n] for n in sidecar_names}
    for name, row in indexed(selection['files']).items():
        if name not in current:
            require(name in sidecars and same(row, sidecars[name]), 'Uninventoried selected source')
    # Independently reproduce historical missing/retained accounting, without inventing bytes.
    available = {}
    for name, row in current.items():
        if row.get('type') == 'regular':
            available.setdefault(identity(row), set()).add(name)
    expected_history, missing = [], []
    historical_lookup = {}
    for row in inventory['historical_original_version_accounting']:
        if row.get('type') != 'symlink':
            key = (row['source_relative_path'], *identity(row))
            historical_lookup.setdefault(key, []).append(row)
    historical_positions = {}
    for doc in historical_inputs:
        for row in doc['files']:
            name = sources.normalize(row['source_relative_path'])
            if row.get('type') == 'regular':
                locations = available.get(identity(row), set())
                key = (name, *identity(row))
                position = historical_positions.get(key, 0)
                candidates = historical_lookup.get(key, [])
                require(position < len(candidates), 'Historical row absent')
                candidate = candidates[position]
                historical_positions[key] = position + 1
                require(candidate.get('prior_disposition') == row.get('disposition'),
                        'Historical prior disposition changed')
                retained = candidate.get('retained_at')
                require((retained in locations and candidate.get('status') == 'original_bytes_retained')
                        if locations else (retained is None and candidate.get('status') == 'historical_descriptor_only'),
                        'Historical retention differs')
                if not locations:
                    missing.append({'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256']})
                expected_history.append(candidate)
            elif row.get('type') == 'symlink':
                expected_history.append({'source_relative_path': name, 'type': 'symlink',
                    'target_descriptor_sha256': row['target_descriptor_sha256'],
                    'status': 'historical_link_descriptor_preserved_only'})
            else:
                raise ValueError('Unknown historical file type')
    require(missing == [GAP] and expected_history == inventory['historical_original_version_accounting'],
            'Historical accounting coverage differs')
    excluded = set(inventory['generated_metadata_excluded'])
    require(excluded == {prefix + '/' + name for name in ORIGINAL_OUTPUTS | {'final-inventory-generation-result.json'}},
            'Original generated-metadata exclusion differs')
    # Invocation plan is post-finalize metadata, never represented as a retained historical payload.
    if plan_binding.get('source_relative_path'):
        excluded.add(plan_binding['source_relative_path'])
    before, before_stats = sources.snapshot(original_plan['inventory_scopes'], excluded)
    expected_snapshot = {}
    for name, row in current.items():
        expected_snapshot[name] = ({k: row[k] for k in ('source_relative_path', 'type', 'bytes', 'sha256')}
                                  if row['type'] == 'regular' else
                                  {k: row[k] for k in ('source_relative_path', 'type', 'target_descriptor_sha256')})
    require(before == expected_snapshot, 'Current source tree differs from finalized snapshot')
    disclosure.update(original_result=ref(plan['original_result']), original_outputs=original_refs,
                      adapter_source=own_binding, adapter_test_source=test_binding,
                      adapter_controls=[ref(r) for r in controls])
    documents = derive_documents(inventory, selection, omissions, disclosure)
    files = {DERIVED[key]: dump(value) for key, value in documents.items()}
    derived_refs = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in files.items()}
    report = {'schema': 'aeust-metadata-gap-acknowledgment-result-v1', 'passed': True,
              'ready_for_final_assembly': True, **disclosure,
              'original_generator': ref(generator), 'original_plan': ref(plan['original_plan']),
              'adapter_plan': plan_binding, 'source_inventories': source_inventory_refs,
              'frozen_sets': plan['frozen_sets'], 'required_set_evidence': required_evidence,
              'required_sets': {family: {'unique_identity_path_count': len({(r['source_relative_path'], *identity(r)) for r in rows}),
                                'ordered_bindings_sha256': digest(dump(rows)),
                                'gap_path_absent': True, 'gap_identity_absent': True}
                                for family, rows in sorted(required_sets.items())},
              'deferred_future_direct_sources': deferred, 'derived_outputs': derived_refs,
              'all_current_source_bytes_unchanged': True,
              'scanner_dependency_closure': 'Original exact-generator completion, exact sole historical HOLD, unchanged full snapshot; scanner not rerun by adapter.',
              'original_scientific_verdict_unchanged': True,
              'controls_scope': 'synthetic_helper_level_not_real_cli', 'model_go': False,
              'original_outputs_rewritten': False, 'missing_bytes_reconstructed': False,
              'archive_created': False,
              'scope': 'Acknowledges one unavailable historical private progress-metadata identity. Current originals and required scientific/replay/proof dependencies remain exact. This is public metadata readiness only; all historical bytes are not retained and no model GO is granted.'}
    after, after_stats = sources.snapshot(original_plan['inventory_scopes'], excluded)
    require(after == before and after_stats == before_stats, 'Source changed during acknowledgment')
    sources.unchanged()
    verify_invocation()
    files[RESULT_NAME] = dump(report)
    def before_commit():
        # Derived products may be large. Recheck originals after those writes,
        # then commit the success report last. Failure leaves no success report.
        final_excluded = set(excluded)
        absolute_out = Path(os.path.abspath(out))
        candidates = [(label, root) for label, root in sources.roots.items()
                      if absolute_out.is_relative_to(root)]
        if candidates:
            label, root = max(candidates, key=lambda item: len(item[1].parts))
            output_prefix = sources.normalize(label + '/' + absolute_out.relative_to(root).as_posix())
            final_excluded.update(output_prefix + '/' + name for name in files)
        final_snapshot, final_stats = sources.snapshot(original_plan['inventory_scopes'], final_excluded)
        require(final_snapshot == before and final_stats == before_stats, 'Source changed before report commit')
        sources.unchanged()
        verify_invocation()
    write_fresh_bundle(out, files, before_commit=before_commit)
    return report


def main():
    os.umask(0o077)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--plan', required=True, type=Path)
    ap.add_argument('--plan-sha256', required=True)
    ap.add_argument('--root', action='append', required=True)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    own, own_id, own_stat = read_path(Path(__file__))
    test_path = Path(__file__).parent / 'test_metadata_gap_adapter.py'
    test, test_id, test_stat = read_path(test_path)
    raw, plan_id, plan_stat = read_path(args.plan)
    require(plan_id['sha256'] == args.plan_sha256, 'Adapter plan SHA differs')
    plan = parse(raw)
    roots = {}
    for entry in args.root:
        label, separator, path = entry.partition('=')
        require(separator and label not in roots, 'Duplicate or malformed root')
        roots[label] = Path(path)
    original_plan_ref = plan['original_plan']
    # Bootstrap exact original plan without imports or execution of its source.
    root_label, separator, rel = safe(original_plan_ref['source_relative_path']).partition('/')
    require(separator and root_label in roots, 'Original plan root differs')
    plan_raw, plan_actual, _ = read_path(roots[root_label] / rel)
    require(same(original_plan_ref, plan_actual), 'Original plan exact binding differs')
    sources = Sources(roots, parse(plan_raw)['logical_alias_prefixes'])
    def logical(path):
        path = Path(os.path.abspath(path))
        candidates = [(label, root) for label, root in sources.roots.items() if path.is_relative_to(root)]
        require(candidates, 'Adapter sources must be in finalized roots')
        label, root = max(candidates, key=lambda item: len(item[1].parts))
        return sources.normalize(label + '/' + path.relative_to(root).as_posix())
    own_binding = {'source_relative_path': logical(Path(__file__)), **own_id}
    test_binding = {'source_relative_path': logical(test_path), **test_id}
    plan_binding = dict(plan_id)
    try:
        plan_binding['source_relative_path'] = logical(args.plan)
    except ValueError:
        plan_binding['external_invocation_metadata'] = True
    sources.data(own_binding); sources.data(test_binding)
    # Out must not overlap any existing source; final creation uses O_EXCL semantics.
    require(not os.path.lexists(args.out), 'Fresh output directory required')
    def verify_invocation():
        for path, initial, initial_stat in [(Path(__file__), own_id, own_stat),
                                           (test_path, test_id, test_stat), (args.plan, plan_id, plan_stat)]:
            _, current, current_stat = read_path(path, keep=False)
            require(same(initial, current) and initial_stat == current_stat, 'Invocation source changed')
    report = run(plan, sources, plan_binding, args.out, own_binding, test_binding, verify_invocation)
    print(json.dumps({'passed': report['passed'], 'gap_acknowledged': True,
                      'all_historical_retained': False, 'model_go': False}, allow_nan=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
        print('REFUSED: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
        raise SystemExit(2)
