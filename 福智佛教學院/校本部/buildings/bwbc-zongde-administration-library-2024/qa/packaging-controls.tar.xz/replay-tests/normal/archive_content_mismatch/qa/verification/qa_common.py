# synthetic helper verification/qa_common.py
