"""Two-stage final payload roster and exact public-selection generator.

Prepared only. No geometry, Blender, producer controls, extraction or packaging.
roster hashes every declared source path, including private fixtures and logs.
finalize refreshes that roster after terminal gates, then performs bounded public
scanning through the exact v2/public helper source bytes supplied by the caller.
An unknown/missing proof or missing exact Blend profile stays HOLD, never waived.
"""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
import argparse
import copy
import datetime
import hashlib
import json
import math
import os
import re
import stat
import sys
import types

HERE = Path(__file__).resolve().parent
OUTPUT_NAMES = (
    'private-source-roster-FINAL.json', 'blend-candidates-FINAL.json',
    'private-original-payload-inventory-FINAL.json', 'controls-selection-FINAL.json',
    'private-omissions-FINAL.json', 'private-inventory-findings-FINAL.json',
    'malformed-fixture-allowlist-FINAL.json', 'negative-archive-allowlist-FINAL.json',
    'privacy-allowlist-FINAL.json', 'final-inventory-generation-result.json',
    'private-duplicate-candidates-FINAL.json',
)
CATEGORIES = {'private_execution_log', 'raw_png_private_metadata',
              'historical_or_failed_evidence', 'private_path_report',
              'duplicate_reproduction_or_scratch', 'private_source_reference',
              'outside_independent_publication_scope', 'private_control_fixture'}
FRESH_ROOTS = ('wrapper-tests-final-normal', 'wrapper-tests-final-optimized',
               'wrapper-exit-final-tests-normal', 'wrapper-exit-final-tests-optimized',
               'wrapper-review-final-normal.json', 'wrapper-review-final-optimized.json',
               'wrapper-exit-final-semantics-normal.json', 'wrapper-exit-final-semantics-optimized.json',
               'replay-results')
SIDECARS = {'malformed-fixture-allowlist-FINAL.json': 'malformed-fixture-allowlist.json',
            'negative-archive-allowlist-FINAL.json': 'negative-archive-allowlist.json',
            'privacy-allowlist-FINAL.json': 'privacy-allowlist.json'}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe(value):
    require(type(value) is str and value and '\\' not in value, 'Invalid logical path')
    p = PurePosixPath(value)
    require(not p.is_absolute() and not re.match(r'^[A-Za-z]:', value)
            and p.as_posix() == value and all(s not in ('', '.', '..') for s in value.split('/'))
            and all(32 <= ord(c) != 127 for c in value), 'Unsafe logical path')
    return value


def dump(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()


def parse(data):
    def pairs(values):
        obj = {}
        for k, v in values:
            require(k not in obj, 'Duplicate JSON object key')
            obj[k] = v
        return obj
    def number(value):
        result = float(value)
        require(math.isfinite(result), 'Nonfinite JSON float')
        return result
    return json.loads(data, object_pairs_hook=pairs, parse_float=number,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def directory_fd(path):
    absolute = Path(os.path.abspath(path))
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in absolute.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def source_stream(path):
    path = Path(os.path.abspath(path))
    parent = directory_fd(path.parent)
    try:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    finally:
        os.close(parent)
    stream = os.fdopen(fd, 'rb')
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), 'Nonregular file descriptor input')
        return stream
    except BaseException:
        stream.close()
        raise


def stat_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def read_bytes(path):
    with source_stream(path) as stream:
        before = os.fstat(stream.fileno())
        data = stream.read()
        after = os.fstat(stream.fileno())
    require(stat_identity(before) == stat_identity(after) and len(data) == before.st_size,
            'Source changed while reading')
    return data


def descriptor(path):
    with source_stream(path) as stream:
        before = os.fstat(stream.fileno())
        h = hashlib.file_digest(stream, 'sha256').hexdigest()
        after = os.fstat(stream.fileno())
    require(stat_identity(before) == stat_identity(after), 'Source changed while hashing')
    return {'bytes': after.st_size, 'sha256': h}


def exact(row, other):
    return (type(row.get('bytes')) is int and row['bytes'] >= 0
            and type(row.get('sha256')) is str and re.fullmatch(r'[0-9a-f]{64}', row['sha256']) is not None
            and all(row.get(k) == other.get(k) for k in ('bytes', 'sha256')))


def under(name, prefix):
    return name == prefix or name.startswith(prefix + '/')


class Context:
    def __init__(self, roots, plan, out, output_names):
        self.roots = roots
        self.plan = plan
        self.out = out
        self.aliases = plan.get('logical_alias_prefixes', {})
        for old, new in self.aliases.items():
            safe(old); safe(new)
            require(not any(under(new, other) for other in self.aliases), 'Recursive logical alias')
        self.bound = {}
        self.excluded = {self.logical(out / name) for name in output_names}
        self.derived = {}
        self.external_bytes = {}

    def normalize(self, name):
        safe(name)
        matches = [key for key in self.aliases if under(name, key)]
        if matches:
            key = max(matches, key=len)
            name = self.aliases[key] + name[len(key):]
        return safe(name)

    def path(self, logical, allow_directory=False):
        name = self.normalize(logical)
        label, slash, rel = name.partition('/')
        require(label in self.roots, 'Unknown logical source root')
        path = self.roots[label]
        require(path.is_dir() and not path.is_symlink(), 'Unsafe source root')
        if slash:
            for part in PurePosixPath(rel).parts:
                path = path / part
                require(not path.is_symlink(), 'Symlink in ordinary source lookup')
        require(path.is_file() or (allow_directory and path.is_dir()), 'Missing ordinary source')
        return path

    def logical(self, path):
        absolute = path.absolute()
        found = [(label, root) for label, root in self.roots.items() if absolute.is_relative_to(root)]
        require(found, 'Output must have a canonical logical source root')
        label, root = max(found, key=lambda item: len(item[1].parts))
        rel = absolute.relative_to(root).as_posix()
        return label if rel == '.' else safe(label + '/' + rel)

    def data(self, reference):
        require(isinstance(reference, dict), 'Exact input reference required')
        name = self.normalize(reference['source_relative_path'])
        path = self.path(name)
        data = read_bytes(path)
        actual = {'bytes': len(data), 'sha256': digest(data)}
        require(type(reference.get('bytes')) is int and exact(reference, actual),
                'Referenced source identity differs: ' + name)
        require(name not in self.bound or self.bound[name] == actual, 'Referenced input changed')
        self.bound[name] = actual
        return data

    def read(self, reference):
        return parse(self.data(reference))

    def walk(self):
        rows = {}
        def add(path, name):
            name = self.normalize(name)
            if name in self.excluded:
                return
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode):
                parent = directory_fd(path.parent)
                try:
                    before = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
                    target = os.readlink(path.name, dir_fd=parent)
                    after = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
                    require(stat.S_ISLNK(before.st_mode) and stat_identity(before) == stat_identity(after),
                            'Link descriptor changed while reading')
                    value = {'source_relative_path': name, 'type': 'symlink',
                             'target_descriptor_sha256': digest(os.fsencode(target))}
                finally:
                    os.close(parent)
            elif stat.S_ISREG(info.st_mode):
                value = {'source_relative_path': name, 'type': 'regular', **descriptor(path)}
            else:
                raise ValueError('Unaccountable special source path: ' + name)
            require(name not in rows or rows[name] == value, 'Conflicting overlapping scope')
            rows[name] = value
        for logical in self.plan['inventory_scopes']:
            name = self.normalize(logical)
            path = self.path(name, allow_directory=True)
            if path.is_file():
                add(path, name)
                continue
            def fail(error):
                raise error
            for base, dirs, files in os.walk(path, followlinks=False, onerror=fail):
                dirs.sort(); files.sort()
                base = Path(base)
                for child in list(dirs):
                    p = base / child
                    if p.is_symlink():
                        add(p, name + '/' + p.relative_to(path).as_posix())
                        dirs.remove(child)
                for child in files:
                    p = base / child
                    add(p, name + '/' + p.relative_to(path).as_posix())
        return rows

    def unchanged(self, initial):
        current = self.walk()
        changed = sorted(k for k in set(initial) | set(current) if initial.get(k) != current.get(k))
        for name, row in self.bound.items():
            if not exact(row, descriptor(self.path(name))):
                changed.append(name)
        for path, raw in self.external_bytes.items():
            if read_bytes(path) != raw:
                changed.append('external-generator-or-plan')
        return sorted(set(changed))


def write_new(path, value):
    write_new_bytes(path, dump(value))


def write_new_bytes(path, data):
    parent = directory_fd(path.parent)
    try:
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=parent)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
    finally:
        os.close(parent)


def prepare_output_directory(out):
    require(out.is_relative_to(HERE), 'Outputs must stay inside archive preparation')
    fd = directory_fd(HERE)
    try:
        for part in out.relative_to(HERE).parts:
            try:
                os.mkdir(part, 0o700, dir_fd=fd)
            except FileExistsError:
                pass
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
    finally:
        os.close(fd)


def normalize_row(c, row):
    result = copy.deepcopy(row)
    result['source_relative_path'] = c.normalize(result['source_relative_path'])
    proof = result.get('proof')
    if isinstance(proof, dict):
        for key in ('result_path', 'generator_path', 'local_result_path'):
            if key in proof:
                proof[key] = c.normalize(proof[key])
        # Original private proofs remain unchanged historical accounting.
        for key in ('result_archive_path', 'generator_archive_path', 'local_result_archive_path'):
            proof.pop(key, None)
    return result


def rows_from_references(c, references):
    found = {}
    for reference in references:
        doc = c.read(reference)
        require(isinstance(doc.get('files'), list), 'Expected files-list input')
        for row in doc['files']:
            row = normalize_row(c, row)
            key = row['source_relative_path']
            require(key not in found or found[key] == row, 'Conflicting exact input rows: ' + key)
            found[key] = row
    return found


def omission(name, row, category, reason):
    require(category in CATEGORIES and type(reason) is str and len(reason) >= 20,
            'Unreviewed omission category or reason')
    return {'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256'],
            'category': category, 'reason': reason}


def terminal_gates(c):
    requirements = c.plan.get('terminal_requirements')
    require(isinstance(requirements, list) and requirements, 'Explicit terminal gates are required')
    checks = []
    for requirement in requirements:
        obj = c.read(requirement['reference'])
        assertions = requirement.get('assertions')
        require(isinstance(assertions, list) and assertions, 'Empty terminal gate')
        for assertion in assertions:
            pointer = assertion['pointer']
            require(type(pointer) is str and pointer.startswith('/'), 'Invalid terminal JSON pointer')
            value = obj
            for part in pointer[1:].split('/'):
                key = part.replace('~1', '/').replace('~0', '~')
                value = value[int(key)] if isinstance(value, list) else value[key]
            require(type(value) is type(assertion['equals']) and value == assertion['equals'],
                    'Terminal assertion failed: ' + requirement['reference']['source_relative_path'] + pointer)
        checks.append(requirement)
    return checks


def original_version_accounting(c, snapshot):
    references = c.plan.get('baseline_inventories', []) + [c.plan['source_roster']]
    by_identity = defaultdict(list)
    for name, row in snapshot.items():
        if row['type'] == 'regular':
            by_identity[(row['bytes'], row['sha256'])].append(name)
    result = []
    missing = []
    for reference in references:
        old = c.read(reference)
        for row in old['files']:
            name = c.normalize(row['source_relative_path'])
            if row['type'] == 'regular':
                locations = by_identity.get((row['bytes'], row['sha256']), [])
                retained = name if name in locations else (locations[0] if locations else None)
                status = 'original_bytes_retained' if retained else 'historical_descriptor_only'
                # Logs and bytecode fixtures are original payload too. A prior
                # broad cache/log disposition cannot waive missing raw bytes.
                if retained is None:
                    missing.append({'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256']})
                result.append({'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256'],
                               'status': status, 'retained_at': retained,
                               'prior_disposition': row.get('disposition')})
            elif row['type'] == 'symlink':
                result.append({'source_relative_path': name, 'type': 'symlink',
                               'target_descriptor_sha256': row['target_descriptor_sha256'],
                               'status': 'historical_link_descriptor_preserved_only'})
    return result, missing


def loaded_source(path, expected, name):
    require(path.is_file() and not path.is_symlink(), 'Nonregular helper source')
    data = read_bytes(path)
    require(digest(data) == expected, 'Helper source SHA256 differs')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__package__ = ''
    sys.modules[name] = module
    exec(compile(data, str(path), 'exec'), module.__dict__)
    return module, data


def blend_exclusions(c, snapshot):
    """Only individually approved, proved unclassified-error negative fixtures."""
    rows = rows_from_references(c, c.plan.get('reviewed_blend_profile_exclusions', []))
    for name, row in rows.items():
        require(name.lower().endswith('.blend') and name in snapshot
                and snapshot[name]['type'] == 'regular' and exact(row, snapshot[name]),
                'Excluded Blend identity differs from full original roster')
        require(row.get('approved') is True and row.get('category') == 'private_control_fixture'
                and type(row.get('reason')) is str and len(row['reason']) >= 20,
                'Explicit per-file private Blend exclusion approval required')
        proof = row.get('proof', {})
        require(proof.get('kind') == 'unclassified_sdna_negative_control'
                and isinstance(proof.get('result_proofs'), list) and proof['result_proofs'],
                'Exact negative-control proof required for Blend exclusion')
        generator = proof['generator_source']; tested = proof['tested_source']
        c.data(generator); c.data(tested)
        for result in proof['result_proofs']:
            report = c.read(result['reference'])
            require(report.get('passed') is True
                    and type(report.get('optimization_level')) is int
                    and report['optimization_level'] == result['optimization_level']
                    and report.get('test_source_sha256') == generator['sha256']
                    and report.get('source_sha256') == tested['sha256'],
                    'Excluded Blend negative-result source/mode binding differs')
            cases = [case for case in report.get('cases', [])
                     if case.get('name') == 'unclassified_decoder_error_is_not_policy_success']
            require(len(cases) == 1, 'Excluded Blend rejection case absent or duplicated')
            case = cases[0]
            require(case.get('passed') is True and case.get('expected_accept') is False
                    and case.get('accepted') is False and type(case.get('returncode')) is int
                    and case['returncode'] == 1 and case.get('fixture_sha256') == row['sha256']
                    and case.get('expected_error') == 'Unclassified decoder/infrastructure failure',
                    'Excluded Blend does not prove the exact intended fail-closed rejection')
    return rows


def roster(c):
    initial = c.walk()
    excluded = blend_exclusions(c, initial)
    changed = c.unchanged(initial)
    require(not changed, 'Roster source tree changed; discard this attempt')
    rows = [initial[k] for k in sorted(initial)]
    common = {'schema': 'aeust-complete-source-roster-v1', 'private': True,
              'inventory_scopes': c.plan['inventory_scopes'],
              'generated_metadata_excluded': sorted(c.excluded),
              'all_snapshot_paths_accounted': True, 'source_changes_during_static_read': [],
              'regular_file_count': sum(r['type'] == 'regular' for r in rows), 'files': rows}
    all_blends = [r for r in rows if r['type'] == 'regular' and r['source_relative_path'].lower().endswith('.blend')]
    blends = [r for r in all_blends if r['source_relative_path'] not in excluded]
    common['blend_candidates'] = blends
    common['excluded_blend_candidates'] = [excluded[k] for k in sorted(excluded)]
    common['all_original_blend_count'] = len(all_blends)
    write_new(c.out / OUTPUT_NAMES[0], common)
    write_new(c.out / OUTPUT_NAMES[1], {'schema': 'aeust-exact-blend-candidate-roster-v1',
              'private': True, 'candidate_count': len(blends), 'files': all_blends, 'blend_candidates': blends,
              'excluded_blend_candidates': [excluded[k] for k in sorted(excluded)],
              'all_original_blend_count': len(all_blends),
              'scope': 'Every regular Blend remains inventoried. Only individually approved exact fail-closed negative fixtures are excluded from profile execution. No fixed total, profile acceptance or model GO is inferred.',
              'all_sources_unchanged': True})
    return {'roster_written': True, 'regular_file_count': common['regular_file_count'],
            'blend_candidate_count': len(blends), 'excluded_blend_candidate_count': len(excluded),
            'controls_executed': False, 'model_go': False}


def finalize(c, scanner_path, scanner_sha, public_path, public_sha, blend_profile_ref):
    require(c.plan.get('ready_for_terminal_inventory') is True and c.plan.get('model_go') is False,
            'Reviewed terminal inventory plan required')
    gates = terminal_gates(c)
    source_roster = c.read(c.plan['source_roster'])
    require(source_roster.get('all_snapshot_paths_accounted') is True
            and source_roster.get('source_changes_during_static_read') == [], 'Completed unchanged source roster required')
    scanner_module, scanner_source = loaded_source(scanner_path, scanner_sha, 'final_inventory_exact_scanner')
    public_module, public_source = loaded_source(public_path, public_sha, 'final_inventory_public_scanner')
    snapshot = c.walk()
    findings = []
    holds = []
    seed = rows_from_references(c, c.plan.get('seed_selections', []))
    malformed = rows_from_references(c, c.plan.get('malformed_allowlists', []))
    negative = rows_from_references(c, c.plan.get('negative_archive_allowlists', []))
    privacy = rows_from_references(c, c.plan.get('privacy_allowlists', []))
    reviewed = rows_from_references(c, c.plan.get('reviewed_private_omissions', []))
    excluded_blends = blend_exclusions(c, snapshot)
    for name, row in excluded_blends.items():
        require(name not in reviewed or exact(row, reviewed[name]), 'Conflicting private Blend exclusion identity')
        reviewed[name] = row
    direct = rows_from_references(c, [c.plan['direct_path_contract']])
    deferred = {c.normalize(name) for name in c.plan.get('deferred_direct_sources', [])}
    require(deferred <= set(direct), 'Deferred direct source outside exact direct contract')
    rejected_blends = {}
    diagnostic_omissions = {}
    diagnostic_copy_bindings = []
    if blend_profile_ref:
        profiles = c.read(blend_profile_ref)
        require(profiles.get('passed') is True and isinstance(profiles.get('files'), list)
                and isinstance(profiles.get('rejected', []), list)
                and profiles.get('model_go') is False and profiles.get('all_source_bytes_unchanged') is True
                and profiles.get('both_mode_profile_equivalence_verified') is True,
                'Completed exact Blend profile batch required')
        candidate_ref = c.plan['blend_candidate_roster']
        roster_doc = c.read(candidate_ref)
        candidates = roster_doc['blend_candidates']
        require(candidates == source_roster.get('blend_candidates')
                and roster_doc.get('excluded_blend_candidates', []) == source_roster.get('excluded_blend_candidates', []),
                'Full source roster and profile candidate roster differ')
        require(roster_doc.get('excluded_blend_candidates', [])
                == [excluded_blends[k] for k in sorted(excluded_blends)],
                'Approved excluded Blend set changed after profile roster')
        require(profiles['roster_sha256'] == candidate_ref['sha256']
                and profiles['candidate_count'] == len(candidates), 'Blend batch roster binding differs')
        decoder = c.plan['blend_decoder_source']
        batch = c.plan['blend_batch_source']
        c.data(decoder); c.data(batch)
        require(profiles['decoder_source_sha256'] == decoder['sha256']
                and profiles['batch_source_sha256'] == batch['sha256'], 'Blend batch tool binding differs')
        candidate_map = {c.normalize(row['source_relative_path']): (index, row)
                         for index, row in enumerate(candidates)}
        require(len(candidate_map) == len(candidates), 'Duplicate Blend roster candidate')
        outcome_names = [c.normalize(row['source_relative_path'])
                         for row in profiles['files'] + profiles.get('rejected', [])]
        require(len(set(outcome_names)) == len(outcome_names) and set(outcome_names) == set(candidate_map),
                'Blend batch accepted/rejected coverage differs')
        diagnostic_prefix = blend_profile_ref['source_relative_path'].rsplit('/', 1)[0]
        def bind_diagnostics(row, accepted):
            name = c.normalize(row['source_relative_path'])
            index, candidate = candidate_map[name]
            require(exact(row, candidate), 'Blend outcome identity differs from candidate')
            diagnostics = row['independent_diagnostic_bindings'] if accepted else row['diagnostics']
            if not accepted:
                require(row.get('policy_rejection_verified') is True and row.get('policy_rejection') in {
                    'Invalid Blender header', 'Unsupported control Blend SDNA format', 'Truncated Blender block',
                    'Incomplete or trailing Blender block stream', 'Missing or duplicated SDNA block',
                    'Invalid SDNA tag', 'Unexpected path field, location or buffer bytes'},
                    'Unclassified Blend infrastructure failure cannot become private policy rejection')
            require(len(diagnostics) == 2 and [r['mode'] for r in diagnostics] == ['normal', 'optimized'],
                    'Blend two-mode diagnostics differ')
            for diagnostic in diagnostics:
                require(type(diagnostic['returncode']) is int
                        and diagnostic['returncode'] == (0 if accepted else 1), 'Blend diagnostic exit semantics differ')
                for key, suffix in [('stdout_sha256', '.stdout.txt'), ('stderr_sha256', '.stderr.txt'),
                                    ('result_sha256', '.json')]:
                    h = diagnostic[key]
                    if h is None:
                        require(not accepted and key == 'result_sha256', 'Accepted Blend diagnostic result absent')
                        continue
                    logical = c.normalize(diagnostic_prefix + '/' + str(index).zfill(5)
                                          + '-' + diagnostic['mode'] + suffix)
                    require(logical in snapshot and snapshot[logical]['type'] == 'regular'
                            and snapshot[logical]['sha256'] == h, 'Blend raw diagnostic missing or changed')
                    if not accepted and key == 'stderr_sha256':
                        raw = c.data({'source_relative_path': logical, **{k: snapshot[logical][k] for k in ('bytes', 'sha256')}})
                        require(raw.decode('utf-8').strip().splitlines()[-1]
                                == 'RuntimeError: ' + row['policy_rejection'], 'Blend diagnostic policy reason differs')
                    diagnostic_omissions[logical] = omission(logical, snapshot[logical],
                        'private_execution_log' if key != 'result_sha256' else 'private_path_report',
                        'Exact independent SDNA raw diagnostic retained privately; clean public profile exposes only field classification and byte/hash bindings, never effective source values.')
            copied = c.normalize(diagnostic_prefix + '/' + str(index).zfill(5) + '-original.blend')
            require(copied in snapshot and snapshot[copied]['type'] == 'regular'
                    and exact(snapshot[copied], candidate), 'Private SDNA diagnostic copy differs from original')
            diagnostic_omissions[copied] = omission(copied, snapshot[copied],
                'duplicate_reproduction_or_scratch',
                'Exact hash-bound read-only SDNA diagnostic copy of a separately inventoried original candidate; the original is retained and the controlled batch binds both-mode diagnostics. This copy is not a new scientific source.')
            diagnostic_copy_bindings.append({'source_relative_path': copied,
                'bytes': candidate['bytes'], 'sha256': candidate['sha256'],
                'canonical_original_source_relative_path': name,
                'batch_manifest_sha256': blend_profile_ref['sha256'],
                'batch_source_sha256': profiles['batch_source_sha256'],
                'original_profile_accepted': accepted})
        for raw in profiles['files']:
            bind_diagnostics(raw, True)
            row = normalize_row(c, raw)
            require(row.get('kind') == 'blend_generic_defaults', 'Unexpected Blend allowance kind')
            key = row['source_relative_path']
            require(key not in privacy or privacy[key] == row, 'Conflicting Blend privacy profile')
            privacy[key] = row
        for raw in profiles.get('rejected', []):
            bind_diagnostics(raw, False)
            row = normalize_row(c, raw)
            key = row['source_relative_path']
            require(key not in privacy and key not in rejected_blends,
                    'Ambiguous or nonretained rejected Blend')
            rejected_blends[key] = row
    required = {c.normalize(name) for name in c.plan.get('replay_required_sources', [])}
    required.update(seed)
    for table in (malformed, negative):
        for name, row in table.items():
            required.add(name)
            for key in ('result_path', 'generator_path', 'local_result_path'):
                if key in row.get('proof', {}):
                    required.add(c.normalize(row['proof'][key]))
    for row in reviewed.values():
        if row.get('category') == 'duplicate_reproduction_or_scratch':
            proof = row.get('duplicate_proof')
            require(isinstance(proof, dict), 'Duplicate omission requires exact dependency and member proof')
            for ref in proof.get('raw_inputs', []) + [proof['generator_source']]:
                required.add(c.normalize(ref['source_relative_path']))
            for result in proof.get('result_proofs', []):
                required.add(c.normalize(result['reference']['source_relative_path']))
            for ref in (proof['selection_input'], proof['archive_index']):
                required.add(c.normalize(ref['source_relative_path']))
            for tool_ref in (c.plan['archive_verifier_source'], c.plan['archive_builder_source']):
                required.add(c.normalize(tool_ref['source_relative_path']))
            for member in proof.get('member_bindings', []):
                required.add(c.normalize(member['source_relative_path']))
    for name in sorted(required | (set(direct) - deferred) | set(privacy) | set(rejected_blends) | set(reviewed)):
        require(name in snapshot and snapshot[name]['type'] == 'regular',
                'Referenced required file absent from final roster: ' + name)
    for table in (seed, malformed, negative, privacy, rejected_blends, reviewed):
        for name, row in table.items():
            require(exact(row, snapshot[name]), 'Snapshot identity differs from bound input: ' + name)
    mappings = c.plan['archive_mapping_rules']
    for rule in mappings:
        safe(rule['source_prefix']); safe(rule['archive_prefix'])
    require(not c.plan.get('private_scope_rules'), 'Bulk private namespace omissions are forbidden')
    def destination(name):
        if name in seed:
            return safe(seed[name]['archive_path'])
        matches = [rule for rule in mappings if under(name, rule['source_prefix'])]
        require(matches, 'No public archive destination mapping: ' + name)
        longest = max(len(rule['source_prefix']) for rule in matches)
        matches = [rule for rule in matches if len(rule['source_prefix']) == longest]
        require(len(matches) == 1, 'Ambiguous archive destination mapping')
        rule = matches[0]
        return safe(rule['archive_prefix'] + name[len(rule['source_prefix']):])
    selected = {}
    omissions = {}
    for name, row in snapshot.items():
        if row['type'] == 'symlink':
            continue
        if name in diagnostic_omissions:
            require(name not in required and name not in direct, 'Private diagnostic is required publicly')
            omissions[name] = diagnostic_omissions[name]
            continue
        if name in rejected_blends:
            require(name not in required and name not in direct, 'Required public source has rejected Blend profile')
            omissions[name] = omission(name, row, 'private_control_fixture',
                'Original Blend retained privately: independent decoder rejected the exact fixed-buffer generic-default profile; no privacy waiver is granted.')
            continue
        if name in reviewed:
            require(name not in required and name not in direct, 'Explicit omission overlaps required public payload')
            omissions[name] = omission(name, row, reviewed[name]['category'], reviewed[name]['reason'])
            continue
        if name in direct and name not in required:
            continue
        # Do not omit arbitrary .pyc files. Poisoned bytecode is itself a control
        # input and remains original private payload unless exactly selected.
        filename = PurePosixPath(name).name
        routine_log = filename in ('stdout.txt', 'stderr.txt') or filename.endswith(('.log', '.stdout.txt', '.stderr.txt', '.lock'))
        if routine_log and name not in required:
            omissions[name] = omission(name, row, 'private_execution_log',
                'Original execution log retained privately with exact bytes and SHA256; it is not a replacement for a scientific result or replay source.')
            continue
        if name.lower().endswith('.blend') and name not in privacy:
            holds.append({'source_relative_path': name, 'reason': 'Missing exact accepted/rejected Blend profile'})
            continue
        selected[name] = {'source_relative_path': name, 'archive_path': destination(name),
                          'bytes': row['bytes'], 'sha256': row['sha256'], 'transformation': 'identity'}
    # Marker/log omissions are individually bound. Unknown malformed inputs and
    # duplicate reproductions require further exact proof or explicit review.
    sources = scanner_module.Sources(c.roots)
    trial = public_module.extended_scanner(scanner_module, sources, list(selected.values()),
        [r for n, r in malformed.items() if n in selected],
        [r for n, r in privacy.items() if n in selected],
        [r for n, r in negative.items() if n in selected])
    rejected_public = set()
    for name, row in sorted(selected.items()):
        try:
            trial.scan(row, sources.read(name, row['sha256'], row['bytes']))
        except (ValueError, RuntimeError) as error:
            rejected_public.add(name)
            text = str(error)
            findings.append({'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256'],
                             'scan_rejection': text, 'required_archive_dependency': name in required})
            privacy_error = text.startswith(('Private path marker in public payload:',
                'Credential-shaped content in public payload:', 'Additional private path/credential pattern:',
                'Unreviewed temporary path in public payload:', 'Source photo/PDF forbidden'))
            if privacy_error and name not in required and name not in direct:
                suffix = PurePosixPath(name).suffix.lower()
                category = ('raw_png_private_metadata' if suffix == '.png' else
                            'private_source_reference' if suffix in ('.py', '.sh', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff') else
                            'private_control_fixture' if '/fixtures/' in name or '/input/' in name else 'private_path_report')
                omissions[name] = omission(name, row, category,
                    'Original bytes retained privately after an exact bounded public scan identified a prohibited path, credential-shaped pattern or source-reference format; no producer payload is rewritten.')
            else:
                holds.append({'source_relative_path': name, 'reason': 'Exact public scan rejected; review proof/profile or explicit private disposition',
                              'error': text})
    for name in rejected_public:
        del selected[name]
    duplicates = []
    public_by_identity = defaultdict(list)
    for name, row in selected.items():
        public_by_identity[(row['bytes'], row['sha256'])].append(name)
    for name in sorted(rejected_public):
        row = snapshot[name]
        matches = public_by_identity.get((row['bytes'], row['sha256']), [])
        if matches:
            duplicates.append({'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256'],
                'category': 'duplicate_reproduction_or_scratch', 'candidate_identical_public_sources': matches,
                'approved': False, 'reason': 'Exact duplicate bytes found, but original-input/generator/result dependency proof still requires review; this proposal grants no omission.'})
    # Exact reviewed duplicate omissions need their unique inputs and complete
    # generation evidence publicly selected. A matching filename is insufficient.
    for name, row in reviewed.items():
        if row.get('category') != 'duplicate_reproduction_or_scratch':
            continue
        proof = row['duplicate_proof']
        try:
            require(proof.get('raw_inputs') and proof.get('result_proofs') and proof.get('member_bindings'),
                    'Empty duplicate dependency/member proof')
            for ref in proof['raw_inputs'] + [proof['generator_source'], proof['selection_input'], proof['archive_index']]:
                key = c.normalize(ref['source_relative_path'])
                require(key in selected and exact(ref, selected[key]), 'Duplicate dependency absent from archive selection')
            require(proof['generator_source']['sha256'] == scanner_sha,
                    'Duplicate report generator is not the exact controlled v2 source')
            archive_tool_hashes = {}
            for tool_ref in (c.plan['archive_verifier_source'], c.plan['archive_builder_source']):
                tool_name = c.normalize(tool_ref['source_relative_path'])
                require(tool_name in selected and exact(tool_ref, selected[tool_name]),
                        'Duplicate archive tooling is not publicly selected')
                c.data(tool_ref)
                archive_tool_hashes[PurePosixPath(tool_name).name] = tool_ref['sha256']
            evidence_selection = c.read(proof['selection_input'])
            evidence_index = c.read(proof['archive_index'])
            members = proof['member_bindings']
            member_map = {member['path']: member for member in members}
            require(len(member_map) == len(members), 'Duplicate member proof path')
            require([{k: member[k] for k in ('path', 'bytes', 'sha256')} for member in members]
                    == evidence_index.get('members'), 'Duplicate all-member proof differs from exact index')
            for member in members:
                key = c.normalize(member['source_relative_path'])
                require(key in selected and exact(member, selected[key]), 'Duplicate member has no exact selected original')
            expected_raw = {(c.normalize(ref['source_relative_path']), ref['bytes'], ref['sha256'])
                            for ref in proof['raw_inputs']}
            require(len(expected_raw) == len(proof['raw_inputs']), 'Duplicate raw input binding')
            for result in proof['result_proofs']:
                ref = result['reference']; key = c.normalize(ref['source_relative_path'])
                require(key in selected and exact(ref, selected[key]), 'Duplicate result absent from archive selection')
                report = c.read(ref)
                require(result.get('schema') == 'package_controls_v2_result'
                        and report.get('source_sha256') == proof['generator_source']['sha256']
                        and report.get('selection_sha256') == proof['selection_input']['sha256']
                        and report.get('index_sha256') == proof['archive_index']['sha256']
                        and report.get('archive_sha256') == evidence_index.get('archive_sha256')
                        and report.get('archive_tool_sources_sha256') == archive_tool_hashes
                        and all(report.get(flag) is True for flag in ('passed', 'sources_unchanged',
                            'bitwise_rebuild_verified', 'safe_extract_all_member_hashes_verified',
                            'all_selected_inputs_accounted', 'all_tracked_dependencies_selected_and_copied')),
                        'Unbound or unsupported duplicate generation report')
                copies = report.get('copies')
                selection_files = evidence_selection.get('files')
                require(isinstance(selection_files, list) and all(item.get('transformation', 'identity') == 'identity'
                        for item in selection_files), 'Duplicate selection is not identity-only')
                selection_copies = [{key: item[key] for key in ('source_relative_path', 'archive_path', 'bytes', 'sha256')}
                                    for item in sorted(selection_files, key=lambda item: item['archive_path'])]
                require(isinstance(copies, list) and report.get('copy_count') == len(copies)
                        and report.get('members') == len(members)
                        and evidence_selection.get('passed') is True
                        and selection_copies == copies, 'Duplicate report copies differ from exact original selection')
                copied_inputs = set(); reported_bindings = {}
                for copied in copies:
                    member = member_map.get(copied['archive_path'])
                    require(member is not None and exact(member, copied)
                            and member.get('reported_source_relative_path') == copied['source_relative_path'],
                            'Duplicate report input/member mapping differs')
                    copied_inputs.add((c.normalize(member['source_relative_path']), member['bytes'], member['sha256']))
                    require(copied['source_relative_path'] not in reported_bindings, 'Duplicate reported source')
                    reported_bindings[copied['source_relative_path']] = (copied['sha256'], copied['bytes'])
                require(copied_inputs == expected_raw, 'Duplicate raw inputs differ from complete generation copies')
                tracked = report.get('proof_and_source_bindings')
                require(isinstance(tracked, list) and len(tracked) == len(reported_bindings)
                        and len({item['source_relative_path'] for item in tracked}) == len(tracked)
                        and {item['source_relative_path']: (item['sha256'], item['bytes']) for item in tracked}
                            == reported_bindings,
                        'Duplicate generation report has unbound tracked dependencies')
            if proof['kind'] == 'regular_identity_duplicate':
                member = member_map.get(proof['reproduction_member_path'])
                require(member is not None and exact(member, row), 'Regular duplicate identity differs')
            elif proof['kind'] == 'strict_archive_identity_duplicate':
                verifier_ref = c.plan['archive_verifier_source']
                verifier_name = c.normalize(verifier_ref['source_relative_path'])
                require(verifier_name in selected and exact(verifier_ref, selected[verifier_name]),
                        'Duplicate archive verifier is not publicly selected')
                c.data(verifier_ref)
                verifier = scanner_module.load_tool(c.path(verifier_ref['source_relative_path']),
                    'final_inventory_duplicate_archive_verifier', verifier_ref['sha256'])
                index_ref = proof['archive_index']
                require(row['sha256'] == evidence_index['archive_sha256'], 'Duplicate archive identity differs from generation evidence')
                _, raw_tar, records = verifier.verify(c.path(name), c.path(index_ref['source_relative_path']))
                require([{k: m[k] for k in ('path', 'bytes', 'sha256')} for m in members]
                        == [{'path': path, 'bytes': end - start, 'sha256': digest(raw_tar[start:end])}
                            for path, start, end in records],
                        'Duplicate archive all-member mapping differs')
            else:
                raise ValueError('Unsupported duplicate proof kind')
        except (ValueError, RuntimeError) as error:
            holds.append({'source_relative_path': name, 'reason': 'Reviewed duplicate proof failed closure', 'error': str(error)})
    # Publish clean derived allowlists as original bytes of these NEW metadata
    # products. Their old inputs remain separately inventoried and unchanged.
    lists = [('malformed-fixture-allowlist-FINAL.json', malformed),
             ('negative-archive-allowlist-FINAL.json', negative),
             ('privacy-allowlist-FINAL.json', privacy)]
    for filename, table in lists:
        chosen = []
        for name, raw in sorted(table.items()):
            if name not in selected:
                continue
            row = copy.deepcopy(raw)
            row['archive_path'] = selected[name]['archive_path']
            if isinstance(row.get('proof'), dict):
                for key in ('result_path', 'generator_path', 'local_result_path'):
                    if key in row['proof']:
                        dependency = row['proof'][key]
                        if dependency in selected:
                            row['proof'][key.replace('_path', '_archive_path')] = selected[dependency]['archive_path']
            chosen.append(row)
        data = dump({'schema': 'aeust-final-exact-derived-allowlist-v1', 'files': chosen,
                     'source_inputs_unchanged': True, 'model_go': False})
        logical = c.logical(c.out / filename)
        c.derived[logical] = data
        selected[logical] = {'source_relative_path': logical, 'archive_path': SIDECARS[filename],
                             'bytes': len(data), 'sha256': digest(data), 'transformation': 'identity'}
    class FinalSources(scanner_module.Sources):
        def read(self, logical, expected_sha256=None, expected_bytes=None):
            if logical not in c.derived:
                return super().read(logical, expected_sha256, expected_bytes)
            data = c.derived[logical]
            binding = (digest(data), len(data))
            require((expected_sha256 is None or expected_sha256 == binding[0])
                    and (expected_bytes is None or expected_bytes == binding[1]), 'Derived metadata binding differs')
            require(logical not in self.tracked or self.tracked[logical] == binding, 'Derived metadata changed')
            self.tracked[logical] = binding
            return data
    final_sources = FinalSources(c.roots)
    final_scanner = public_module.extended_scanner(scanner_module, final_sources, list(selected.values()),
        [r for n, r in malformed.items() if n in selected],
        [r for n, r in privacy.items() if n in selected],
        [r for n, r in negative.items() if n in selected])
    try:
        for name, row in sorted(selected.items()):
            final_scanner.scan(row, final_sources.read(name, row['sha256'], row['bytes']))
        final_scanner.complete()
        final_sources.unchanged()
    except (ValueError, RuntimeError) as error:
        holds.append({'reason': 'Final selected dependency/scanner closure failed', 'error': str(error)})
    targets = [row['archive_path'] for row in selected.values()]
    require(len(targets) == len(set(targets)), 'Final archive destination collision')
    for target in targets:
        require(not any(under(target, root) for root in FRESH_ROOTS), 'Fixed fresh replay output would preexist')
        require(not any(other != target and under(target, other) for other in targets), 'Archive file/directory collision')
    versions, missing_versions = original_version_accounting(c, snapshot)
    if missing_versions:
        holds.append({'reason': 'Prior original payload versions not found in current preserved sources, including logs and bytecode fixtures',
                      'files': missing_versions})
    changed = c.unchanged(snapshot)
    require(not changed and read_bytes(scanner_path) == scanner_source and read_bytes(public_path) == public_source,
            'Source tree or scanner helpers changed during final inventory')
    rows = []
    for name, raw in sorted(snapshot.items()):
        row = dict(raw)
        if row['type'] == 'symlink':
            row.update(disposition='omit_nonregular_descriptor', reason='Original link descriptor hash only; never followed, copied, extracted or restored.')
        elif name in selected:
            row.update(disposition='preserve_original_bytes', archive_path=selected[name]['archive_path'], transformation='identity')
        elif name in direct:
            row.update(disposition='public_direct_identity', public_relative_path=direct[name]['public_relative_path'])
        elif name in omissions:
            row.update(disposition='private_original_retained', category=omissions[name]['category'], reason=omissions[name]['reason'])
        else:
            row.update(disposition='HOLD_unresolved_exact_publication_disposition')
        rows.append(row)
    ready = not holds and all(row['type'] == 'symlink' or row['disposition'] != 'HOLD_unresolved_exact_publication_disposition' for row in rows)
    inventory = {'schema': 'aeust-complete-private-original-control-payload-inventory-v1', 'private': True,
                 'stage': 'FINAL_TERMINAL_SNAPSHOT', 'inventory_scopes': c.plan['inventory_scopes'],
                 'generated_metadata_excluded': sorted(c.excluded), 'all_snapshot_paths_accounted': True,
                 'source_changes_during_static_read': [], 'regular_file_count': sum(r['type'] == 'regular' for r in rows),
                 'symlink_descriptor_count': sum(r['type'] == 'symlink' for r in rows),
                 'disposition_counts': dict(Counter(r['disposition'] for r in rows)),
                 'files': rows, 'historical_original_version_accounting': versions,
                 'excluded_blend_candidates': [excluded_blends[k] for k in sorted(excluded_blends)],
                 'historical_nonroutine_versions_missing': missing_versions,
                 'deferred_future_direct_generated_sources': sorted(name for name in deferred if name not in snapshot)}
    selection = {'schema': 'aeust-exact-original-controls-public-selection-final-v1', 'passed': ready,
                 'model_go': False, 'scope': 'Terminal original-byte controls selection; synthetic/archive success is not model GO.',
                 'files': [selected[k] for k in sorted(selected)], 'must_not_preexist_at_archive_root': list(FRESH_ROOTS),
                 'replay': c.plan.get('replay', {}), 'original_payload_inventory_complete': True,
                 'all_selected_dependencies_publicly_mapped': ready}
    outputs = {'private-original-payload-inventory-FINAL.json': inventory,
               'controls-selection-FINAL.json': selection,
               'private-omissions-FINAL.json': {'schema': 'aeust-v15-exact-private-omissions-1',
                    'ready_for_final_assembly': ready, 'files': [omissions[k] for k in sorted(omissions)]},
               'private-inventory-findings-FINAL.json': {'private': True, 'holds': holds, 'public_scan_rejections': findings,
                    'exact_private_sdna_diagnostic_copy_bindings': diagnostic_copy_bindings}}
    outputs['private-duplicate-candidates-FINAL.json'] = {'private': True, 'files': duplicates,
        'scope': 'Unapproved exact-byte duplicate proposals only. Missing member or raw-input/generator/result closure always remains HOLD.'}
    for filename, value in outputs.items():
        write_new(c.out / filename, value)
    for logical, data in c.derived.items():
        write_new_bytes(c.out / PurePosixPath(logical).name, data)
    result = {'passed': ready, 'model_go': False, 'source_inventory_regular_count': inventory['regular_file_count'],
              'selected_count': len(selected), 'private_omission_count': len(omissions), 'hold_count': len(holds),
              'terminal_requirements_verified': gates, 'all_source_bytes_unchanged': True,
              'scanner_source_sha256': scanner_sha, 'public_scanner_helper_sha256': public_sha,
              'controls_executed': False, 'archive_created': False,
              'outputs': {n: descriptor(c.out / n) for n in list(outputs) + list(SIDECARS)}}
    write_new(c.out / 'final-inventory-generation-result.json', result)
    return {k: result[k] for k in ('passed', 'selected_count', 'private_omission_count', 'hold_count', 'model_go')}


def main():
    os.umask(0o077)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('stage', choices=('roster', 'finalize'))
    ap.add_argument('--plan', type=Path, required=True)
    ap.add_argument('--root', action='append', default=[], metavar='LABEL=PATH')
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--scanner', type=Path)
    ap.add_argument('--scanner-sha256')
    ap.add_argument('--public-helper', type=Path)
    ap.add_argument('--public-helper-sha256')
    ap.add_argument('--blend-profiles', type=Path)
    args = ap.parse_args()
    own = read_bytes(Path(__file__))
    plan_data = read_bytes(args.plan)
    plan = parse(plan_data)
    require(plan.get('schema') == 'aeust-final-inventory-plan-v1'
            and isinstance(plan.get('inventory_scopes'), list) and plan['inventory_scopes'], 'Inventory plan schema differs')
    roots = {}
    for item in args.root:
        label, separator, value = item.partition('=')
        require(separator and '/' not in label and safe(label) and label not in roots, 'Invalid root label')
        raw = Path(value)
        require(raw.is_dir() and not raw.is_symlink(), 'Invalid source root')
        checkfd = directory_fd(raw)
        os.close(checkfd)
        roots[label] = Path(os.path.abspath(raw))
    require(roots, 'At least one source root required')
    for child, child_root in roots.items():
        for parent, parent_root in roots.items():
            if child != parent and child_root.is_relative_to(parent_root):
                alias = parent + '/' + child_root.relative_to(parent_root).as_posix()
                require(plan.get('logical_alias_prefixes', {}).get(alias) == child,
                        'Nested source root needs exact canonical logical alias')
    out = Path(os.path.abspath(args.out))
    prepare_output_directory(out)
    required_outputs = OUTPUT_NAMES[:2] if args.stage == 'roster' else OUTPUT_NAMES[2:]
    require(all(not (out / n).exists() and not (out / n).is_symlink() for n in required_outputs), 'Fresh named outputs required')
    c = Context(roots, plan, out, required_outputs)
    c.external_bytes = {Path(__file__): own, args.plan: plan_data}
    if args.stage == 'roster':
        result = roster(c)
    else:
        require(args.scanner and args.public_helper and args.scanner_sha256 and args.public_helper_sha256,
                'Both exact scanner helper sources are required for finalization')
        reference = None
        if args.blend_profiles:
            reference = {'source_relative_path': c.logical(args.blend_profiles), **descriptor(args.blend_profiles)}
        result = finalize(c, args.scanner, args.scanner_sha256, args.public_helper, args.public_helper_sha256, reference)
    require(read_bytes(Path(__file__)) == own and read_bytes(args.plan) == plan_data, 'Generator or plan changed')
    print(json.dumps(result, allow_nan=False))
    if result.get('passed') is False:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
