"""A narrowly bound historical metadata acknowledgment, never a model verdict.

No import-time I/O. A reviewed SHA-bound plan must identify the original
generator's sole historical HOLD, or its exact five HOLDs followed by the
independently verified fixed-four source-copy transition leaving that one gap.
It does not modify original evidence, execute scanners, or restore missing data.
"""
import argparse
from collections import Counter
import copy
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

sys.dont_write_bytecode = True
GAP = {'source_relative_path': 'independent/WORK-STATE.json', 'bytes': 3814,
       'sha256': '6e3f0b0e1e31a2e0385ecf3b66bad84158d4d1afaa0a231e60096740f8f17faf'}
HISTORICAL_REASON = 'Prior original payload versions not found in current preserved sources, including logs and bytecode fixtures'
GENERATOR_SHA = '60633de97fbb0e39e565b44e94cc6f8174eb81405eca6ba246ff4fc11695d786'
SCANNER_SHA = '1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c'
HELPER_SHA = '75f1604d4f67e87906325c7394d39b96fad98e1c44ca59db862307b4a35b935a'
BASELINE_SHA = '80c942e0c36610cbfc02bb38b8d2b557164e8fc33d2e550160c9517afcc3f636'
ANCHORS = {
    'science': ('author/qa/V15-SCIENTIFIC-HANDOFF-FREEZE.json', 'a46bf5d5eba7ba570dd0bd4adb832663f43146858751118d619b18f2ceab6224'),
    'runner': ('independent/V15-RUNNER-FREEZE-ADAPTER.json', '11794b224ea898237e21a54b387956ba2cfbab26c8161e2da1be467f0474d368'),
    'tooling': ('independent/FINAL-INDEPENDENT-TOOLING-FREEZE.json', '68c9fa4e5a0f9fb555b4b48d6ca37545711a2eac467d56e03f8ecaeaf29c05fa'),
    'public_base': ('independent/public-preparation/PUBLIC-DIRECT-PATH-CONTRACT.json', '508bf1f9ae233f221952e45f6e550e44f881849125210a4e8e82ce7ea8a7235d')}
ORIGINAL_OUTPUTS = {
    'private-original-payload-inventory-FINAL.json', 'controls-selection-FINAL.json',
    'private-omissions-FINAL.json', 'private-inventory-findings-FINAL.json',
    'private-duplicate-candidates-FINAL.json', 'malformed-fixture-allowlist-FINAL.json',
    'negative-archive-allowlist-FINAL.json', 'privacy-allowlist-FINAL.json'}
DERIVED = {'inventory': 'private-original-payload-inventory-GAP-ACK.json',
           'selection': 'controls-selection-GAP-ACK.json',
           'omissions': 'private-omissions-GAP-ACK.json'}
RESULT_NAME = 'metadata-gap-acknowledgment-result.json'
REPORT_PENDING_NAME = '.metadata-gap-report.pending'
DEFERRED_DIRECT = frozenset('independent/public-controls-v15/' + name for name in (
    'controls-index.json', 'controls-selection.json', 'controls.tar.xz',
    'malformed-fixture-allowlist.json', 'negative-archive-allowlist.json',
    'package_controls_v2.py', 'packaging-result.json', 'privacy-allowlist.json',
    'replay-verification.json'))
CSV = {'bytes': 31965628, 'sha256': 'c628b2150cecf8b894bf3f0716b5e60420bec9e77eec31c320ad8e34456b4016'}
MODES = ('normal', 'optimized')
CSV_REL = 'standard/dense/dense-original.csv.xz'
COPY_PATHS = tuple('independent/handoff-controls-' + control + '-v15/fixture/qa/v15-full/'
                   + science + '/' + CSV_REL for control in MODES for science in MODES)
CANONICAL = {'author/qa/v15-full/' + mode + '/' + CSV_REL: 'qa/v15-full/' + mode + '/' + CSV_REL
             for mode in MODES}
CANONICAL.update({'independent/final-v15-r1/geometry/' + mode + '/' + CSV_REL:
                  'qa/independent/geometry/' + mode + '/' + CSV_REL for mode in MODES})
COPY_OMISSION_REASON = (
    'Exact complete scientific CSV copy retained privately: the schema-only handoff producer hardlinked '
    'the frozen author file without a content mutation. All four complete canonical author/independent CSV streams '
    'remain mandatory direct public science and require the original exact full-stream privacy scan. This source '
    'copy is not a negative fixture, and no generic decoding limit or privacy exception is granted.')
COPY_OUTPUTS = {
    'inventory': 'private-original-payload-inventory-SOURCE-COPY-ACK.json',
    'selection': 'controls-selection-SOURCE-COPY-ACK.json',
    'omissions': 'private-omissions-SOURCE-COPY-ACK.json',
    'findings': 'private-inventory-findings-SOURCE-COPY-ACK.json'}
COPY_SOURCE = {'source_relative_path': 'independent/public-preparation/source-copy-adapter-v1/source_copy_duplicate_adapter.py',
               'bytes': 43962, 'sha256': '76aa6c42900004cf367fc616df12cbf8c667fb2c848fbbe546454f7e8ccc6e31'}
COPY_TEST = {'source_relative_path': 'independent/public-preparation/source-copy-adapter-v1/test_source_copy_duplicate_adapter.py',
             'bytes': 51278, 'sha256': 'ba50d20a2a499d826aa7042f9a975f8051f8f166fd1e552026933cbb7a090bd6'}
COPY_CONTROLS = {
    'normal': {'source_relative_path': 'independent/source-copy-controls-normal-v15/results.json', 'bytes': 43363,
               'sha256': '6500c375b9a339f4e2eb2d6733dbca542f95ec03ffe608c492c0783e412eb7e6'},
    'optimized': {'source_relative_path': 'independent/source-copy-controls-optimized-v15/results.json', 'bytes': 43363,
                  'sha256': '99a30733e6b70f1f71af33958c6eec84639e0faa2442b0b3ec0dece160927a54'}}
COPY_ANCHORS = {
    'graph': '2b5d1957abb5c4113f1de58fd8ef4001518533c651f732da1e956003c8fd3f79',
    'generator': GENERATOR_SHA,
    'producer': '9ca3d6850556a696c1b621396bfe6a367e9aad2bb3b39a34129e282fa6ce1ae5',
    'handoff_adapter': 'a98d528d07f290a2e4e16330784a176964a8ccadaa05e1d52a066364c2ce081e',
    'freeze': ANCHORS['science'][1], 'runner_adapter': ANCHORS['runner'][1],
    'scanner': SCANNER_SHA, 'public_helper': HELPER_SHA,
    'base_direct_contract': ANCHORS['public_base'][1],
    'comparison': '8b5debdbec2435a214f8c1da10215f4a165b1ec93442c2885269a8e860ce7aa8',
    'control_normal': '054469b254703ab512506ce2bff3c773f00a649e17844e457c7e2dc7bc8d4d73',
    'control_optimized': 'ed024297f6891dcde6e3ff07ae3e9bf9b6b191c27f7b1b80000652394d4c4e3a'}
COPY_DEPENDENCIES = {'author/qa/V15-SCIENTIFIC-HANDOFF-FREEZE.json',
    'independent/independent-tools/test_handoff_adapter.py',
    'independent/independent-tools/prepare_frozen_handoff.py',
    'independent/final-v15-r1/author-independent-science-comparison.json'}
COPY_DEPENDENCIES.update('independent/handoff-controls-' + mode + '-v15/' + name
    for mode in MODES for name in ('adapter-controls.json', 'genuine_complete_exact_mapping-adapter.json'))
COPY_DEPENDENCIES.update(name.rsplit('/', 1)[0] + '/dense-check.json' for name in CANONICAL)
COPY_DEPENDENCIES.update(name.split('/standard/dense/')[0] + '/dense-evidence.json' for name in CANONICAL)
SET_NAMES = {'science', 'runner', 'tooling', 'public_base', 'public_active',
             'seed', 'replay', 'malformed_proofs', 'negative_proofs', 'other_proofs'}
DISPOSITIONS = {'preserve_original_bytes', 'public_direct_identity', 'private_original_retained'}
CATEGORIES = {'private_execution_log', 'raw_png_private_metadata', 'historical_or_failed_evidence',
              'private_path_report', 'duplicate_reproduction_or_scratch', 'private_source_reference',
              'outside_independent_publication_scope', 'private_control_fixture'}
CONTROL_CASE_NAMES = (
    'exact_gap_preserves_original_evidence', 'same_path_current_bytes_remain_separately_retained',
    'wrong_gap_path_rejected', 'wrong_gap_size_rejected', 'wrong_gap_hash_rejected',
    'second_historical_missing_rejected', 'science_dependency_rejected',
    'runner_dependency_rejected', 'public_dependency_rejected', 'replay_dependency_rejected',
    'malformed_and_negative_proof_dependency_rejected', 'extra_hold_rejected',
    'current_unresolved_rejected', 'mutated_exact_binding_rejected',
    'source_changed_or_replaced_rejected', 'unsafe_read_and_strict_metadata_rejected',
    'exact_four_copy_then_gap_chain_preserves_original_five',
    'changed_upstream_source_binding_rejected', 'changed_original_output_chain_binding_rejected',
    'non_four_copy_extra_hold_rejected', 'unapproved_chain_row_delta_rejected',
    'widened_or_narrowed_deferred_set_rejected', 'required_proof_gap_path_rejected',
    'required_proof_gap_identity_rejected', 'late_source_change_prevents_success_report',
    'failed_derived_readback_prevents_success_report')
CONTROL_EXPECTATIONS = ['accept'] * 2 + ['reject'] * 14 + ['accept'] + ['reject'] * 9


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def parse(data):
    def pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'Duplicate JSON key')
            value[key] = item
        return value
    def number(value):
        result = float(value)
        require(math.isfinite(result), 'Nonfinite JSON value')
        return result
    def constant(value):
        raise ValueError('Nonfinite JSON value')
    return json.loads(data, object_pairs_hook=pairs, parse_float=number, parse_constant=constant)


def safe(name):
    require(type(name) is str and name and '\\' not in name, 'Unsafe logical path')
    require(not PurePosixPath(name).is_absolute() and not re.match(r'^[A-Za-z]:', name)
            and PurePosixPath(name).as_posix() == name
            and all(x not in ('', '.', '..') for x in name.split('/'))
            and all(ord(c) >= 32 and ord(c) != 127 for c in name), 'Unsafe logical path')
    return name


def identity(row):
    require(type(row) is dict and type(row.get('bytes')) is int and row['bytes'] >= 0
            and type(row.get('sha256')) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']),
            'Invalid exact identity')
    return row['bytes'], row['sha256']


def ref(row):
    identity(row)
    return {'source_relative_path': safe(row['source_relative_path']),
            'bytes': row['bytes'], 'sha256': row['sha256']}


def same(row, other):
    return identity(row) == identity(other)


def stat_id(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def directory_fd(path):
    path = Path(os.path.abspath(path))
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_at(parent, leaf, keep=True):
    fd = os.open(leaf, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode), 'Unsafe nonregular source')
        chunks, total, h = [], 0, hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            h.update(chunk)
            if keep:
                chunks.append(chunk)
        after = os.fstat(fd)
        named = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
        require(stat_id(before) == stat_id(after) == stat_id(named) and total == before.st_size,
                'Source changed during read')
        return (b''.join(chunks) if keep else None,
                {'bytes': total, 'sha256': h.hexdigest()}, stat_id(after))
    finally:
        os.close(fd)


def read_path(path, keep=True):
    path = Path(os.path.abspath(path))
    fd = directory_fd(path.parent)
    try:
        return read_at(fd, path.name, keep)
    finally:
        os.close(fd)


class Sources:
    def __init__(self, roots, aliases):
        self.roots = {k: Path(os.path.abspath(v)) for k, v in roots.items()}
        self.aliases = dict(aliases)
        self.observed = {}
        self.cache = {}
        require(set(self.roots) == {'author', 'independent'}, 'Exactly author and independent roots required')
        for label, path in self.roots.items():
            safe(label)
            fd = directory_fd(path)
            os.close(fd)
        nested = self.roots['author'].relative_to(self.roots['independent']).as_posix()
        require(self.aliases.get('independent/' + nested) == 'author', 'Canonical author root alias missing')
        for key, value in self.aliases.items():
            safe(key); safe(value)
            require(not any(value == other or value.startswith(other + '/') for other in self.aliases),
                    'Recursive aliases forbidden')

    def normalize(self, name):
        safe(name)
        choices = [k for k in self.aliases if name == k or name.startswith(k + '/')]
        if choices:
            key = max(choices, key=len)
            name = self.aliases[key] + name[len(key):]
        return safe(name)

    def path(self, name):
        name = self.normalize(name)
        root, slash, rest = name.partition('/')
        require(root in self.roots and slash, 'Unknown source root')
        return self.roots[root] / rest

    def data(self, row):
        row = ref(row)
        name = self.normalize(row['source_relative_path'])
        if name in self.cache:
            data, actual, sid = self.cache[name]
        else:
            data, actual, sid = read_path(self.path(name))
            self.cache[name] = (data, actual, sid)
        require(same(row, actual), 'Mutated exact binding')
        self.observed[name] = (actual, sid)
        return data

    def document(self, row):
        value = parse(self.data(row))
        require(type(value) is dict, 'JSON object required')
        return value

    def bind(self, row):
        row = ref(row)
        name = self.normalize(row['source_relative_path'])
        if name in self.observed:
            actual, sid = self.observed[name]
        else:
            _, actual, sid = read_path(self.path(name), keep=False)
        require(same(row, actual), 'Mutated exact binding')
        self.observed[name] = (actual, sid)

    def snapshot(self, scopes, excluded):
        rows, stats = {}, {}
        def visit(fd, logical):
            for leaf in sorted(os.listdir(fd)):
                name = self.normalize(logical + '/' + leaf)
                if name in excluded:
                    continue
                before = os.stat(leaf, dir_fd=fd, follow_symlinks=False)
                if stat.S_ISDIR(before.st_mode):
                    child = os.open(leaf, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                    try:
                        require(stat_id(before) == stat_id(os.fstat(child)), 'Directory changed')
                        visit(child, name)
                        require(stat_id(before) == stat_id(os.fstat(child))
                                == stat_id(os.stat(leaf, dir_fd=fd, follow_symlinks=False)), 'Directory changed')
                    finally:
                        os.close(child)
                elif stat.S_ISREG(before.st_mode):
                    _, bound, sid = read_at(fd, leaf, keep=False)
                    require(stat_id(before) == sid, 'Source changed before read')
                    value = {'source_relative_path': name, 'type': 'regular', **bound}
                    require(name not in rows or rows[name] == value, 'Conflicting scope overlap')
                    rows[name], stats[name] = value, sid
                elif stat.S_ISLNK(before.st_mode):
                    target = os.readlink(leaf, dir_fd=fd)
                    after = os.stat(leaf, dir_fd=fd, follow_symlinks=False)
                    require(stat_id(before) == stat_id(after), 'Link changed')
                    value = {'source_relative_path': name, 'type': 'symlink',
                             'target_descriptor_sha256': digest(os.fsencode(target))}
                    require(name not in rows or rows[name] == value, 'Conflicting link overlap')
                    rows[name], stats[name] = value, stat_id(after)
                else:
                    raise ValueError('Unsafe special source in snapshot')
        require(scopes == ['independent', 'author'], 'Complete two-root inventory required')
        for scope in scopes:
            fd = directory_fd(self.roots[scope])
            try:
                visit(fd, scope)
            finally:
                os.close(fd)
        return rows, stats

    def unchanged(self):
        for name, (bound, sid) in self.observed.items():
            _, current, current_sid = read_path(self.path(name), keep=False)
            require(same(bound, current) and sid == current_sid, 'Source changed after binding')


def indexed(rows):
    require(type(rows) is list, 'File list required')
    result = {}
    for row in rows:
        name = safe(row['source_relative_path'])
        require(name not in result, 'Duplicate source path')
        result[name] = row
    return result


def no_gap_dependencies(required_sets):
    require(set(required_sets) == SET_NAMES, 'Incomplete required-set families')
    for family, rows in required_sets.items():
        require(type(rows) is list and rows, 'Empty required-set family: ' + family)
        for row in rows:
            name = safe(row['source_relative_path'])
            require(name != GAP['source_relative_path'], 'Historical path is a required dependency: ' + family)
            require(identity(row) != identity(GAP), 'Historical identity is a required dependency: ' + family)


def validate_deferred_sources(names):
    require(type(names) is list and len(names) == 9 and set(names) == DEFERRED_DIRECT,
            'Only the exact original nine deferred direct sources are allowed')


def exact_references(value):
    """Explicit proof-reference closure; never walks inventory payload rows."""
    found = []
    if type(value) is dict:
        if all(key in value for key in ('source_relative_path', 'bytes', 'sha256')):
            found.append(ref(value))
        for child in value.values():
            if type(child) in (dict, list):
                found.extend(exact_references(child))
    elif type(value) is list:
        for child in value:
            found.extend(exact_references(child))
    return found


def protect_proof_references(rows):
    protected = []
    for raw in rows:
        row = ref(raw)
        require(row['source_relative_path'] != GAP['source_relative_path'],
                'Historical path is a required proof source')
        require(identity(row) != identity(GAP), 'Historical identity is a required proof source')
        protected.append(row)
    return protected


def validate_copy_source_bindings(source, test):
    require(ref(source) == COPY_SOURCE and ref(test) == COPY_TEST,
            'Frozen source-copy adapter source or test differs')


def validate_copy_evidence(evidence):
    require(evidence.get('anchors') == COPY_ANCHORS, 'Source-copy frozen evidence anchors differ')
    fixtures = indexed(evidence['fixture_descriptors'])
    canonical = indexed(evidence['canonical_descriptors'])
    require(set(fixtures) == set(COPY_PATHS) and set(canonical) == set(CANONICAL),
            'Source-copy exact fixture/canonical scope differs')
    require(all(same(row, CSV) for row in list(fixtures.values()) + list(canonical.values())),
            'Source-copy fixture/canonical identity differs')
    require(evidence.get('direct_mappings') == CANONICAL, 'Source-copy direct mappings differ')
    require(evidence.get('actual_descriptors') == {name: CSV for name in set(COPY_PATHS) | set(CANONICAL)},
            'Source-copy actual descriptors differ')
    require(evidence.get('freeze_count') == 3690
            and evidence.get('adapter_mapping_counts') == {mode: 3691 for mode in MODES},
            'Source-copy complete freeze counts differ')
    entries = {'qa/v15-full/' + mode + '/' + CSV_REL: CSV for mode in MODES}
    require(evidence.get('freeze_entries') == entries
            and evidence.get('adapter_entries') == {mode: entries for mode in MODES},
            'Source-copy freeze entries differ')
    require(evidence.get('control_results') == {
        mode: {'passed': True, 'optimization_level': level, 'case_count': 15, 'all_cases_passed': True,
               'positive_complete_mapping_passed': True, 'all_original_author_files_unchanged': True}
        for level, mode in enumerate(MODES)}, 'Source-copy original fifteen-case controls differ')
    require(evidence.get('comparison_rows') == [
        {'mode': mode, 'logical_file': CSV_REL, 'author_sha256': CSV['sha256'],
         'independent_sha256': CSV['sha256'], 'bitwise_identical': True,
         'only_allowed_non_scientific_differences': [], 'scientific_evidence_identical': True}
        for mode in MODES], 'Source-copy comparison differs')
    report = {'strict_passed': False, 'audit_passed': True, 'audit_completed': True,
              'audit_original_numerical_strict_passed': False, 'csv_data_rows': 477700,
              'compressed_bytes': CSV['bytes'], 'compressed_sha256': CSV['sha256'],
              'decoded_bytes': 580378890,
              'decoded_sha256': '8534788024a73b04e27e1184fa23cacc59da04aa5f2c2180d8b7b528315deedc',
              'all_original_numerical_flag_predicates_recomputed': True,
              'all_expected_flag_indices_and_reasons_match': True,
              'stl_sha256': '46649566e965a049e6e333e9d82b075407c8e926e55c9034f11fbe3dbdf15a5d',
              'dense_report_hash_bound': True}
    require(evidence.get('canonical_science_reports') == {name: report for name in CANONICAL},
            'Source-copy strict-false complete-stream evidence differs')
    dependencies = evidence.get('publicly_retained_dependencies', [])
    require(type(dependencies) is list and len(dependencies) == len(COPY_DEPENDENCIES)
            and set(dependencies) == COPY_DEPENDENCIES, 'Source-copy producer/proof scope differs')


def validate_source_copy_chain(original_result, originals, upstream, derived, expected):
    """Independently verify raw606 five HOLDs -> exactly four private copies -> one.

    No upstream source is imported, and no upstream result is renamed as a raw
    original-generator result. Only the explicit four-document delta is allowed.
    """
    require(upstream.get('schema') == 'aeust-exact-source-copy-duplicate-result-v1'
            and upstream.get('model_go') is False, 'Upstream source-copy result schema differs')
    for key in ('original_result', 'original_plan', 'original_outputs', 'adapter_source',
                'adapter_test_source', 'adapter_controls'):
        require(upstream.get(key) == expected[key], 'Upstream exact chain binding differs: ' + key)
    require(original_result.get('passed') is False and original_result.get('model_go') is False
            and type(original_result.get('hold_count')) is int and original_result['hold_count'] == 5
            and original_result.get('all_source_bytes_unchanged') is True
            and original_result.get('scanner_source_sha256') == SCANNER_SHA
            and original_result.get('public_scanner_helper_sha256') == HELPER_SHA,
            'Chain requires original606 exact five-HOLD result')
    inventory = originals['private-original-payload-inventory-FINAL.json']
    selection = originals['controls-selection-FINAL.json']
    omissions = originals['private-omissions-FINAL.json']
    findings = originals['private-inventory-findings-FINAL.json']
    historical = {'reason': HISTORICAL_REASON, 'files': [GAP]}
    copy_holds = [{'source_relative_path': name,
                   'reason': 'Exact public scan rejected; review proof/profile or explicit private disposition',
                   'error': 'Decoded byte safety limit exceeded'} for name in COPY_PATHS]
    holds = findings.get('holds')
    require(type(holds) is list and len(holds) == 5
            and sorted(dump(row) for row in holds) == sorted(dump(row) for row in copy_holds + [historical]),
            'Original606 HOLDs are not exactly fixed four CSVs plus historical gap')
    require(inventory.get('historical_nonroutine_versions_missing') == [GAP], 'Chain historical missing list differs')
    current, selected, omitted = indexed(inventory['files']), indexed(selection['files']), indexed(omissions['files'])
    require(selection.get('passed') is False and selection.get('model_go') is False
            and omissions.get('ready_for_final_assembly') is False, 'Original chain readiness differs')
    require(original_result.get('selected_count') == len(selected)
            and original_result.get('private_omission_count') == len(omitted), 'Original chain counts differ')
    for name in COPY_PATHS:
        require(name in current and same(current[name], CSV)
                and current[name].get('type') == 'regular'
                and current[name].get('disposition') == 'HOLD_unresolved_exact_publication_disposition'
                and name not in selected and name not in omitted, 'Original CSV copy identity/disposition differs')
    for name, destination in CANONICAL.items():
        require(name in current and same(current[name], CSV)
                and current[name].get('disposition') == 'public_direct_identity'
                and current[name].get('public_relative_path') == destination
                and name not in omitted, 'Canonical full science must remain direct')
    for name in COPY_DEPENDENCIES:
        require(name in current and current[name].get('disposition')
                in ('preserve_original_bytes', 'public_direct_identity'), 'Source-copy proof is not publicly retained')
    validate_copy_evidence(upstream['graph_evidence'])
    expected_documents = {'inventory': copy.deepcopy(inventory), 'selection': copy.deepcopy(selection),
                          'omissions': copy.deepcopy(omissions), 'findings': copy.deepcopy(findings)}
    added = [{'source_relative_path': name, **CSV, 'category': 'duplicate_reproduction_or_scratch',
              'reason': COPY_OMISSION_REASON} for name in COPY_PATHS]
    for row in expected_documents['inventory']['files']:
        if row['source_relative_path'] in COPY_PATHS:
            row.update(disposition='private_original_retained', category='duplicate_reproduction_or_scratch',
                       reason=COPY_OMISSION_REASON)
    expected_documents['inventory']['disposition_counts'] = dict(
        Counter(row['disposition'] for row in expected_documents['inventory']['files']))
    expected_documents['omissions']['files'] = sorted(omissions['files'] + added, key=lambda row: row['source_relative_path'])
    expected_documents['omissions']['ready_for_final_assembly'] = False
    expected_documents['selection'].update(passed=False, all_selected_dependencies_publicly_mapped=False)
    expected_documents['findings']['holds'] = [historical]
    require(derived == expected_documents, 'Unapproved source-copy document or row delta')
    transition = {'exact_source_copy_count': 4, 'category': 'duplicate_reproduction_or_scratch',
        'original_passed': False, 'original_hold_count': 5, 'remaining_hold_count': 1,
        'remaining_holds': [historical], 'historical_gap_acknowledged': False,
        'all_historical_retained': False, 'canonical_complete_science_must_remain_direct': True,
        'canonical_whole_stream_privacy_scan_still_required': True, 'generic_decoded_byte_limit_unchanged': 536870912,
        'selection_file_rows_unchanged': True, 'historical_accounting_unchanged': True,
        'added_private_dispositions': added, 'model_go': False}
    require(upstream.get('transition') == transition, 'Source-copy transition claim differs')
    remaining_gate_result = copy.deepcopy(original_result)
    remaining_gate_result.update(hold_count=1, private_omission_count=len(omitted) + 4,
        input_stage='independently_verified_source_copy_delta_not_original606_result')
    return remaining_gate_result, transition


def validate_only_gap(result, inventory, selection, omissions, findings, required_sets):
    """Pure acceptance gate, also exercised by the explicitly helper-level suite."""
    require(result.get('passed') is False and result.get('model_go') is False
            and type(result.get('hold_count')) is int and result['hold_count'] == 1,
            'Original result must have exactly one remaining HOLD')
    require(result.get('all_source_bytes_unchanged') is True
            and result.get('scanner_source_sha256') == SCANNER_SHA
            and result.get('public_scanner_helper_sha256') == HELPER_SHA,
            'Original unchanged/scanner binding differs')
    require(findings.get('holds') == [{'reason': HISTORICAL_REASON, 'files': [GAP]}],
            'Only the exact historical missing HOLD may remain')
    require(inventory.get('historical_nonroutine_versions_missing') == [GAP], 'Missing descriptors differ')
    history = inventory.get('historical_original_version_accounting')
    require(type(history) is list and history, 'Complete historical accounting required')
    missing = [row for row in history if row.get('status') == 'historical_descriptor_only'
               or ('retained_at' in row and row['retained_at'] is None)]
    require(len(missing) == 1 and ref(missing[0]) == GAP
            and missing[0].get('status') == 'historical_descriptor_only'
            and 'retained_at' in missing[0] and missing[0]['retained_at'] is None,
            'Historical descriptor-only row differs')
    require(inventory.get('all_snapshot_paths_accounted') is True
            and inventory.get('source_changes_during_static_read') == [], 'Snapshot closure not complete')
    require(selection.get('passed') is False and selection.get('model_go') is False
            and omissions.get('ready_for_final_assembly') is False, 'Original metadata readiness differs')
    current = indexed(inventory['files'])
    selected = indexed(selection['files'])
    omitted = indexed(omissions['files'])
    require(not (set(selected) & set(omitted)), 'Selected/private overlap')
    regular = {n: r for n, r in current.items() if r.get('type') == 'regular'}
    require(type(inventory.get('regular_file_count')) is int
            and inventory['regular_file_count'] == len(regular)
            and result.get('source_inventory_regular_count') == len(regular), 'Current count differs')
    require(result.get('selected_count') == len(selected)
            and result.get('private_omission_count') == len(omitted), 'Disposition counts differ')
    for name, row in current.items():
        if row.get('type') == 'symlink':
            require(row.get('disposition') == 'omit_nonregular_descriptor', 'Link disposition differs')
            continue
        require(row.get('type') == 'regular' and row.get('disposition') in DISPOSITIONS,
                'Current source unresolved')
        identity(row)
        require(identity(row) != identity(GAP), 'Acknowledged original bytes are now retained')
        if row['disposition'] == 'preserve_original_bytes':
            require(name in selected and same(row, selected[name])
                    and row.get('archive_path') == selected[name].get('archive_path')
                    and selected[name].get('transformation') == 'identity', 'Selected disposition differs')
        elif row['disposition'] == 'private_original_retained':
            require(name in omitted and same(row, omitted[name])
                    and row.get('category') == omitted[name].get('category')
                    and row.get('reason') == omitted[name].get('reason')
                    and row.get('category') in CATEGORIES, 'Private disposition differs')
        else:
            require(type(row.get('public_relative_path')) is str, 'Direct mapping absent')
    for name, row in omitted.items():
        require(name in regular and same(row, regular[name])
                and regular[name]['disposition'] == 'private_original_retained', 'Unaccounted omission')
    for name, row in selected.items():
        identity(row)
        require(row.get('transformation') == 'identity', 'Nonidentity selection')
        if name in regular:
            require(same(row, regular[name]) and regular[name]['disposition'] == 'preserve_original_bytes',
                    'Unaccounted selection')
    no_gap_dependencies(required_sets)
    return {'all_historical_retained': False, 'gap_acknowledged': True, 'model_go': False,
            'acknowledged_gap': copy.deepcopy(GAP), 'original_hold_count': 1, 'original_passed': False,
            'current_regular_dispositions_complete': True,
            'science_and_required_dependencies_exclude_gap': True}


def evaluate_assertions(doc, assertions):
    require(type(assertions) is list and assertions, 'Empty terminal assertions')
    for assertion in assertions:
        pointer = assertion['pointer']
        require(type(pointer) is str and pointer.startswith('/'), 'Invalid JSON pointer')
        value = doc
        for part in pointer[1:].split('/'):
            part = part.replace('~1', '/').replace('~0', '~')
            value = value[int(part)] if type(value) is list else value[part]
        expected = assertion['equals']
        require(type(value) is type(expected) and value == expected, 'Terminal assertion differs')


def build_required_sets(sources, plan, original_plan, inventory, originals,
                        proof_references, postfinal_references):
    current = indexed(inventory['files'])
    postfinal = {row['source_relative_path']: ref(row) for row in postfinal_references}
    sets = {name: [] for name in SET_NAMES}
    evidence = []
    def add(family, row):
        row = ref(row)
        row['source_relative_path'] = sources.normalize(row['source_relative_path'])
        name = row['source_relative_path']
        require((name in current and current[name]['type'] == 'regular' and same(row, current[name]))
                or (family == 'other_proofs' and postfinal.get(name) == row),
                'Required identity not in current inventory or exact postfinal proof set')
        sources.bind(row)
        sets[family].append(row)
    def by_name(family, name, expected_sha=None):
        name = sources.normalize(name)
        require(name != GAP['source_relative_path'], 'Historical path is required')
        require(name in current and current[name]['type'] == 'regular', 'Required dependency absent')
        if expected_sha is not None:
            require(current[name]['sha256'] == expected_sha, 'Proof dependency SHA differs')
        add(family, current[name])
    anchors = plan['frozen_sets']
    require(set(anchors) == set(ANCHORS), 'Frozen-set anchors differ')
    docs = {}
    for family, (path, expected_sha) in ANCHORS.items():
        anchor = ref(anchors[family])
        require(anchor['source_relative_path'] == path and anchor['sha256'] == expected_sha,
                'Frozen-set anchor identity differs')
        docs[family] = sources.document(anchor)
        evidence.append(anchor)
    science = docs['science']['files']
    require(type(science) is dict and len(science) == 3690
            and docs['science'].get('file_count') == 3690, 'Science set count differs')
    for name, row in science.items():
        add('science', {'source_relative_path': 'author/' + safe(name), **row})
    runner = docs['runner']['files']
    require(type(runner) is list and len(runner) == 3691, 'Runner set count differs')
    for row in runner:
        add('runner', {'source_relative_path': 'author/' + safe(row['path']),
                       'bytes': row['bytes'], 'sha256': row['sha256']})
    tooling = docs['tooling']['files']
    require(type(tooling) is dict and tooling, 'Tooling set absent')
    for name, row in tooling.items():
        add('tooling', {'source_relative_path': 'independent/' + safe(name), **row})
    base = indexed(docs['public_base']['files'])
    active_ref = original_plan['direct_path_contract']
    active_doc = sources.document(active_ref)
    active = indexed(active_doc['files'])
    require(len(base) == 181 and all(name in active and active[name] == row for name, row in base.items()),
            'Active direct mapping must preserve every base181 row exactly')
    validate_deferred_sources(original_plan['deferred_direct_sources'])
    deferred = {sources.normalize(n) for n in original_plan['deferred_direct_sources']}
    require(deferred <= set(base), 'Only original base181 future outputs may be deferred')
    expected_deferred = set(inventory['deferred_future_direct_generated_sources'])
    require(expected_deferred == {n for n in deferred if n not in current}, 'Deferred direct set differs')
    for family, rows in [('public_base', base), ('public_active', active)]:
        for name, row in rows.items():
            name = sources.normalize(name)
            require(name != GAP['source_relative_path'], 'Historical path appears in direct contract')
            if name in expected_deferred:
                continue
            by_name(family, name)
            original = current[name]
            if original['disposition'] == 'public_direct_identity':
                require(original['public_relative_path'] == row['public_relative_path'], 'Direct destination differs')
    evidence.append(ref(active_ref))
    for input_ref in original_plan['seed_selections']:
        doc = sources.document(input_ref)
        evidence.append(ref(input_ref))
        for row in doc['files']:
            add('seed', row)
    for name in original_plan['replay_required_sources']:
        by_name('replay', name)
    def dependencies(family, node):
        if type(node) is list:
            for child in node:
                dependencies(family, child)
        elif type(node) is dict:
            if all(key in node for key in ('source_relative_path', 'bytes', 'sha256')):
                add(family, node)
            for key in ('result_path', 'generator_path', 'local_result_path'):
                if key in node:
                    sha_key = key[:-5] + '_sha256'
                    require(sha_key in node, 'Unbound proof path')
                    by_name(family, node[key], node[sha_key])
            for child in node.values():
                if type(child) in (list, dict):
                    dependencies(family, child)
    for family, plan_key, output_name in [
            ('malformed_proofs', 'malformed_allowlists', 'malformed-fixture-allowlist-FINAL.json'),
            ('negative_proofs', 'negative_archive_allowlists', 'negative-archive-allowlist-FINAL.json')]:
        for input_ref in original_plan[plan_key]:
            evidence.append(ref(input_ref))
            dependencies(family, sources.document(input_ref))
        dependencies(family, originals[output_name])
    for key in ('privacy_allowlists', 'reviewed_private_omissions', 'reviewed_blend_profile_exclusions'):
        for input_ref in original_plan.get(key, []):
            evidence.append(ref(input_ref))
            dependencies('other_proofs', sources.document(input_ref))
    for key in ('archive_builder_source', 'archive_verifier_source', 'blend_decoder_source', 'blend_batch_source'):
        add('other_proofs', original_plan[key])
    # These are explicit required proof families, not the incidental list of all
    # current snapshot rows. A newer privately retained WORK-STATE is not proof.
    explicit_proofs = [gate['reference'] for gate in original_plan['terminal_requirements']]
    explicit_proofs += plan['preinventoried_adapter_files'] + plan['adapter_controls']
    explicit_proofs += proof_references + exact_references(original_plan)
    for row in protect_proof_references(explicit_proofs):
        add('other_proofs', row)
        evidence.append(ref(row))
    # Every metadata/source read must be independently represented by the
    # explicit required lists above. Snapshot-only rows are never observed here.
    protected = {row['source_relative_path'] for rows in sets.values() for row in rows}
    require(set(sources.observed) <= protected, 'A necessary read escaped the protected proof families')
    no_gap_dependencies(sets)
    return sets, evidence, sorted(expected_deferred)


def derive_documents(inventory, selection, omissions, disclosure):
    documents = {'inventory': copy.deepcopy(inventory), 'selection': copy.deepcopy(selection),
                 'omissions': copy.deepcopy(omissions)}
    for obj in documents.values():
        obj.update(all_historical_retained=False, gap_acknowledged=True, model_go=False,
                   gap_acknowledgment=copy.deepcopy(disclosure))
    documents['selection'].update(passed=True, all_selected_dependencies_publicly_mapped=True,
                                  ready_for_final_assembly=True)
    documents['omissions']['ready_for_final_assembly'] = True
    documents['inventory']['ready_for_final_assembly'] = True
    for key, original in [('inventory', inventory), ('selection', selection), ('omissions', omissions)]:
        require(documents[key]['files'] == original['files'], 'Original rows may not be rewritten')
    require(documents['inventory']['historical_nonroutine_versions_missing'] == [GAP]
            and documents['inventory']['historical_original_version_accounting']
            == inventory['historical_original_version_accounting'], 'Historical accounting may not be rewritten')
    return documents


def write_fresh_bundle(out, files, before_commit=None):
    """Create a new directory only; refusal never writes a success report."""
    require(REPORT_PENDING_NAME not in files, 'Reserved pending output name')
    if RESULT_NAME in files:
        require(list(files)[-1] == RESULT_NAME, 'Success report must be committed last')
    out = Path(os.path.abspath(out))
    parent = directory_fd(out.parent)
    try:
        os.mkdir(out.name, mode=0o700, dir_fd=parent)
        fd = os.open(out.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            verified_outputs = {}
            for name, data in files.items():
                require('/' not in safe(name), 'Output basename required')
                target_name = REPORT_PENDING_NAME if name == RESULT_NAME else name
                target = os.open(target_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                 0o600, dir_fd=fd)
                try:
                    remaining = memoryview(data)
                    while remaining:
                        written = os.write(target, remaining)
                        require(written > 0, 'Output write failed')
                        remaining = remaining[written:]
                    os.fsync(target)
                finally:
                    os.close(target)
                _, actual, initial_sid = read_at(fd, target_name, keep=False)
                require(actual == {'bytes': len(data), 'sha256': digest(data)}, 'Derived output readback differs')
                verified_outputs[target_name] = (actual, initial_sid)
                if name == RESULT_NAME:
                    if before_commit is not None:
                        before_commit()
                    for written_name, (expected_identity, expected_sid) in verified_outputs.items():
                        _, checked_identity, checked_sid = read_at(fd, written_name, keep=False)
                        require(checked_identity == expected_identity and checked_sid == expected_sid,
                                'Derived output changed before success commit')
                    _, actual, final_sid = read_at(fd, target_name, keep=False)
                    require(actual == {'bytes': len(data), 'sha256': digest(data)} and initial_sid == final_sid,
                            'Pending report changed before commit')
                    os.link(target_name, RESULT_NAME, src_dir_fd=fd, dst_dir_fd=fd, follow_symlinks=False)
                    os.unlink(target_name, dir_fd=fd)
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def read_source_copy_chain(sources, plan, originals, original_result, original_refs, current):
    chain = plan['source_copy_adapter']
    require(type(chain) is dict and set(chain) == {'result', 'source', 'test', 'controls'},
            'Explicit source-copy source/test/result/control bindings required')
    require(set(chain['controls']) == set(MODES), 'Source-copy two-mode controls absent')
    validate_copy_source_bindings(chain['source'], chain['test'])
    require({mode: ref(chain['controls'][mode]) for mode in MODES} == COPY_CONTROLS,
            'Source-copy reviewed two-mode result identities differ')
    expected = {'original_result': ref(plan['original_result']), 'original_plan': ref(plan['original_plan']),
                'original_outputs': original_refs, 'adapter_source': ref(chain['source']),
                'adapter_test_source': ref(chain['test']),
                'adapter_controls': {mode: ref(chain['controls'][mode]) for mode in MODES}}
    proof_refs = [expected['adapter_source'], expected['adapter_test_source']]
    selected = indexed(originals['controls-selection-FINAL.json']['files'])
    for row in proof_refs + list(expected['adapter_controls'].values()):
        name = row['source_relative_path']
        require(name in current and name in selected and same(row, current[name]) and same(row, selected[name])
                and current[name].get('disposition') == 'preserve_original_bytes',
                'Source-copy source/tests/controls were not public in raw606 inventory')
        sources.bind(row)
    for level, mode in enumerate(MODES):
        row = expected['adapter_controls'][mode]
        require(row['source_relative_path'] == 'independent/source-copy-controls-' + mode + '-v15/results.json',
                'Source-copy exact control result path differs')
        control = sources.document(row)
        require(control.get('schema') == 'aeust-exact-source-copy-controls-v1'
                and control.get('passed') is True and control.get('synthetic_only') is True
                and control.get('model_go') is False and control.get('optimization_level') == level
                and control.get('case_count') == 30 and control.get('positive_case_count') == 2
                and control.get('negative_case_count') == 28
                and control.get('adapter_source_sha256') == expected['adapter_source']['sha256']
                and control.get('test_source_sha256') == expected['adapter_test_source']['sha256']
                and control.get('all_original_adapter_and_test_source_bytes_unchanged') is True,
                'Source-copy complete two-mode control proof differs')
        cases = control.get('cases')
        require(type(cases) is list and len(cases) == 30 and len({r['name'] for r in cases}) == 30
                and all(r.get('passed') is True for r in cases), 'Source-copy case ledger differs')
        fixture_ref = {'source_relative_path': row['source_relative_path'].rsplit('/', 1)[0] + '/fixture-inventory.json',
                       **control['fixture_inventory']}
        require(control.get('fixture_inventory_file') == 'fixture-inventory.json', 'Source-copy fixture inventory path differs')
        proof_refs.extend([row, ref(fixture_ref)])
        sources.document(fixture_ref)
    upstream_ref = ref(chain['result'])
    require(upstream_ref['source_relative_path'].endswith('/source-copy-duplicate-result.json'),
            'Source-copy report basename differs')
    upstream = sources.document(upstream_ref)
    require(upstream.get('passed') is True and upstream.get('original_outputs_rewritten') is False
            and upstream.get('model_acceptance_changed') is False
            and upstream.get('all_bound_source_bytes_unchanged') is True,
            'Source-copy report unchanged/publication scope differs')
    output_prefix = upstream_ref['source_relative_path'].rsplit('/', 1)[0]
    require(output_prefix.startswith('independent/archive-preparation/source-copy-resolution-')
            and len(output_prefix.split('/')) == 3, 'Source-copy output namespace differs')
    require(set(upstream.get('derived_outputs', {})) == set(COPY_OUTPUTS.values()),
            'Source-copy four derived output coverage differs')
    derived, postfinal = {}, [upstream_ref]
    for key, filename in COPY_OUTPUTS.items():
        row = ref(upstream['derived_outputs'][filename])
        require(row['source_relative_path'] == output_prefix + '/' + filename,
                'Source-copy derived output location differs')
        derived[key] = sources.document(row)
        postfinal.append(row)
    adapter_plan_ref = ref(upstream['adapter_plan'])
    require(adapter_plan_ref['source_relative_path'] not in current,
            'Source-copy postfinal plan cannot replace an inventoried file')
    upstream_plan = sources.document(adapter_plan_ref)
    require(upstream_plan.get('schema') == 'aeust-exact-source-copy-plan-v1'
            and upstream_plan.get('ready_for_exact_four_resolution') is True
            and upstream_plan.get('model_go') is False
            and upstream_plan.get('original_result') == expected['original_result']
            and upstream_plan.get('original_plan') == expected['original_plan']
            and upstream_plan.get('adapter_source') == expected['adapter_source']
            and upstream_plan.get('adapter_test_source') == expected['adapter_test_source']
            and upstream_plan.get('adapter_controls') == expected['adapter_controls'],
            'Source-copy generating plan chain differs')
    postfinal.append(adapter_plan_ref)
    bound_sources = upstream.get('ref_bound_sources')
    require(type(bound_sources) is list and bound_sources, 'Source-copy proof references absent')
    normalized = indexed([ref(row) for row in bound_sources])
    require(set(COPY_ANCHORS.values()) <= {row['sha256'] for row in normalized.values()}
            and set(COPY_PATHS) | set(CANONICAL) | COPY_DEPENDENCIES <= set(normalized),
            'Source-copy frozen anchors or canonical/producer proof coverage incomplete')
    proof_refs.extend(list(normalized.values()) + exact_references(upstream_plan) + postfinal)
    remaining, transition = validate_source_copy_chain(original_result, originals, upstream, derived, expected)
    return derived, remaining, transition, proof_refs, postfinal, upstream


def run(plan, sources, plan_binding, out, own_binding, test_binding, verify_invocation):
    require(plan.get('schema') == 'aeust-metadata-gap-acknowledgment-plan-v2'
            and plan.get('ready_for_gap_acknowledgment') is True and plan.get('model_go') is False
            and plan.get('acknowledged_gap') == GAP, 'Inactive or different adapter plan')
    require(ref(plan['adapter_source']) == own_binding
            and ref(plan['adapter_test_source']) == test_binding, 'Adapter source/test binding differs')
    generator = plan['original_generator']
    require(generator['source_relative_path'] == 'independent/archive-preparation/generate_final_inventory.py'
            and generator['sha256'] == GENERATOR_SHA, 'Frozen generator differs')
    sources.data(generator)
    original_plan = sources.document(plan['original_plan'])
    require(original_plan.get('schema') == 'aeust-final-inventory-plan-v1'
            and original_plan.get('ready_for_terminal_inventory') is True
            and original_plan.get('model_go') is False
            and original_plan.get('logical_alias_prefixes') == sources.aliases, 'Original plan differs')
    result = sources.document(plan['original_result'])
    require(set(result['outputs']) == ORIGINAL_OUTPUTS, 'Original output coverage differs')
    prefix = plan['original_result']['source_relative_path'].rsplit('/', 1)[0]
    require(original_plan.get('planned_output_source_prefix') == prefix, 'Original output location differs')
    original_refs, originals = {}, {}
    for name, bound in result['outputs'].items():
        original_refs[name] = ref({'source_relative_path': prefix + '/' + name, **bound})
        originals[name] = sources.document(original_refs[name])
    inventory = originals['private-original-payload-inventory-FINAL.json']
    selection = originals['controls-selection-FINAL.json']
    omissions = originals['private-omissions-FINAL.json']
    findings = originals['private-inventory-findings-FINAL.json']
    # Refuse the 409-HOLD first run. A five-HOLD chain must be explicit and is
    # independently verified below; it is never relabeled as native606 one HOLD.
    chain_requested = 'source_copy_adapter' in plan
    if chain_requested:
        require(result.get('hold_count') == 5, 'Source-copy chain requires raw606 five HOLDs')
    else:
        require(result.get('hold_count') == 1 and findings.get('holds') == [
            {'reason': HISTORICAL_REASON, 'files': [GAP]}], 'Other original HOLDs remain')
    require(result.get('terminal_requirements_verified') == original_plan['terminal_requirements']
            and original_plan['terminal_requirements'], 'Terminal closure differs')
    for gate in original_plan['terminal_requirements']:
        evaluate_assertions(sources.document(gate['reference']), gate['assertions'])
    source_inventory_refs = original_plan['baseline_inventories'] + [original_plan['source_roster']]
    require(plan['source_inventories'] == source_inventory_refs, 'Source-inventory reference coverage differs')
    historical_inputs = []
    for input_ref in source_inventory_refs:
        historical_inputs.append(sources.document(input_ref))
    baseline_refs = [r for r in source_inventory_refs if r['sha256'] == BASELINE_SHA]
    require(len(baseline_refs) == 1 and baseline_refs[0]['source_relative_path']
            == 'independent/archive-preparation/private-original-payload-inventory-v1.json', 'Original baseline absent')
    baseline = sources.document(baseline_refs[0])
    require(any(ref(row) == GAP and row.get('type') == 'regular' for row in baseline['files']
                if row.get('type') == 'regular'), 'Gap not recorded in exact original baseline')
    current = indexed(inventory['files'])
    for name, expected_sha in [
            ('independent/archive-preparation/package_controls_v2.py', SCANNER_SHA),
            ('independent/public-preparation/public_bundle_common_v15.py', HELPER_SHA)]:
        require(name in current and current[name].get('sha256') == expected_sha,
                'Current frozen scanner/helper source differs')
        sources.bind(current[name])
    for row in plan['preinventoried_adapter_files']:
        binding = ref(row)
        require(binding['source_relative_path'] in current
                and same(binding, current[binding['source_relative_path']]), 'Adapter evidence was not finalized')
        sources.data(binding)
    controls = plan['adapter_controls']
    require(type(controls) is list and len(controls) == 2, 'Both control modes required')
    pre = {r['source_relative_path']: ref(r) for r in plan['preinventoried_adapter_files']}
    mandatory = [own_binding, test_binding] + [ref(r) for r in controls]
    require(all(pre.get(r['source_relative_path']) == r for r in mandatory), 'Preinventory omits adapter evidence')
    for mode, control_ref in enumerate(controls):
        control = sources.document(control_ref)
        require(control.get('schema') == 'aeust-metadata-gap-synthetic-controls-v2'
                and control.get('passed') is True and control.get('case_count') == 26
                and control.get('positive_count') == 3 and control.get('negative_count') == 23
                and control.get('optimization_level') == mode
                and control.get('adapter_source_sha256') == own_binding['sha256']
                and control.get('test_source_sha256') == test_binding['sha256']
                and control.get('scope') == 'synthetic_helper_level_not_real_cli'
                and control.get('real_cli_success_exercised') is False
                and control.get('all_original_input_and_tool_bytes_unchanged') is True
                and control.get('model_go') is False, 'Control proof differs')
        cases = control.get('cases')
        require(type(cases) is list and len(cases) == 26 and all(r.get('passed') is True for r in cases)
                and tuple(r['name'] for r in cases) == CONTROL_CASE_NAMES
                and [r.get('expected') for r in cases] == CONTROL_EXPECTATIONS,
                'Control case coverage differs')
    postfinal_refs = [ref(plan['original_result'])] + list(original_refs.values())
    proof_refs = [ref(generator), ref(plan['original_plan']), own_binding, test_binding]
    proof_refs += source_inventory_refs + list(plan['frozen_sets'].values()) + postfinal_refs
    require(identity(plan_binding) != identity(GAP), 'Invocation plan cannot use historical missing identity')
    if plan_binding.get('source_relative_path'):
        postfinal_refs.append(ref(plan_binding))
        proof_refs.append(ref(plan_binding))
    gate_result, chain_transition, upstream = result, None, None
    if chain_requested:
        resolved, gate_result, chain_transition, chain_refs, chain_postfinal, upstream = read_source_copy_chain(
            sources, plan, originals, result, original_refs, current)
        inventory, selection, omissions, findings = (resolved[key] for key in ('inventory', 'selection', 'omissions', 'findings'))
        proof_refs.extend(chain_refs)
        postfinal_refs.extend(chain_postfinal)
    required_sets, required_evidence, deferred = build_required_sets(
        sources, plan, original_plan, inventory, originals, proof_refs, postfinal_refs)
    disclosure = validate_only_gap(gate_result, inventory, selection, omissions, findings, required_sets)
    disclosure.update(original_hold_count=result['hold_count'], original_passed=result['passed'],
                      acknowledged_input_hold_count=1,
                      input_stage='source_copy_derived_remaining_gap' if chain_requested else 'original606_native_gap')
    if chain_requested:
        disclosure.update(source_copy_adapter_result=ref(plan['source_copy_adapter']['result']),
                          source_copy_transition=chain_transition,
                          source_copy_original_outputs_preserved=True,
                          original606_report_not_rewritten_or_relabelled=True)
    # Every selected output outside snapshot must be one of the original three exact derived sidecars.
    sidecar_names = {'malformed-fixture-allowlist-FINAL.json', 'negative-archive-allowlist-FINAL.json',
                     'privacy-allowlist-FINAL.json'}
    sidecars = {original_refs[n]['source_relative_path']: original_refs[n] for n in sidecar_names}
    for name, row in indexed(selection['files']).items():
        if name not in current:
            require(name in sidecars and same(row, sidecars[name]), 'Uninventoried selected source')
    # Independently reproduce historical missing/retained accounting, without inventing bytes.
    available = {}
    for name, row in current.items():
        if row.get('type') == 'regular':
            available.setdefault(identity(row), set()).add(name)
    expected_history, missing = [], []
    historical_lookup = {}
    for row in inventory['historical_original_version_accounting']:
        if row.get('type') != 'symlink':
            key = (row['source_relative_path'], *identity(row))
            historical_lookup.setdefault(key, []).append(row)
    historical_positions = {}
    for doc in historical_inputs:
        for row in doc['files']:
            name = sources.normalize(row['source_relative_path'])
            if row.get('type') == 'regular':
                locations = available.get(identity(row), set())
                key = (name, *identity(row))
                position = historical_positions.get(key, 0)
                candidates = historical_lookup.get(key, [])
                require(position < len(candidates), 'Historical row absent')
                candidate = candidates[position]
                historical_positions[key] = position + 1
                require(candidate.get('prior_disposition') == row.get('disposition'),
                        'Historical prior disposition changed')
                retained = candidate.get('retained_at')
                require((retained in locations and candidate.get('status') == 'original_bytes_retained')
                        if locations else (retained is None and candidate.get('status') == 'historical_descriptor_only'),
                        'Historical retention differs')
                if not locations:
                    missing.append({'source_relative_path': name, 'bytes': row['bytes'], 'sha256': row['sha256']})
                expected_history.append(candidate)
            elif row.get('type') == 'symlink':
                expected_history.append({'source_relative_path': name, 'type': 'symlink',
                    'target_descriptor_sha256': row['target_descriptor_sha256'],
                    'status': 'historical_link_descriptor_preserved_only'})
            else:
                raise ValueError('Unknown historical file type')
    require(missing == [GAP] and expected_history == inventory['historical_original_version_accounting'],
            'Historical accounting coverage differs')
    excluded = set(inventory['generated_metadata_excluded'])
    require(excluded == {prefix + '/' + name for name in ORIGINAL_OUTPUTS | {'final-inventory-generation-result.json'}},
            'Original generated-metadata exclusion differs')
    for row in postfinal_refs:
        name = row['source_relative_path']
        require(name not in current, 'Postfinal chain proof may not replace a current original')
        excluded.add(name)
    # Invocation plan is post-finalize metadata, never represented as a retained historical payload.
    if plan_binding.get('source_relative_path'):
        excluded.add(plan_binding['source_relative_path'])
    before, before_stats = sources.snapshot(original_plan['inventory_scopes'], excluded)
    expected_snapshot = {}
    for name, row in current.items():
        expected_snapshot[name] = ({k: row[k] for k in ('source_relative_path', 'type', 'bytes', 'sha256')}
                                  if row['type'] == 'regular' else
                                  {k: row[k] for k in ('source_relative_path', 'type', 'target_descriptor_sha256')})
    require(before == expected_snapshot, 'Current source tree differs from finalized snapshot')
    disclosure.update(original_result=ref(plan['original_result']), original_outputs=original_refs,
                      adapter_source=own_binding, adapter_test_source=test_binding,
                      adapter_controls=[ref(r) for r in controls])
    documents = derive_documents(inventory, selection, omissions, disclosure)
    files = {DERIVED[key]: dump(value) for key, value in documents.items()}
    derived_refs = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in files.items()}
    report = {'schema': 'aeust-metadata-gap-acknowledgment-result-v2', 'passed': True,
              'ready_for_final_assembly': True, **disclosure,
              'original_generator': ref(generator), 'original_plan': ref(plan['original_plan']),
              'adapter_plan': plan_binding, 'source_inventories': source_inventory_refs,
              'post_finalize_bound_additions': [row for row in postfinal_refs
                  if row['source_relative_path'] not in {r['source_relative_path'] for r in original_refs.values()}
                  and row['source_relative_path'] != plan['original_result']['source_relative_path']],
              'frozen_sets': plan['frozen_sets'], 'required_set_evidence': required_evidence,
              'required_sets': {family: {'unique_identity_path_count': len({(r['source_relative_path'], *identity(r)) for r in rows}),
                                'ordered_bindings_sha256': digest(dump(rows)),
                                'gap_path_absent': True, 'gap_identity_absent': True}
                                for family, rows in sorted(required_sets.items())},
              'deferred_future_direct_sources': deferred, 'derived_outputs': derived_refs,
              'all_current_source_bytes_unchanged': True,
              'scanner_dependency_closure': ('Original606 raw five-HOLD result plus independently verified exact-four source-copy delta, '
                  'then sole historical HOLD, complete dispositions and unchanged full snapshot; no scanner rerun.'
                  if chain_requested else 'Original exact-generator completion, exact sole historical HOLD, unchanged full snapshot; no scanner rerun.'),
              'original_scientific_verdict_unchanged': True,
              'controls_scope': 'synthetic_helper_level_not_real_cli', 'model_go': False,
              'original_outputs_rewritten': False, 'missing_bytes_reconstructed': False,
              'archive_created': False,
              'scope': 'Acknowledges one unavailable historical private progress-metadata identity. Current originals and required scientific/replay/proof dependencies remain exact. This is public metadata readiness only; all historical bytes are not retained and no model GO is granted.'}
    if chain_requested:
        report['source_copy_chain'] = {
            'result': ref(plan['source_copy_adapter']['result']),
            'adapter_source': ref(plan['source_copy_adapter']['source']),
            'adapter_test_source': ref(plan['source_copy_adapter']['test']),
            'adapter_controls': {mode: ref(plan['source_copy_adapter']['controls'][mode]) for mode in MODES},
            'adapter_plan': ref(upstream['adapter_plan']), 'derived_outputs': upstream['derived_outputs'],
            'ref_bound_sources': upstream['ref_bound_sources'], 'transition': chain_transition,
            'raw606_original_hold_count': 5, 'source_copy_remaining_hold_count': 1,
            'raw606_original_passed': False, 'historical_gap_acknowledged_by_source_copy_adapter': False}
    after, after_stats = sources.snapshot(original_plan['inventory_scopes'], excluded)
    require(after == before and after_stats == before_stats, 'Source changed during acknowledgment')
    sources.unchanged()
    verify_invocation()
    files[RESULT_NAME] = dump(report)
    def before_commit():
        # Derived products may be large. Recheck originals after those writes,
        # then commit the success report last. Failure leaves no success report.
        final_excluded = set(excluded)
        absolute_out = Path(os.path.abspath(out))
        candidates = [(label, root) for label, root in sources.roots.items()
                      if absolute_out.is_relative_to(root)]
        if candidates:
            label, root = max(candidates, key=lambda item: len(item[1].parts))
            output_prefix = sources.normalize(label + '/' + absolute_out.relative_to(root).as_posix())
            final_excluded.update(output_prefix + '/' + name for name in files)
            final_excluded.add(output_prefix + '/' + REPORT_PENDING_NAME)
        final_snapshot, final_stats = sources.snapshot(original_plan['inventory_scopes'], final_excluded)
        require(final_snapshot == before and final_stats == before_stats, 'Source changed before report commit')
        sources.unchanged()
        verify_invocation()
    write_fresh_bundle(out, files, before_commit=before_commit)
    return report


def main():
    os.umask(0o077)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--plan', required=True, type=Path)
    ap.add_argument('--plan-sha256', required=True)
    ap.add_argument('--root', action='append', required=True)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    own, own_id, own_stat = read_path(Path(__file__))
    test_path = Path(__file__).parent / 'test_metadata_gap_adapter.py'
    test, test_id, test_stat = read_path(test_path)
    raw, plan_id, plan_stat = read_path(args.plan)
    require(plan_id['sha256'] == args.plan_sha256, 'Adapter plan SHA differs')
    plan = parse(raw)
    roots = {}
    for entry in args.root:
        label, separator, path = entry.partition('=')
        require(separator and label not in roots, 'Duplicate or malformed root')
        roots[label] = Path(path)
    original_plan_ref = plan['original_plan']
    # Bootstrap exact original plan without imports or execution of its source.
    root_label, separator, rel = safe(original_plan_ref['source_relative_path']).partition('/')
    require(separator and root_label in roots, 'Original plan root differs')
    plan_raw, plan_actual, _ = read_path(roots[root_label] / rel)
    require(same(original_plan_ref, plan_actual), 'Original plan exact binding differs')
    sources = Sources(roots, parse(plan_raw)['logical_alias_prefixes'])
    def logical(path):
        path = Path(os.path.abspath(path))
        candidates = [(label, root) for label, root in sources.roots.items() if path.is_relative_to(root)]
        require(candidates, 'Adapter sources must be in finalized roots')
        label, root = max(candidates, key=lambda item: len(item[1].parts))
        return sources.normalize(label + '/' + path.relative_to(root).as_posix())
    own_binding = {'source_relative_path': logical(Path(__file__)), **own_id}
    test_binding = {'source_relative_path': logical(test_path), **test_id}
    plan_binding = dict(plan_id)
    try:
        plan_binding['source_relative_path'] = logical(args.plan)
    except ValueError:
        plan_binding['external_invocation_metadata'] = True
    sources.data(own_binding); sources.data(test_binding)
    # Out must not overlap any existing source; final creation uses O_EXCL semantics.
    require(not os.path.lexists(args.out), 'Fresh output directory required')
    def verify_invocation():
        for path, initial, initial_stat in [(Path(__file__), own_id, own_stat),
                                           (test_path, test_id, test_stat), (args.plan, plan_id, plan_stat)]:
            _, current, current_stat = read_path(path, keep=False)
            require(same(initial, current) and initial_stat == current_stat, 'Invocation source changed')
    report = run(plan, sources, plan_binding, args.out, own_binding, test_binding, verify_invocation)
    print(json.dumps({'passed': report['passed'], 'gap_acknowledged': True,
                      'all_historical_retained': False, 'model_go': False}, allow_nan=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
        print('REFUSED: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
        raise SystemExit(2)
