# AEUST Youxiang independent QA preparation

These are fresh-task tool inputs, not a model GO. No prior model counts, numerical exceptions, results, source GO, or physical-print assurance are inherited.

The 28 current sources are copied byte-identically from the author and compared against HDUT final revised tools. Twenty-five are unchanged. Three have only explicitly enumerated scope/error-message strings changed; executable Python AST is identical after these exact string normalizations. The C++ original-face sampler remains byte-identical. Full before/after diffs and SHA-256 mappings are retained in audit/.

Fixed gates: original raw binary STL with stored normals and exact-coordinate topology; one oriented surface; ten original-normal samples for every original triangle with complete actual C++ hexadecimal descriptors; 0.8 mm first-solid-chord threshold. XY sections at 0.2 mm pitch with offsets 0.031, 0.071, 0.137 mm; every individual Polygon assessed with 0.4 mm erosion/opening radius and 1% maximum loss, no component split. All closed-AABB overlapping original triangle pairs, including adjacent and coplanar triangles, require exact contacts. No mesh repair, changed ray, shifted sample, tolerance relaxation, average waiver, or discarded flag is allowed. Original strict=false is preserved.

Final frozen source reconstruction must reproduce original STL and color-region bytes. Complete used scene state includes mesh/material assignments, shader scalar state, sockets/links, Noise TexMapping and ColorMapping/ramp, camera/lighting/world/render/visibility/collection state. One independent nine-view replay uses the exact saved Blend, CPU Cycles at 64 samples with one thread and no denoising (installed build has no OIDN). Seven exterior projections remain ORTHO/50 mm; two detail views PERSP/20 mm. View names are schema identifiers, not geographic direction claims.

PNG comparison permits only the established privacy/time text-key cleanup; IDAT, decoded RGBA, color and every surviving complete chunk must remain identical. Raw original PNG hashes stay bound. No visual retouching or re-encoding is accepted.

All heavy geometry/Blender stages use the author shared qa/.heavy.lock and the lowest allowed CPU with numerical thread counts one. Final candidate execution waits for author freeze and exact-artifact source-appearance GO. Normal/-O synthetic controls are independent fresh runs and cannot substitute for candidate gates. Any narrow case postflight branch will be bound to the final independently measured STL and complete exact original-ray evidence, never prior flags or count assumptions.

Public candidates are allowlisted scientific reports, full losslessly compressed raw data, verified sources, indexed safe-replay controls and metadata-cleaned images. Reference imagery, routine logs, historical attempts and private paths stay outside the public bundle with exact private restore coverage. All author inputs remain read-only.

Architectural limits: early representative exterior reconstructed from source images; dimensions are estimates, not survey measurements or a claimed exact scale. Two courtyards, nonparallel twin wings, two end frames and the glass box remain source-critical geometry. No physical print has been tested.
