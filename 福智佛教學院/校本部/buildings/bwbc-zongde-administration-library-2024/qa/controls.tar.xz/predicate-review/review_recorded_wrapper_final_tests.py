"""Small copied-fixture tests for the original-run descriptor CLI.
Only the 28-triangle synthetic glide fixture is read, never a real model.
"""
from pathlib import Path
from fractions import Fraction as F
import contextlib,csv,gzip,hashlib,io,json,lzma,shutil,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'wrapper-snapshot-final'))
import diagnose_recorded_cpp_rays as m
SOURCE=ROOT.parent/'audit/original-hex-glide'
MODE='optimized' if sys.flags.optimize else 'normal'
BASE=ROOT/f'wrapper-tests-final-{MODE}';BASE.mkdir()
rows=[]
def save_json(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def check(name,cond,**data):
 if not cond:raise RuntimeError(name)
 rows.append(dict(test=name,passed=True,**data))
def prepare(name):
 directory=BASE/name;directory.mkdir();shutil.copy2(SOURCE/'fixture.stl',directory/'fixture.stl')
 source=SOURCE/'normal'
 for sourcefile,target in [(source/'raw/raw-mesh-check.json','raw.json'),(source/'intersections.json','intersections.json'),(source/'dense/dense-check.json','dense.json'),(source/'dense/dense-flagged-samples.json.gz','flags.json.gz'),(source/'dense/dense-original.csv.xz','dense-original.csv.xz')]:shutil.copy2(sourcefile,directory/target)
 return directory

def rewrite_flags(directory,fn):
 with gzip.open(directory/'flags.json.gz','rt') as f:flags=json.load(f)
 fn(flags)
 with gzip.open(directory/'flags.json.gz','wt') as f:json.dump(flags,f)
 p=directory/'dense.json';report=json.loads(p.read_text());report['flagged_samples_sha256']=m.sha(directory/'flags.json.gz');save_json(p,report)

def rewrite_csv(directory,fn):
 p=directory/'dense-original.csv.xz'
 with lzma.open(p,'rt',newline='') as f:reader=csv.DictReader(f);fields=reader.fieldnames;records=list(reader)
 records=fn(records)
 text=io.StringIO(newline='');writer=csv.DictWriter(text,fieldnames=fields);writer.writeheader();writer.writerows(records);decoded=text.getvalue().encode()
 p.write_bytes(lzma.compress(decoded))
 report=json.loads((directory/'dense.json').read_text());report['csv_compressed_sha256']=m.sha(p);report['uncompressed_csv_sha256']=hashlib.sha256(decoded).hexdigest();save_json(directory/'dense.json',report)

def rewrite_json(directory,name,fn):
 p=directory/name;report=json.loads(p.read_text());fn(report);save_json(p,report)

def rewrite_descriptor_both(directory,fn):
 rewrite_flags(directory,lambda flags:fn(flags[0]['original_cpp_row']))
 def apply(records):
  for r in records:
   if r['face']=='15' and r['sample']=='0':fn(r)
  return records
 rewrite_csv(directory,apply)

original_classify=m.classify

def run_case(name,mutate=None,late=False,expected_success=False):
 directory=prepare(name)
 if mutate:mutate(directory)
 if late:
  def altered(*args):
   result=original_classify(*args)
   with (directory/'flags.json.gz').open('ab') as f:f.write(b'late-mutation')
   return result
  m.classify=altered
 else:m.classify=original_classify
 sys.argv=['diagnose_recorded_cpp_rays.py','--stl',str(directory/'fixture.stl'),'--flags',str(directory/'flags.json.gz'),'--dense-report',str(directory/'dense.json'),'--raw-report',str(directory/'raw.json'),'--intersections-report',str(directory/'intersections.json'),'--expected-sha256',m.sha(directory/'fixture.stl'),'--out',str(directory/'result')]
 with contextlib.redirect_stdout(io.StringIO()):code=m.main()
 report=json.loads((directory/'result/exact-recorded-ray-summary.json').read_text())
 if expected_success:
  check(name,code==0 and report['completed'] and report['all_selected_rays_exactly_classified'] and report['all_selected_first_chords_ge_0p8mm'] and report['original_numerical_strict_passed'] is False,exit_code=code)
  check('full_original_csv_coverage_verified',report['full_original_csv_rows_verified']==280 and report['full_original_csv_exact_face_sample_coverage'] is True)
  with gzip.open(directory/'result/exact-recorded-ray-details.jsonl.gz','rt') as f:verified_row=json.loads(next(f))
  check('verified_cli_attaches_provenance',verified_row.get('original_run_lossless_descriptor_used') is True)
 else:
  check(name,code==1 and not report['all_selected_rays_exactly_classified'] and not report['all_selected_first_chords_ge_0p8mm'],exit_code=code,completed=report['completed'],error=report.get('error'))
  if name=='late_input_mutation':check('late_input_mutation_clears_all_completion_flags',not report['completed'] and not report['all_original_inputs_and_sources_unchanged'])

run_case('original_glide_baseline',expected_success=True)
run_case('missing_original_hex',lambda d:rewrite_flags(d,lambda flags:flags[0]['original_cpp_row'].pop('origin_x_hex')))
run_case('hex_row_identity_mismatch',lambda d:rewrite_flags(d,lambda flags:flags[0]['original_cpp_row'].__setitem__('origin_x_hex','0x1p+0')))
run_case('compressed_hash_mismatch',lambda d:(d/'dense-original.csv.xz').write_bytes((d/'dense-original.csv.xz').read_bytes()+b'x'))
run_case('decoded_hash_mismatch',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('uncompressed_csv_sha256','0'*64)))
run_case('flags_hash_mismatch',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('flagged_samples_sha256','0'*64)))
run_case('dense_stl_mismatch',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('stl_sha256','0'*64)))
run_case('raw_stl_mismatch',lambda d:rewrite_json(d,'raw.json',lambda r:r.__setitem__('stl_sha256','0'*64)))
run_case('raw_failed',lambda d:rewrite_json(d,'raw.json',lambda r:r.__setitem__('passed',False)))
run_case('raw_missing_vertex_link_check',lambda d:rewrite_json(d,'raw.json',lambda r:r['checks'].pop('exact_coordinate_vertex_links_single_cycles')))
run_case('intersection_failed',lambda d:rewrite_json(d,'intersections.json',lambda r:r.__setitem__('passed',False)))
run_case('intersection_incomplete',lambda d:rewrite_json(d,'intersections.json',lambda r:r.__setitem__('completed',False)))
run_case('intersection_wrong_final_hash',lambda d:rewrite_json(d,'intersections.json',lambda r:r.__setitem__('stl_sha256_after_check','0'*64)))
run_case('intersection_bad_pair',lambda d:rewrite_json(d,'intersections.json',lambda r:r.__setitem__('bad_pair_count',1)))
run_case('intersection_broadphase_incomplete',lambda d:rewrite_json(d,'intersections.json',lambda r:r['broad_phase'].__setitem__('all_bbox_overlapping_pairs_completed',False)))
run_case('duplicate_selected_flag',lambda d:rewrite_flags(d,lambda flags:flags.append(flags[0].copy())))
run_case('empty_selected_flags',lambda d:rewrite_flags(d,lambda flags:flags.clear()))
run_case('duplicate_selected_csv_row',lambda d:rewrite_csv(d,lambda records:records+[r for r in records if r['face']=='15' and r['sample']=='0']))
run_case('missing_selected_csv_row',lambda d:rewrite_csv(d,lambda records:[r for r in records if not (r['face']=='15' and r['sample']=='0')]))
run_case('zero_direction',lambda d:rewrite_descriptor_both(d,lambda r:r.update(dx_hex='0x0p+0',dy_hex='0x0p+0',dz_hex='0x0p+0')))
run_case('nonfinite_origin',lambda d:rewrite_descriptor_both(d,lambda r:r.__setitem__('origin_x_hex','nan')))
run_case('late_input_mutation',late=True)
run_case('raw_dense_inventory_mismatch',lambda d:rewrite_json(d,'raw.json',lambda r:r['checker_sources_sha256'].__setitem__('check_raw_mesh.py','0'*64)))
run_case('exact_checker_inventory_mismatch',lambda d:rewrite_json(d,'intersections.json',lambda r:r['tools'].__setitem__('source_sha256','0'*64)))
run_case('reported_face_count_mismatch',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('original_triangles',27)))
run_case('reported_sample_count_mismatch',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('samples',279)))
run_case('reported_flag_count_mismatch',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('flagged_sample_count',2)))
run_case('csv_nonlocal_basename',lambda d:rewrite_json(d,'dense.json',lambda r:r.__setitem__('csv_file','../dense-original.csv.xz')))
run_case('selected_face_out_of_range',lambda d:rewrite_flags(d,lambda r:r[0].__setitem__('original_face_index',28)))
# Retest all three malformed-full-CSV counterexamples against the correction.
run_case('selected_only_csv_rejected',lambda d:rewrite_csv(d,lambda records:[r for r in records if r['face']=='15' and r['sample']=='0']))
run_case('unselected_duplicate_csv_rejected',lambda d:rewrite_csv(d,lambda records:records+[records[0].copy()]))
def bad_unselected_key(records):
 records[0]['face']='999999';return records
run_case('unselected_out_of_range_csv_rejected',lambda d:rewrite_csv(d,bad_unselected_key))
m.classify=original_classify

# Geometry helper checks use deliberately synthetic descriptors, not run identity.
def cube():
 v=[(0,0,0),(10,0,0),(10,10,0),(0,10,0),(0,0,10),(10,0,10),(10,10,10),(0,10,10)];f=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(1,2,6),(1,6,5),(2,3,7),(2,7,6),(3,0,4),(3,4,7)];return [tuple(v[i] for i in face) for face in f]
# Ray from (6,3,-1/16), direction proportional to (3,0,5). Source is bottom
# triangle 0; it exits x=10. Entry x=483/80, travel dx=317/80; dy=0; dz=317/48.
desc=dict(face='0',sample='0',origin_x_hex='0x6p+0',origin_y_hex='0x3p+0',origin_z_hex='-0x1p-4',dx_hex='0x3p-4',dy_hex='0x0p+0',dz_hex='0x5p-4')
expected=F(317,80)**2+F(317,48)**2
for scale in [1,8]:
 triangles=[tuple(tuple(scale*x for x in p) for p in t) for t in cube()];mesh=m.Mesh(triangles,scale);result=m.classify(mesh,desc,desc)
 check('nonunit_oblique_direction_physical_chord',F(result['conservative_first_solid_chord_squared_mm2_exact'])==expected,lattice_scale=scale,squared=result['conservative_first_solid_chord_squared_mm2_exact'],note='Synthetic helper input checks geometry only, not descriptor provenance')
 check('standalone_helper_does_not_assert_provenance','original_run_lossless_descriptor_used' not in result and result['supplied_lossless_descriptor_line_classified'] is True,lattice_scale=scale)
# A direct geometric short-slab check remains exactly classified but fails threshold.
thin=[tuple((p[0]*2,p[1]*2,p[2]//10) for p in t) for t in cube()]
thin_desc=dict(face='0',sample='0',origin_x_hex='0x6p+0',origin_y_hex='0x3p+0',origin_z_hex='-0x1p-4',dx_hex='0x0p+0',dy_hex='0x0p+0',dz_hex='0x1p+0')
thin_result=m.classify(m.Mesh(thin,2),thin_desc,thin_desc)
check('exact_half_mm_slab_retains_classification_but_fails_threshold',thin_result['exact_classification_completed'] and thin_result['conservative_first_solid_chord_squared_mm2_exact']=='1/4' and thin_result['conservative_first_solid_chord_ge_0p8mm'] is False)
# Original glide report files are read-only; compare modes without re-running.
observed=[]
for mode in ['normal','optimized']:
 path=SOURCE/mode/'exact-original-ray-diagnosis'
 report=json.loads((path/'exact-recorded-ray-summary.json').read_text())
 with gzip.open(path/'exact-recorded-ray-details.jsonl.gz','rt') as f:record=json.loads(next(f))
 states=[x['state'] for x in record['classified_open_intervals']]
 check('original_glide_report_semantics',report['original_numerical_strict_passed'] is False and states==['outside','inside','boundary','boundary','outside'] and record['conservative_first_solid_chord_squared_mm2_exact']=='400',mode=mode,states=states)
 observed.append(record)
check('normal_optimized_original_glide_rows_equal',observed[0]==observed[1])
summary=dict(passed=True,case_count=len(rows),optimization_level=sys.flags.optimize,wrapper_sha256=m.sha(Path(m.__file__)),core_sha256=m.sha(Path(m.__file__).with_name('exact_ray_diagnosis.py')),cases=rows)
save_json(ROOT/f'wrapper-review-final-{MODE}.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='cases'}))
