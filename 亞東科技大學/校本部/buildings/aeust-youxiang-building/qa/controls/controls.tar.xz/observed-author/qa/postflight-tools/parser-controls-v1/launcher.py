import sys,os,json,importlib,unittest,pathlib
p=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(p.parent));m=importlib.import_module(p.stem);s=unittest.defaultTestLoader.loadTestsFromModule(m);r=unittest.TextTestRunner(verbosity=2).run(s)
out.write_text(json.dumps({'passed':r.wasSuccessful(),'optimization_level':sys.flags.optimize,'cpu_affinity':sorted(os.sched_getaffinity(0)),'test_count':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped)},indent=2)+'\n')
raise SystemExit(0 if r.wasSuccessful() else 1)
