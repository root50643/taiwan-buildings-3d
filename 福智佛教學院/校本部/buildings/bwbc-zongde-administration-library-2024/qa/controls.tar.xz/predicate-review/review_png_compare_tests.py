"""Independent tiny PNG tests. No Blender or author inputs are used."""
import argparse, hashlib, importlib.util, itertools, json, pathlib, struct, sys, zlib
from png_fixture_helpers import *

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--module',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    source=pathlib.Path(args.module).resolve();out=pathlib.Path(args.out).resolve();out.mkdir(parents=True,exist_ok=False)
    spec=importlib.util.spec_from_file_location('review_png_target',source);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    cases=[]
    def comparison(name,a,b,expected=True):
        fa=out/(name+'-a.png');fb=out/(name+'-b.png');fa.write_bytes(a);fb.write_bytes(b)
        row={'name':name,'expected':expected}
        try:
            result=mod.compare(fa,fb,hashlib.sha256(a).hexdigest());row.update(observed=result['passed'],result=result)
            row['ok']=row['observed'] is expected
        except Exception as exc:row.update(ok=not expected,observed='rejected',error=type(exc).__name__+': '+str(exc))
        cases.append(row)
    def rejected(name,data):
        file=out/(name+'.png');file.write_bytes(data);row={'name':name,'expected':'reject'}
        try:result=mod.compare(file,file,hashlib.sha256(data).hexdigest());row.update(ok=False,observed='accepted',result=result)
        except Exception as exc:row.update(ok=True,observed='rejected',error=type(exc).__name__+': '+str(exc))
        cases.append(row)
    base=png()
    for filters in itertools.product(range(5),repeat=HEIGHT):
        comparison('filters-'+''.join(map(str,filters)),base,png(filters=filters))
    for split in [0,1,2,3,7,10,1000]:comparison('idat-split-'+str(split),base,png(split=split))
    for level in [0,1,9]:comparison('compression-'+str(level),base,png(level=level))
    for channel in range(4):
        changed=bytearray(PIXELS);changed[channel]^=1
        comparison('changed-channel-'+str(channel),base,png(bytes(changed)),False)
    transparent=bytes([30,40,50,0]*9);changed=bytes([30,40,51,0]*9)
    comparison('changed-transparent-rgb',png(transparent),png(changed),False)
    comparison('same-bytes-different-dimensions',base,png(PIXELS,1,9,filters=(0,)),False)
    allowed=['Date','RenderTime','cycles.ViewLayer.total_time','cycles.ViewLayer.render_time','cycles.ViewLayer.synchronization_time']
    for key in allowed:
        slug=key.replace('.','-')
        comparison('allowed-'+slug,png(before=[text(key,'1')]),png(before=[text(key,'2')]))
        comparison('missing-'+slug,png(before=[text(key,'1')]),base,False)
        rejected('duplicate-'+slug,png(before=[text(key,'1'),text(key,'2')]))
    comparison('all-five-allowed',png(before=[text(k,'old') for k in allowed]),png(before=[text(k,'new') for k in allowed]))
    for key in ['File','Software','date','Date ','RenderTime.extra','cycles.ViewLayer.total_time.extra','cycles.OtherLayer.total_time']:
        comparison('strict-key-'+key.replace(' ','_').replace('.','-'),png(before=[text(key,'one')]),png(before=[text(key,'two')]),False)
    for name,kind,a,b in [
        ('gamma',b'gAMA',struct.pack('>I',45455),struct.pack('>I',45456)),
        ('chromaticity',b'cHRM',struct.pack('>8I',31270,32900,64000,33000,30000,60000,15000,6000),struct.pack('>8I',31271,32900,64000,33000,30000,60000,15000,6000)),
        ('srgb',b'sRGB',b'\0',b'\1'),('sbit',b'sBIT',bytes([8,8,8,8]),bytes([7,8,8,8])),
        ('palette',b'PLTE',b'\0\0\0',b'\1\0\0'),('physical',b'pHYs',struct.pack('>IIB',1000,1000,1),struct.pack('>IIB',1001,1000,1)),
        ('time-not-allowlisted',b'tIME',struct.pack('>HBBBBB',2026,10,16,12,34,56),struct.pack('>HBBBBB',2026,10,16,12,34,57)),
        ('unknown-ancillary',b'vpAg',b'abc',b'abd')]:
        comparison('stable-'+name,png(before=[chunk(kind,a)]),png(before=[chunk(kind,a)]))
        comparison('changed-'+name,png(before=[chunk(kind,a)]),png(before=[chunk(kind,b)]),False)
    # A minimal ICC header/tag table, used only as opaque preserved metadata.
    icc=bytearray(132);struct.pack_into('>I',icc,0,len(icc));icc[8:12]=b'\x04\x30\0\0';icc[12:16]=b'mntr';icc[16:20]=b'RGB ';icc[20:24]=b'XYZ ';icc[36:40]=b'acsp'
    profile=b'Review\0\0'+zlib.compress(bytes(icc));profile2=b'Review\0\0'+zlib.compress(bytes(icc),0)
    comparison('stable-icc',png(before=[chunk(b'iCCP',profile)]),png(before=[chunk(b'iCCP',profile)]))
    comparison('changed-icc-compression',png(before=[chunk(b'iCCP',profile)]),png(before=[chunk(b'iCCP',profile2)]),False)
    comparison('stable-text-reorder',png(before=[text('A','a'),text('B','b')]),png(before=[text('B','b'),text('A','a')]),False)
    comparison('stable-text-phase',png(before=[text('File','same')]),png(after=[text('File','same')]),False)
    comparison('allowed-text-phase',png(before=[text('Date','same')]),png(after=[text('Date','same')]),False)
    comparison('allowed-text-reorder',png(before=[text('Date','one'),text('RenderTime','two')]),png(before=[text('RenderTime','two'),text('Date','one')]),False)
    pieces=parts(base)
    rejected('bad-signature',b'X'+base[1:]);rejected('crc-corrupt',base[:-5]+bytes([base[-5]^1])+base[-4:])
    rejected('trailing-byte',base+b'X');rejected('trailing-chunk',base+text('Comment','x'))
    rejected('truncated-chunk',base[:-1]);rejected('no-iend',assemble(pieces[:-1]));rejected('no-idat',assemble([pieces[0],pieces[-1]]))
    rejected('first-not-ihdr',SIGNATURE+text('x','y')+base[8:]);rejected('duplicate-ihdr',assemble([pieces[0],*pieces]));rejected('invalid-iend',assemble([*pieces[:-1],(b'IEND',b'x')]))
    rejected('unknown-critical',png(before=[chunk(b'ABCD',b'')]));rejected('lower-reserved-bit',png(before=[chunk(b'abcd',b'')]));rejected('nonletter-tag',png(before=[chunk(b'a1Cd',b'')]))
    compressed=pieces[1][1]
    rejected('nonconsecutive-idat',assemble([pieces[0],(b'IDAT',compressed[:3]),(b'tEXt',b'X\0Y'),(b'IDAT',compressed[3:]),pieces[-1]]))
    for name,kwargs in [('zero-width',{'width':0}),('zero-height',{'height':0}),('rgb',{'color':2}),('depth16',{'depth':16}),('interlace',{'interlace':1}),('compression-method',{'compression':1}),('filter-method',{'filter_method':1})]:
        rejected(name,SIGNATURE+ihdr(**kwargs)+b''.join(chunk(k,v) for k,v in pieces[1:]))
    for name,stream in [('zlib-extra',compressed+b'junk'),('zlib-concatenated',compressed+zlib.compress(b'x')),('zlib-truncated',compressed[:-1]),('zlib-corrupt',compressed[:-1]+bytes([compressed[-1]^1]))]:
        rejected(name,assemble([pieces[0],(b'IDAT',stream),pieces[-1]]))
    raw=filtered()
    rejected('scanline-short',png(raw=raw[:-1]));rejected('scanline-long',png(raw=raw+b'x'));rejected('filter5',png(raw=b'\5'+raw[1:]))
    malformed=[
        ('nul-text',b'tEXt',b'Date\0date\0junk'),('nul-stable-text',b'tEXt',b'File\0path\0junk'),
        ('empty-key',b'tEXt',b'\0x'),('key-leading-space',b'tEXt',b' Date\0x'),('key-control',b'tEXt',b'Fi\x01le\0x'),
        ('no-text-delimiter',b'tEXt',b'abc'),('bad-itxt',b'iTXt',b'abc'),('bad-ztxt',b'zTXt',b'abc'),
        ('bad-icc',b'iCCP',b'abc'),('icc-method',b'iCCP',b'Review\0\1'+zlib.compress(bytes(icc))),
        ('icc-extra-zlib',b'iCCP',profile+b'junk'),('zero-sbit',b'sBIT',b'\0\0\0\0'),('large-sbit',b'sBIT',b'\11\10\10\10'),('short-sbit',b'sBIT',b'\10'),
        ('zero-gamma',b'gAMA',b'\0'*4),('short-chrm',b'cHRM',b'\0'),('bad-srgb',b'sRGB',b'\4'),
        ('short-phys',b'pHYs',b'\0'),('bad-phys-unit',b'pHYs',struct.pack('>IIB',1,1,2)),
        ('trns-rgba',b'tRNS',b'\0\0'),('empty-palette',b'PLTE',b''),('odd-palette',b'PLTE',b'\0'),
        ('invalid-time',b'tIME',b'x'),('invalid-background',b'bKGD',b'x')]
    for name,kind,payload in malformed:rejected(name,png(before=[chunk(kind,payload)]))
    rejected('conflicting-srgb-icc',png(before=[chunk(b'sRGB',b'\0'),chunk(b'iCCP',profile)]))
    for kind,payload in [(b'gAMA',struct.pack('>I',45455)),(b'pHYs',struct.pack('>IIB',1,1,1))]:
        rejected('late-'+kind.decode(),png(after=[chunk(kind,payload)]))
    # Expected-file identity must fail, even when decoded pixels match.
    fa=out/'hash-check.png';fa.write_bytes(base)
    try:mod.compare(fa,fa,'0'*64);cases.append({'name':'wrong-expected-file-sha','ok':False})
    except Exception as exc:cases.append({'name':'wrong-expected-file-sha','ok':True,'error':str(exc)})
    result={'module':str(source),'module_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'optimized':not __debug__,'case_count':len(cases),'passed_count':sum(r['ok'] for r in cases),'failed':[r['name'] for r in cases if not r['ok']],'cases':cases}
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2));return 0 if not result['failed'] else 1
if __name__=='__main__':raise SystemExit(main())
