"""Synthetic source-binding/fail-closed controls for two-mode profile batching."""
from pathlib import Path
import argparse,hashlib,json,os,struct,subprocess,sys

def require(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def encode(v):return (json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
def main():
 os.umask(0o077)
 ap=argparse.ArgumentParser();ap.add_argument('--blend',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();require(not a.out.exists() and len(os.sched_getaffinity(0))==1,'Fresh output and one CPU required');a.out.mkdir();original=a.blend.read_bytes();require(sha(original)=='e3ec3b7f00c8ae33b9734a3f6d10b7bc7ab1ff24fae3f0f97349616dabe8e67a','Unexpected fixture');tool=Path(__file__).with_name('profile_control_blends.py');source=tool.read_bytes();rows=[]
 def case(name,data=original,expected=True,needle='',mutate=None,alias=False,leaf_link=False,existing=False,policy_rejected=False,fifo=False,environment=None):
  root=a.out/name;root.mkdir();inputs=root/'inputs';inputs.mkdir();fixture=inputs/'fixture.blend';fixture.write_bytes(data);sourcepath=inputs
  if alias:
   sourcepath=root/'alias';sourcepath.symlink_to(inputs,target_is_directory=True)
  if leaf_link:
   fixture.rename(inputs/'original.blend');fixture.symlink_to('original.blend')
  if fifo:fixture.rename(inputs/'original.blend');os.mkfifo(fixture)
  descriptor={'source_relative_path':'fixture/fixture.blend','bytes':len(data),'sha256':sha(data)};roster={'blend_candidates':[descriptor]}
  if mutate:mutate(roster)
  rp=root/'roster.json';rp.write_bytes(encode(roster));out=root/'profiles'
  if existing:out.mkdir();(out/'original-marker').write_bytes(b'unchanged')
  cp=subprocess.run([sys.executable,'-B',*(['-O'] if sys.flags.optimize else []),str(tool),'--roster',str(rp),'--source-root','fixture='+str(sourcepath),'--out',str(out)],capture_output=True,text=True,env=environment);(root/'stdout.txt').write_text(cp.stdout);(root/'stderr.txt').write_text(cp.stderr)
  if fifo:
   (root/'fifo-descriptor.json').write_bytes(encode({'path':'inputs/fixture.blend','type':'FIFO','mode':fixture.lstat().st_mode,'policy':'Synthetic nonblocking-open control. No payload bytes; remove the FIFO after capture and preserve this descriptor and generator source, never follow or restore it as a live endpoint.'}));fixture.unlink()
  passed=(cp.returncode==0) is expected and (expected or not needle or needle in cp.stderr);require(passed,'Batch control failed '+name)
  if expected:
   report=json.loads((out/'blend-profiles.json').read_text());require(report['passed'] is True and report['candidate_count']==1 and report['all_source_bytes_unchanged'] is True and report['both_mode_profile_equivalence_verified'] is True,'Positive batch report differs')
   if policy_rejected:require(not report['files'] and len(report['rejected'])==1 and report['rejected'][0]['policy_rejection_verified'] is True,'Expected explicit policy rejection differs')
   else:require(len(report['files'])==1 and not report['rejected'],'Expected accepted profile differs')
  if existing:require((out/'original-marker').read_bytes()==b'unchanged' and sorted(p.name for p in out.iterdir())==['original-marker'],'Existing output altered')
  rows.append({'name':name,'expected_accept':expected,'accepted':cp.returncode==0,'returncode':cp.returncode,'passed':passed,'expected_error':needle or None,'fixture_sha256':sha(data)})
 case('authentic_two_mode_profile')
 changed=bytearray(original);changed[171630]=65;case('controlled_buffer_policy_rejection',bytes(changed),policy_rejected=True)
 case('inherited_optimization_cannot_substitute_modes',environment={**os.environ,'PYTHONOPTIMIZE':'2'})
 case('nonregular_fifo_is_rejected_without_blocking',expected=False,needle='Candidate is not regular',fifo=True)
 case('symlink_source_root_rejected',expected=False,alias=True)
 case('symlink_source_leaf_rejected',expected=False,leaf_link=True)
 case('wrong_declared_identity',expected=False,needle='Candidate identity differs',mutate=lambda d:d['blend_candidates'][0].__setitem__('sha256','0'*64))
 case('duplicate_candidate',expected=False,needle='Unsafe or duplicate candidate',mutate=lambda d:d['blend_candidates'].append(dict(d['blend_candidates'][0])))
 case('unknown_source_label',expected=False,needle='Unknown candidate source',mutate=lambda d:d['blend_candidates'][0].__setitem__('source_relative_path','unknown/fixture.blend'))
 case('existing_output_untouched',expected=False,needle='Fresh output and single CPU required',existing=True)
 bad=bytearray(original);at=12
 while at+24<=len(bad):
  code,n,addr,sdna,count=struct.unpack_from('<4sIQII',bad,at)
  if at+24<=171624<at+24+n:struct.pack_into('<I',bad,at+16,2**32-1);break
  at+=24+n
 else:raise RuntimeError('Expected control block missing')
 case('unclassified_decoder_error_is_not_policy_success',bytes(bad),expected=False,needle='Unclassified decoder/infrastructure failure')
 require(a.blend.read_bytes()==original and tool.read_bytes()==source,'Original input/source changed');report={'passed':True,'optimization_level':sys.flags.optimize,'case_count':len(rows),'cases':rows,'source_sha256':sha(source),'test_source_sha256':sha(Path(__file__).read_bytes()),'base_blend_sha256':sha(original),'scope':'Synthetic batch source-identity, two-mode profile and explicit policy-rejection controls only. No geometry or model acceptance.'};(a.out/'results.json').write_bytes(encode(report));print(json.dumps({'passed':True,'case_count':len(rows)}))
if __name__=='__main__':main()
