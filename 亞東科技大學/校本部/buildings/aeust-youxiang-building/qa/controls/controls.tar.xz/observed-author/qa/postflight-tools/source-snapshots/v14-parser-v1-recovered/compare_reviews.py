#!/usr/bin/env python3
"""Compare two independently executed normal/-O author reviews; retain strict=false."""
import argparse,json,pathlib,sys
from review_bounded_evidence import Evidence,require,write,STL_SHA

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--normal',type=pathlib.Path,required=True);p.add_argument('--optimized',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args();require(not a.out.exists(),'Comparison output must be new');e=Evidence();result={'bounded_supplemental_pass':False,'original_numerical_strict_passed':False,'independent_qa_pass':False,'stl_sha256':STL_SHA,'scope':'Author review comparison only; independent QA remains required.'}
    try:
        reports=[]
        for path,opt in [(a.normal,0),(a.optimized,1)]:
            r=e.read(path);require(r.get('schema')=='aeust-v14-author-bounded-supplement-v1' and r.get('stl_sha256')==STL_SHA,'Wrong author review schema/input')
            for key in ('review_completed','bounded_supplemental_pass','all_original_flags_exactly_resolved','normal_optimized_scientific_evidence_identical','all_bound_inputs_unchanged'):require(r.get(key) is True,'Incomplete/failed author review')
            require(r.get('original_numerical_strict_passed') is False and r.get('independent_qa_pass') is False and r.get('unresolved') is False,'Review scope/strict state differs')
            require(type(r.get('review_optimization_level')) is int and r['review_optimization_level']==opt and not {'error','error_type'}.intersection(r),'Reviewer mode/error differs')
            require(set(r.get('modes',{}))=={'normal','optimized'} and r['modes']['normal']==r['modes']['optimized'],'Original mode science differs')
            inv=r.get('evidence_inventory');require(type(inv) is dict and inv,'Review evidence inventory missing')
            for name,meta in inv.items():p=e.track(name,meta['sha256']);require(type(meta.get('bytes')) is int and p.stat().st_size==meta['bytes'],'Bound evidence bytes differ')
            reports.append(r)
        a0={k:v for k,v in reports[0].items() if k not in ('review_optimization_level','cpu_affinity')};a1={k:v for k,v in reports[1].items() if k not in ('review_optimization_level','cpu_affinity')};require(a0==a1,'Reviewer normal/-O semantic evidence differs');require(e.unchanged(),'Review inputs changed')
        result.update(bounded_supplemental_pass=True,review_modes_identical=True,original_flags_count=reports[0]['original_flags_count'],science=reports[0]['modes']['normal'])
    except Exception as err:result.update(error_type=type(err).__name__,error=str(err))
    result['evidence_inventory']=e.files;write(a.out,result);print(json.dumps({'bounded_supplemental_pass':result['bounded_supplemental_pass'],'report':str(a.out)}));return 0 if result['bounded_supplemental_pass'] else 1
if __name__=='__main__':raise SystemExit(main())
