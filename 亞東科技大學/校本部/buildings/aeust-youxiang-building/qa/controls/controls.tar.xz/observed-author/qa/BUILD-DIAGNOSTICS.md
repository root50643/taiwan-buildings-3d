# 製作紀錄

v0為宏觀殼source-review blockout。所有座標為相對模型毫米。根據12F描讀採A長翼、B不平行短翼、C街端、D校園端與E/F跨接，兩孔分開。先四面原創圖比對，未細化為成品。

已知下一宏觀修正：D下段較小、上盒懸挑；校園地面入口；兩端上部帶孔；相機更貼近英城街照的觀察角度。v0空白牆是低模階段，不表示將證據已知立面省略到成品。

所有舊版保留；不覆寫STL、模型快照或原QA報告。修正原碼後輸出新版本。

v2原始CSG轉float32 STL前觸發非退化硬失敗，沒有輸出不合格STL或刪除三角形。定位為C下橫玻璃與A廊邊交界的一個微小共線殘片：x坐標差<0.000001mm，float32完全共線，詳細原64/32坐標保存在v2-export-degenerate-diagnostic.json。v3在原始CSG建構末端把simplify容差由1e-7調為1e-5mm（小於目前坐標下float32量化級），不填洞、不改STL、不做輸出修補；原失敗程式與log保留。v3原始二進位STL待完整QA。

v4按獨立審查與早期原照調整兩端立面分段，避免用13層等距概念替代已見外觀：D校園端採7條普通圓角窗帶（含盒底陰影1條），下方高玻璃約兩層，上盒降低到底82mm；C街角採10個綠色圓角段、9道內部分帶，上下白色體另分段。所有高程仍為模型估值，不把圖像像素當真實尺寸。

## v3 original-section failure, retained 2026-10-17

The unchanged section checker sampled 1,785 layers and 23,459 original Polygons. It rejected 1,370 layers / 20,786 Polygons. The complete details and failure geometry remain in `v3-preflight/sections`; this is not a passing result. Most failures are the per-Polygon 1% opening-loss rule on 1.8 mm rectangular column corners. Further failures identify a small neck at the A outer glazing projection and upper connector / street-hole intersections; these are being diagnosed from the original triangle sections before an original-CAD revision. No thresholds, sample schedule, contours or emitted STL are repaired or exempted.

v4 changes source-visible elevation segmentation only: D has seven ordinary bands above a tall lower glazing band; C has ten green intervals, with separate white upper/lower bodies. v4 remains an intermediate candidate, not a final freeze.

## Original-CAD corrections v5–v10

- v5 rounded column corners, separated A piers from paired recesses, preserved the A vertical glazing root, and confined E/C perforations to those components. The critical-section diagnostic found only two remaining sampled failures; raw topology exposed ten tiny enclosed pockets at the terminal A/C join. These failures remain recorded.
- v6 added local plan fillets and rooted terminal gallery piers. Its float32 exporter rejected ten collapsed triangles around the last B column / layered C rounded-return intersection; no STL was emitted. v7's 0.0001 mm CSG tolerance and v8's removal of per-part rounding did not resolve export. All failed source/parameters and logs remain. The larger v7 tolerance is not retained.
- v9 replaced C's near-parallel estimated quadrilateral with a common-axis 9.6 mm strip and consistent rounded return segments. Original corner displacement is under 0.3 mm, explicitly a printing idealization. Export succeeded and all 22 diagnostic levels passed, but raw shell diagnosis found one remaining ~0.12 mm-wide enclosed pocket between terminal A pier and street corner.
- v10 increased the terminal A root pier's X extent to197.2 mm, overlapping that incidental internal seam. This changes an estimated internal join, not either source-significant courtyard or the high street opening. Original STL is one shell and the 22-level diagnostic passes. Full unchanged geometry checks remain pending; no final-pass claim follows from this diagnostic subset.

## v10 complete dense result and v11 original-CAD response

v10 records all475,720 original rays:41 numerical chords below0.8mm and44 flagged samples, strict=false. Thirty-six short rays are at the D tall-core window edge, chord0.784057mm; five are at B's slightly acute terminal outer corner, minimum0.148021mm. The original CSV, short list and flags remain unchanged and are included in Library checkpoint version1.

v11 moves the D core's estimated local window interval fromu1.5–4.5 tou2.5–5.5mm and rounds B's original main-footprint corners by0.8mm. All ground solids now overlap the integral base by0.1mm rather than starting0.1mm above it; genuine ground apertures still open to the base. No ray threshold or sampling changed. v11 raw topology passes and22 diagnostic levels /258Polygons pass; complete dense and full section checks are pending. No final-pass claim is made.

## v12 to v13 material-only source correction

The source reviewer identified a broad white B end plane behind the street giant frame that should represent recessed high glazing. v12 rendering stopped with five completed views; the queued full-QA process was canceled before starting. v13 assigns original green material only to existing B outward end-plane triangles fully within relative z27–94 mm. No triangles, solids, aperture or courtyard geometry change. Final STL identity will be checked; all nine images must be newly bound.

## v13 to v14 material-selection completion

v13 strict B-end-plane selection colored only the narrow exposed portion. The dominant white visible plane was traced to the existing rooted B terminal pier at x191.9, y-45.205..-35.708. v14 additionally colors only its existing +X-facing triangles fully within relative z27–94 and the stated Y interval. Floor ends, other normals and real apertures remain unchanged. v12/v13/v14 STL hashes are expected identical and checked bytewise.

## v14 completed nine-image framing HOLD; v15 camera-only revision

All nine v14 originals and their complete manifest remain intact. The author and source reviewer found courtyard-arcade almost filled by the nearby existing high-glazing plane, so it did not communicate the small courtyard. No geometry or material fault was found. v15 changes only that camera from (181,-30,62)→(201,-37,58) to (181,-28,104)→(185,-32,43), still PERSP20mm, CPU64, with parameters revision recorded. The initial seven exterior views and courtyard-gallery were source-accepted. v14 full geometry was never launched. New probe then complete nine-image provenance is required; final source GO remains pending.

## Completed v11 diagnostic result (not final v15 science)

The subsequently completed v11 dense diagnostic records 477,540 original rays, zero numerical chords below 0.8 mm, a minimum first chord of 0.8499984741210938 mm and 26 numerical crossing/parity flags. Original strict/pass remain false. Its complete 82,919,346-byte compressed CSV and flags are retained. The v11 22-level section diagnostic is still only a subset; none of these records substitutes for v15's fresh full run.

## v15 formal source freeze and original full-QA start

All nine original v15 renders completed on 2026-10-17 at 06:22 UTC. The final source reviewer inspected every image and separately verified the saved scene's 47,770 original triangles, in exact STL order and coordinates, with identity transform, no modifiers and no photo textures. SOURCE-APPEARANCE-GO is bound in qa/source-review/final-v15; it certifies only the stated source/appearance scope. The 20-file original artifact freeze is qa/V15-FINAL-ARTIFACT-FREEZE.json. Fresh author normal/-O full QA began at 06:23 UTC through the actual-process capture wrapper. Manufacturing acceptance remains pending.

## v15 original full science, exact recorded rays, and author aggregation correction

Normal and optimized full runs completed with all raw, 1,785-section, original-pair intersection and control gates passing. Both original dense runs retained 26 crossing/parity flags and zero short rays; generic full exit 1 and strict=false are unchanged. Every actual recorded flagged ray was then exactly classified, without a limit or reconstructed line; both exact processes exited 0 with identical detail bytes.

The first author metadata review failed closed because it used iterative += for per-layer totals, unlike the original producer's Python 3.12 builtin sum. At layer 0.031:15 the first discrepancy was one ULP. Both original runs' 3,570 area/loss totals exactly match the original-order builtin sum. Only the new review helper changed, retaining == with no tolerance; original science, core tools and model are untouched. Old tested sources, failed review, independent diagnosis and new 154 controls are retained. Fresh r2 normal/-O reviews and their comparison pass the separate bounded supplement. The author source/scene preflight and 24 final-scene controls pass; independent full QA and the sole formal nine-view replay remain pending.
