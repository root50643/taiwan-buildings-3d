"""Small author reviewer parser controls. No model or geometry computation."""
import copy,json,pathlib,tempfile,unittest
import review_bounded_evidence as r
class Parsers(unittest.TestCase):
    def reject(self,fn,*args):
        with self.assertRaises((RuntimeError,KeyError,TypeError,ValueError)):fn(*args)
    def full(self):
        return {'completed':True,'passed':False,'strict_passed':False,'stl_sha256':r.STL_SHA,'expected_longest_mm':219,'tool_sources_sha256':{'tool':'digest'},'checks':{'both_modes_strictly_pass':False,'normal_optimized_scientific_evidence_identical':False,'original_stl_unchanged':True,'tool_sources_unchanged':True},'modes':{m:{'strict_passed':False,'error_type':'QAError','error':'Standard aggregate did not strictly pass','child_exit_codes':{'standard':1,'intersections':0,'intersection-controls':0,'dense-evidence':0}} for m in ('normal','optimized')}}
    def ex(self):
        return {**{k:True for k in r.EXACT_TRUE},'optimization_level':0,'original_numerical_strict_passed':False,'full_original_csv_rows_verified':r.RAYS,'selected_samples':7,'total_flagged_samples':7,'input_and_tool_sha256':{'stl':'digest'}}
    def test_full_expected_failure(self):r.validate_full(self.full(),{'tool':'digest'},set())
    def test_full_incomplete(self):
        x=self.full();x['completed']=False;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_strict_laundered(self):
        x=self.full();x['strict_passed']=True;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_pass_nonboolean(self):
        x=self.full();x['passed']=0;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_unexpected_error(self):
        x=self.full();x['modes']['normal']['error']='Missing evidence';self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_wrong_exit(self):
        x=self.full();x['modes']['normal']['child_exit_codes']['standard']=0;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_bool_exit(self):
        x=self.full();x['modes']['optimized']['child_exit_codes']['intersections']=False;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_missing_stage(self):
        x=self.full();del x['modes']['optimized']['child_exit_codes']['dense-evidence'];self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_extra_stage(self):
        x=self.full();x['modes']['normal']['child_exit_codes']['pretend']=0;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_missing_mode(self):
        x=self.full();del x['modes']['optimized'];self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_extra_mode(self):
        x=self.full();x['modes']['other']={};self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_source_hash(self):self.reject(r.validate_full,self.full(),{'tool':'wrong'},set())
    def test_full_stl_hash(self):
        x=self.full();x['stl_sha256']='0'*64;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_full_check_extra(self):
        x=self.full();x['checks']['pretend']=True;self.reject(r.validate_full,x,{'tool':'digest'},set())
    def test_exact_positive(self):r.validate_exact_summary(self.ex(),0,7,{'stl':'digest'})
    def test_exact_missing_true_field(self):
        for k in r.EXACT_TRUE:
            x=self.ex();del x[k];self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_nonboolean(self):
        for k in r.EXACT_TRUE:
            x=self.ex();x[k]=1;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_wrong_mode(self):self.reject(r.validate_exact_summary,self.ex(),1,7,{'stl':'digest'})
    def test_exact_boolean_mode(self):
        x=self.ex();x['optimization_level']=False;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_wrong_hash(self):self.reject(r.validate_exact_summary,self.ex(),0,7,{'stl':'wrong'})
    def test_exact_extra_hash(self):
        x=self.ex();x['input_and_tool_sha256']['extra']='x';self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_omitted_flag(self):
        x=self.ex();x['selected_samples']=6;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_extra_flag(self):
        x=self.ex();x['selected_samples']=8;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_boolean_count(self):
        x=self.ex();x['selected_samples']=True;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_empty_flags(self):
        x=self.ex();x.update(selected_samples=0,total_flagged_samples=0);self.reject(r.validate_exact_summary,x,0,0,{'stl':'digest'})
    def test_exact_incomplete_csv(self):
        x=self.ex();x['full_original_csv_rows_verified']=r.RAYS-1;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_error_present(self):
        x=self.ex();x['error']='';self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_exact_strict_true(self):
        x=self.ex();x['original_numerical_strict_passed']=True;self.reject(r.validate_exact_summary,x,0,7,{'stl':'digest'})
    def test_duplicate_json(self):self.reject(r.parse,'{"passed":false,"passed":true}')
    def test_nonfinite_json(self):
        for v in ('NaN','Infinity','-Infinity'):self.reject(r.parse,'{"x":'+v+'}')
    def test_boolean_integer(self):self.reject(r.integer,True,'test')
    def test_bool_finite(self):self.reject(r.finite,False,'test')
    def test_missing_check(self):self.reject(r.bools,{'a':True},{'a','b'})
    def test_extra_check(self):self.reject(r.bools,{'a':True,'b':True},{'a'})
    def test_check_integer(self):self.reject(r.bools,{'a':1},{'a'})
    def test_hash_tamper(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'a';p.write_text('original');e=r.Evidence();e.track(p);p.write_text('tampered');self.assertFalse(e.unchanged());self.reject(e.track,p)
    def test_hash_wrong(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'a';p.write_text('original');self.reject(r.Evidence().track,p,'0'*64)
    def test_path_traversal(self):
        with tempfile.TemporaryDirectory() as td:self.reject(r.confined,pathlib.Path(td),'../elsewhere')
    def test_path_absolute(self):self.reject(r.confined,pathlib.Path('/tmp'),'/etc/passwd')
    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as td:self.reject(r.Evidence().track,pathlib.Path(td)/'missing')
class SyntheticEvidenceIntegration(unittest.TestCase):
    """Read existing synthetic control metadata only, never candidate geometry."""
    def test_bound_synthetic_tool_controls(self):
        r.validate_synthetic_evidence(r.Evidence(),r.inventory(r.QA))
    def test_generic_control_actual_schema(self):
        inv={pathlib.Path(k).name:v for k,v in r.inventory(r.QA).items() if k.startswith('verification/')}
        for mode in ('normal','optimized'):
            base=r.QA/'tool-controls/synthetic-normal/positive-full'/mode/'standard/controls';e=r.Evidence();report=e.read(base/'control-check.json');r.validate_generic_controls(e,base,report,inv)
    def test_intersection_control_actual_schema(self):
        import sys
        sys.path.insert(0,str(r.QA/'verification'))
        inv={pathlib.Path(k).name:v for k,v in r.inventory(r.QA).items() if k.startswith('verification/')}
        for opt,mode in enumerate(('normal','optimized')):
            r.validate_intersection_controls(r.Evidence(),r.QA/'tool-controls/synthetic-normal/positive-full'/mode/'intersection-controls',opt,inv)

    def test_generic_positive_missing_key_rejected(self):
        class Changed(r.Evidence):
            def read(self,path,expected=None):
                v=super().read(path,expected)
                if pathlib.Path(path).name=='raw-mesh-check.json' and 'normal_box' in str(path):v['checks'].pop('binary_length_exact')
                return v
        inv={pathlib.Path(k).name:v for k,v in r.inventory(r.QA).items() if k.startswith('verification/')};base=r.QA/'tool-controls/synthetic-normal/positive-full/normal/standard/controls';e=Changed();report=e.read(base/'control-check.json')
        with self.assertRaises(RuntimeError):r.validate_generic_controls(e,base,report,inv)
    def test_generic_positive_false_check_rejected(self):
        class Changed(r.Evidence):
            def read(self,path,expected=None):
                v=super().read(path,expected)
                if pathlib.Path(path).name=='raw-mesh-check.json' and 'normal_box' in str(path):v['checks']['binary_length_exact']=False
                return v
        inv={pathlib.Path(k).name:v for k,v in r.inventory(r.QA).items() if k.startswith('verification/')};base=r.QA/'tool-controls/synthetic-normal/positive-full/normal/standard/controls';e=Changed();report=e.read(base/'control-check.json');report['controls'][0]['actual_false_checks']=['binary_length_exact']
        with self.assertRaises(RuntimeError):r.validate_generic_controls(e,base,report,inv)

if __name__=='__main__':unittest.main()
