# synthetic replay control
