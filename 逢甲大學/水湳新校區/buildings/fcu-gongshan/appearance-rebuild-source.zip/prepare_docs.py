from pathlib import Path
import json,shutil,hashlib
R=Path(__file__).resolve().parent;S=R/'source/repo';D=R/'payload';rel=Path('逢甲大學/水湳新校區/buildings/fcu-gongshan');O=D/rel
for p in [Path('README.md'),Path('逢甲大學/README.md'),Path('逢甲大學/水湳新校區/README.md')]:
 t=(S/p).read_text();t=t.replace('fcu-gongshan/previews/front.png','fcu-gongshan/previews/appearance-front.png').replace('fcu-gongshan/previews/rear.png','fcu-gongshan/previews/appearance-rear.png')
 t=t.replace('當前候選待逐構件警示獨立裁定，未發布。','本輪為保留原STL幾何的8材質配色更新；62跨層警示與3類原例外保留。新配色包僅本地完成，尚未發布。')
 if str(p)=='README.md':t+='\n## 共善樓外觀配色更新\n\n[逢甲共善樓8材質與4視角預覽](逢甲大學/水湳新校區/buildings/fcu-gongshan/README.md)：原STL幾何不變；保留62跨層警示及3類原例外。本次只更新外觀，不新增模型件數。\n'
 (D/p).parent.mkdir(parents=True,exist_ok=True);(D/p).write_text(t)
pkg=json.loads((S/'model-packages.json').read_text());pkg['schools']['逢甲大學']['cover']=str(rel/'previews/appearance-front.png');pkg['updated']='2026-10-20';assert pkg['total_packages']==502 and pkg['higher_education_model_packages']==470 and pkg['all_repository_institutions_with_models']==110;(D/'model-packages.json').write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n')
t=(S/rel/'README.md').read_text();t=t.replace('尚待62筆逐構件警示的獨立特例裁定；不是已准發布包。','本輪僅更新外觀材質，原幾何與62跨層警示／3類既有例外均保留；本地重建完成，尚未發布。');t=t.replace('previews/front.png','previews/appearance-front.png').replace('previews/rear.png','previews/appearance-rear.png').replace('previews/top.png','previews/appearance-top.png').replace('正面 actual STL','正面新配色').replace('背面 actual STL','背面新配色').replace('[可編輯Blend](scene.blend)','[新配色Blend](appearance.blend) · [彩色3MF](appearance.3mf) · [鳥瞰](previews/appearance-aerial.png)');t=t.replace('屋頂金屬板縫/草皮條紋及細格柵省略','屋頂金屬板縫及細格柵省略；草皮條紋以本次共面材質分區近似')
t+='''

## 2026-10-20 本地外觀重建

本版重新從指定遠端STL建立，沒有恢復或沿用上一輪遺失的配色檔，也未引用上一輪QA。兩張官方照片已實際開圖檢視，拍攝日期未知，不能稱為2026現況。

- 8個材質：銀灰屋頂、綠色屋頂帶、淺灰簷口、深綠灰玻璃、暖褐既有框、灰廣場、既有綠地、未確認面中性灰。
- 條帶間距與寬度為照片支持的外觀近似，未逐條測繪。未將陰影當黑漆、未新增鄰樓、植栽體積或窗框幾何。
- 原STL 6,644三角面不覆寫。材質模型54,096面，由同一表面共面細分；每面保留原三角面索引。為避免T接，條帶切線也傳遞至其他面，這些細分不改外形。
- 原包圍盒完全相同；雙精度signed-volume差0 mm³；最大共面誤差2.67×10⁻¹⁴ mm；最大單原面面積差9.10×10⁻¹² mm²。單一閉合殼、繞序一致。
- Blender與lib3mf實際float32讀回及單材質編輯存檔測試另列於QA；不能以double檢查代替交付格式檢驗。
- 3MF採標準Core base materials逐面配色，未包含特定切片器耗材映射；不保證任一切片器自動識別所有色料。
- 原始104層／294構件已重新檢查，仍62筆>1%警示，嚴格測試仍exit1。3類既有例外的原裁定保留，未重新授予或擴大例外。沒有實體試印或切片器工具路徑測試。

[外觀幾何QA](appearance-geometry-qa.json) · [格式讀回QA](appearance-roundtrip-qa.json) · [實際材質編輯QA](appearance-edit-roundtrip-qa.json) · [材質來源對應](material-evidence.json) · [本次QA說明](APPEARANCE-QA.md)

新配色可由同目錄的appearance-rebuild-source.zip重新生成。原始照片不納入公開包；重建源包只列官方URL及SHA256。全庫件數維持502／高教470／110校。
''';(O/'README.md').write_text(t)
for name in ['model.stl','build_model.py','requirements.txt','independent-review.json','warning-review.json','sources.json','sources.md']:
 shutil.copy2(S/rel/name,O/name)
# Keep the original QA and exact historical exception evidence, labeled as baseline.
shutil.copy2(S/rel/'QA.md',O/'QA.md')
qdir=O/'appearance-baseline-recheck';qdir.mkdir(exist_ok=True)
for p in (R/'qa-original').iterdir():
 if p.suffix=='.json' or p.name.endswith('.py.log'):shutil.copy2(p,qdir/p.name)
# Copies of newly executed tests, not prior-run claims.
(O/'APPEARANCE-QA.md').write_text('''# 本輪外觀配色QA

基準為遠端commit 8388c665eb19c2857a0f29143a8713b801c3cea1，原STL SHA256 b81c4c9b53abc38982bc69a5cffb6742871a04e352ab5a1bf60929a649f8bc4d。

本輪重新下載並核對來源blob，實讀兩張官方照片。照片日期未知；沒有引用遺失舊版本的面數、誤差或通過結果。

1. 原始二進位STL、source重建與原Blend重新核驗成功；所有原幾何檢查重新執行。validate_model最初因未取得原Blend而未完成，補取得SHA核對成功的原Blend後完整重跑通過。
2. 原104層294構件依舊62筆超過1%的loss警示。check_component_detail保留exit1；其餘列出的檢查exit0。不修改門檻，不宣稱所有原測試綠燈。三類原裁定仍是O柱42／白帶16／屋尖4。
3. 外觀材質只作用於原表面；8材質，不限制4色。每面記錄原STL三角面索引。全域共面切分防止T接；數值相同頂點以1e−10mm容差去重，沒有拓撲repair。誤差與閉合檢查見appearance-geometry-qa.json。
4. 3MF逐點／逐面／逐材質讀回與主資料精確一致；Blender使用float32，其座標誤差與索引核驗另記錄。lib3mf嚴格讀取與實際改一材質、寫出、重開；Blender亦實際改一材質、存檔、重開。完整結果見appearance-edit-roundtrip-qa.json。首輪3MF編輯寫出發現缺少object預設材質，已在源補上pid/pindex。其後預設6位小數存檔曾使2面退化，已將條帶切線相位平移0.01337mm避開屋尖近重合頂點，對最終54,096面重測零退化、零重合頂點且閉合。未靠提高writer精度避開問題。預設6位存檔後座標最大變動7.63e−6mm，故不宣稱lib3mf編輯後座標bitwise相同。
5. 四張1400×1050 PNG均以最終材質mesh重新渲染並開圖檢查；正、背、鳥瞰、頂視，全底座入框。無來源照片混入。

限制：條帶相位、寬度、色值和不可見面不屬測繪；不可見／未能匹配面中性灰。小三角面仍存在，不以通過數位測試聲稱連續最小壁厚、切片器保證或實體可印。未新增樓棟，全庫502／高教470／110校不變。未推送GitHub。
''')
print('Documentation synchronized; counts 502/470/110 unchanged')
