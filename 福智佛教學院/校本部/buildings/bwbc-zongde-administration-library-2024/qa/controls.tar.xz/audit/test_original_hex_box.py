from pathlib import Path
import csv,json,lzma,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'independent-tools'))
from diagnose_recorded_cpp_rays import hex_fraction,classify
from exact_ray_diagnosis import Mesh,load,require
base=Path(__file__).resolve().parent
with lzma.open(base/'generic-controls/python_B/normal_box/check_dense_surface/dense-original.csv.xz','rt') as f:old=list(csv.DictReader(f))
with lzma.open(base/'original-hex-box/dense-original.csv.xz','rt') as f:new=list(csv.DictReader(f))
_,tris,den=load(base/'generic-controls/python_B/normal_box/fixture.stl');m=Mesh(tris,den)
require(len(old)==len(new)==120,'Count mismatch');rows=[]
for before,after in zip(old,new):
 require(all(before[k]==after[k] for k in before),'Numerical field changed with added hex output')
 require(len(after)==len(before)+12,'Missing exact descriptor columns')
 for k,j in [('nx','dx'),('ny','dy'),('nz','dz')]:require(hex_fraction(after[k+'_hex'])==-hex_fraction(after[j+'_hex']),'Direction not exact negated rounded normal')
 r=classify(m,after,after);require(r['exact_classification_completed'] and r['conservative_first_solid_chord_ge_0p8mm'],'Exact box ray classification failed');rows.append({'face':int(after['face']),'sample':int(after['sample']),'old_numerical_columns_bitwise_equal':True,'exact_classification_completed':True,'squared_chord':r['conservative_first_solid_chord_squared_mm2_exact']})
report={'passed':True,'optimization_level':sys.flags.optimize,'original_ray_count':len(rows),'cases':rows};Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n');print({'passed':True,'original_ray_count':len(rows)})
