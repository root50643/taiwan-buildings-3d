"""Sixteen synthetic helper-level controls. No real inventory CLI success claimed.

Run only when the parent schedules the pure normal/-O controls. All fixtures are
new synthetic bytes. No science, scanner, compression, model, or real HOLD edits.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import types

sys.dont_write_bytecode = True
CASE_NAMES = (
    'exact_gap_preserves_original_evidence',
    'same_path_current_bytes_remain_separately_retained',
    'wrong_gap_path_rejected', 'wrong_gap_size_rejected', 'wrong_gap_hash_rejected',
    'second_historical_missing_rejected', 'science_dependency_rejected',
    'runner_dependency_rejected', 'public_dependency_rejected', 'replay_dependency_rejected',
    'malformed_and_negative_proof_dependency_rejected', 'extra_hold_rejected',
    'current_unresolved_rejected', 'mutated_exact_binding_rejected',
    'source_changed_or_replaced_rejected', 'unsafe_read_and_strict_metadata_rejected')


def check(value, message):
    if not value:
        raise RuntimeError(message)


def bootstrap_read(path):
    path = Path(os.path.abspath(path))
    parent = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            parent = child
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        try:
            before = os.fstat(fd)
            check(stat.S_ISREG(before.st_mode), 'Bootstrap source is nonregular')
            parts = []
            while True:
                part = os.read(fd, 1024 * 1024)
                if not part:
                    break
                parts.append(part)
            after = os.fstat(fd)
            named = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
            fields = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns)
            check(fields(before) == fields(after) == fields(named), 'Bootstrap source changed')
            data = b''.join(parts)
            check(len(data) == before.st_size, 'Bootstrap source size changed')
            return data
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def load_adapter(path):
    raw = bootstrap_read(path)
    module = types.ModuleType('metadata_gap_adapter_under_test')
    module.__file__ = str(Path(os.path.abspath(path)))
    module.__package__ = ''
    # Exactly these bytes are hashed, compiled once, and executed without pycache.
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    return module, raw


def rejected(fn, message):
    try:
        fn()
    except (ValueError, OSError, KeyError, TypeError, IndexError):
        return
    raise RuntimeError(message)


def synthetic_bundle(m):
    def descriptor(name, raw):
        return {'source_relative_path': name, 'bytes': len(raw), 'sha256': m.digest(raw)}
    selected = {**descriptor('independent/synthetic-selected.txt', b'synthetic selected\n'),
                'archive_path': 'synthetic-selected.txt', 'transformation': 'identity'}
    omitted = {**descriptor('independent/synthetic-private.txt', b'synthetic private\n'),
               'category': 'private_execution_log', 'reason': 'Pure synthetic private bytes retained without publication.'}
    direct = {**descriptor('author/synthetic-direct.txt', b'synthetic direct\n'),
              'type': 'regular', 'disposition': 'public_direct_identity',
              'public_relative_path': 'synthetic-direct.txt'}
    inventory = {'all_snapshot_paths_accounted': True, 'source_changes_during_static_read': [],
                 'regular_file_count': 3,
                 'files': [{**selected, 'type': 'regular', 'disposition': 'preserve_original_bytes'},
                           {**omitted, 'type': 'regular', 'disposition': 'private_original_retained'}, direct],
                 'historical_nonroutine_versions_missing': [copy.deepcopy(m.GAP)],
                 'historical_original_version_accounting': [
                     {**m.GAP, 'status': 'historical_descriptor_only', 'retained_at': None,
                      'prior_disposition': 'omit_private_content'}]}
    result = {'passed': False, 'model_go': False, 'hold_count': 1,
              'all_source_bytes_unchanged': True, 'scanner_source_sha256': m.SCANNER_SHA,
              'public_scanner_helper_sha256': m.HELPER_SHA,
              'source_inventory_regular_count': 3, 'selected_count': 1, 'private_omission_count': 1}
    selection = {'passed': False, 'model_go': False, 'files': [selected],
                 'original_payload_inventory_complete': True, 'all_selected_dependencies_publicly_mapped': False}
    omissions = {'ready_for_final_assembly': False, 'files': [omitted]}
    findings = {'private': True, 'holds': [{'reason': m.HISTORICAL_REASON, 'files': [copy.deepcopy(m.GAP)]}]}
    required = {name: [m.ref(selected)] for name in m.SET_NAMES}
    return [result, inventory, selection, omissions, findings, required]


def gate(m, bundle):
    return m.validate_only_gap(*bundle)


def positive_exact(m, directory):
    bundle = synthetic_bundle(m)
    before = copy.deepcopy(bundle)
    disclosure = gate(m, bundle)
    derived = m.derive_documents(bundle[1], bundle[2], bundle[3], disclosure)
    check(bundle == before, 'Inputs mutated')
    check(derived['selection']['passed'] is True and derived['omissions']['ready_for_final_assembly'] is True,
          'Derived readiness absent')
    for name, value in derived.items():
        check(value['gap_acknowledged'] is True and value['all_historical_retained'] is False
              and value['model_go'] is False, 'Truthful gap/model flags absent')
    check(derived['inventory']['historical_nonroutine_versions_missing'] == [m.GAP], 'Missing row rewritten')
    check(derived['inventory']['historical_original_version_accounting']
          == bundle[1]['historical_original_version_accounting'], 'Historical retention rewritten')
    m.write_fresh_bundle(directory / 'derived-synthetic',
                         {m.DERIVED[key]: m.dump(value) for key, value in derived.items()})


def positive_current_path(m, directory):
    bundle = synthetic_bundle(m)
    latest = {'source_relative_path': m.GAP['source_relative_path'], 'bytes': 19,
              'sha256': m.digest(b'new synthetic state'), 'category': 'private_path_report',
              'reason': 'Current synthetic progress metadata is independently retained.'}
    bundle[1]['files'].append({**latest, 'type': 'regular', 'disposition': 'private_original_retained'})
    bundle[1]['regular_file_count'] += 1
    bundle[0]['source_inventory_regular_count'] += 1
    bundle[0]['private_omission_count'] += 1
    bundle[3]['files'].append(latest)
    gate(m, bundle)
    check(bundle[1]['historical_nonroutine_versions_missing'] == [m.GAP], 'Old missing identity erased')


def wrong_gap(m, key, value):
    bundle = synthetic_bundle(m)
    bundle[4]['holds'][0]['files'][0][key] = value
    bundle[1]['historical_nonroutine_versions_missing'][0][key] = value
    bundle[1]['historical_original_version_accounting'][0][key] = value
    rejected(lambda: gate(m, bundle), 'Different gap accepted')


def second_missing(m, directory):
    bundle = synthetic_bundle(m)
    second = {**m.GAP, 'source_relative_path': 'independent/another-historical.json'}
    bundle[1]['historical_nonroutine_versions_missing'].append(second)
    bundle[1]['historical_original_version_accounting'].append(
        {**second, 'status': 'historical_descriptor_only', 'retained_at': None})
    bundle[4]['holds'][0]['files'].append(second)
    rejected(lambda: gate(m, bundle), 'Second missing accepted')


def dependency(m, families):
    for family in families:
        for variant in ('path', 'identity'):
            bundle = synthetic_bundle(m)
            row = copy.deepcopy(m.GAP)
            if variant == 'path':
                row['sha256'] = m.digest(b'different current byte identity')
                row['bytes'] = 31
            else:
                row['source_relative_path'] = 'independent/different-name-same-identity.json'
            bundle[5][family].append(row)
            rejected(lambda: gate(m, bundle), 'Required gap dependency accepted: ' + family)


def extra_hold(m, directory):
    bundle = synthetic_bundle(m)
    bundle[0]['hold_count'] = 2
    bundle[4]['holds'].append({'reason': 'Final selected dependency/scanner closure failed'})
    rejected(lambda: gate(m, bundle), 'Extra HOLD accepted')
    bundle[0]['hold_count'] = 1
    rejected(lambda: gate(m, bundle), 'Miscounted extra HOLD accepted')


def current_unresolved(m, directory):
    bundle = synthetic_bundle(m)
    bundle[1]['files'][0]['disposition'] = 'HOLD_unresolved_exact_publication_disposition'
    rejected(lambda: gate(m, bundle), 'Unresolved current disposition accepted')


def synthetic_sources(m, directory):
    root = directory / 'synthetic-independent'
    root.mkdir()
    author = root / 'frozen'
    author.mkdir()
    path = root / 'input.txt'
    path.write_bytes(b'synthetic input\n')
    source = m.Sources({'independent': root, 'author': author}, {'independent/frozen': 'author'})
    bound = {'source_relative_path': 'independent/input.txt', 'bytes': 16,
             'sha256': m.digest(b'synthetic input\n')}
    return source, path, bound


def mutated_binding(m, directory):
    source, path, bound = synthetic_sources(m, directory)
    wrong = {**bound, 'sha256': '0' * 64}
    rejected(lambda: source.data(wrong), 'Mutated SHA binding accepted')
    wrong = {**bound, 'bytes': True}
    rejected(lambda: source.data(wrong), 'Boolean byte count accepted')
    wrong = {**bound, 'bytes': bound['bytes'] + 1}
    rejected(lambda: source.data(wrong), 'Mutated size binding accepted')


def source_changed(m, directory):
    source, path, bound = synthetic_sources(m, directory)
    source.data(bound)
    replacement = path.with_name('replacement.txt')
    replacement.write_bytes(b'synthetic input\n')
    os.replace(replacement, path)
    rejected(source.unchanged, 'Same-byte replaced inode accepted')
    source2, path2, bound2 = synthetic_sources(m, directory / 'second')
    source2.data(bound2)
    path2.write_bytes(b'mutated content\n')
    rejected(source2.unchanged, 'Changed source bytes accepted')


def unsafe_and_strict(m, directory):
    real = directory / 'regular.txt'
    real.write_bytes(b'synthetic')
    leaf_link = directory / 'leaf-link'
    leaf_link.symlink_to(real.name)
    rejected(lambda: m.read_path(leaf_link), 'Leaf symlink read accepted')
    ancestor = directory / 'ancestor-link'
    ancestor.symlink_to('.', target_is_directory=True)
    rejected(lambda: m.read_path(ancestor / 'regular.txt'), 'Ancestor symlink read accepted')
    fifo = directory / 'fifo'
    os.mkfifo(fifo)
    try:
        rejected(lambda: m.read_path(fifo), 'FIFO read accepted')
    finally:
        fifo.unlink()
    for raw in (b'{"x": 1, "x": 2}', b'{"x": NaN}', b'{"x": Infinity}', b'{"x": 1e999}'):
        rejected(lambda raw=raw: m.parse(raw), 'Non-strict JSON accepted')
    for name in ('../escape', '/absolute', 'a/../b', 'a\\b', 'a//b'):
        rejected(lambda name=name: m.safe(name), 'Unsafe logical path accepted')
    m.write_fresh_bundle(directory / 'fresh', {'one.json': b'{}\n'})
    rejected(lambda: m.write_fresh_bundle(directory / 'fresh', {'one.json': b'{}\n'}),
             'Existing output accepted')


def main():
    os.umask(0o077)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    adapter_path = Path(__file__).parent / 'acknowledge_metadata_gap.py'
    own = bootstrap_read(Path(__file__))
    m, source = load_adapter(adapter_path)
    # Fresh output creation uses the adapter's fd-relative implementation.
    m.write_fresh_bundle(args.out, {})
    cases = [
        positive_exact, positive_current_path,
        lambda m, d: wrong_gap(m, 'source_relative_path', 'independent/WRONG.json'),
        lambda m, d: wrong_gap(m, 'bytes', 3815),
        lambda m, d: wrong_gap(m, 'sha256', '0' * 64),
        second_missing,
        lambda m, d: dependency(m, ['science']),
        lambda m, d: dependency(m, ['runner']),
        lambda m, d: dependency(m, ['public_base', 'public_active']),
        lambda m, d: dependency(m, ['replay', 'seed']),
        lambda m, d: dependency(m, ['malformed_proofs', 'negative_proofs', 'other_proofs']),
        extra_hold, current_unresolved, mutated_binding, source_changed, unsafe_and_strict]
    check(len(cases) == len(CASE_NAMES) == 16, 'Wrong case count')
    results = []
    for number, (name, operation) in enumerate(zip(CASE_NAMES, cases)):
        directory = args.out / ('case-' + str(number + 1).zfill(2))
        directory.mkdir()
        # The changed-source case creates a second independent fixture root.
        if name == 'source_changed_or_replaced_rejected':
            (directory / 'second').mkdir()
        try:
            operation(m, directory)
            results.append({'name': name, 'expected': 'accept' if number < 2 else 'reject',
                            'passed': True, 'scope': 'synthetic_helper_level'})
        except Exception as error:
            # Exception class only: never leak a physical fixture directory.
            results.append({'name': name, 'expected': 'accept' if number < 2 else 'reject',
                            'passed': False, 'error_type': type(error).__name__,
                            'scope': 'synthetic_helper_level'})
    unchanged = bootstrap_read(adapter_path) == source and bootstrap_read(Path(__file__)) == own
    passed = all(row['passed'] for row in results) and unchanged
    report = {'schema': 'aeust-metadata-gap-synthetic-controls-v1', 'passed': passed,
              'optimization_level': sys.flags.optimize, 'case_count': 16,
              'positive_count': 2, 'negative_count': 14, 'cases': results,
              'scope': 'synthetic_helper_level_not_real_cli', 'real_cli_success_exercised': False,
              'adapter_source_sha256': hashlib.sha256(source).hexdigest(),
              'test_source_sha256': hashlib.sha256(own).hexdigest(),
              'all_original_input_and_tool_bytes_unchanged': unchanged,
              'model_go': False, 'science_or_scanner_executed': False,
              'not_claimed': 'These small helpers do not establish full production CLI acceptance or complete real dependency coverage.'}
    m.write_fresh_bundle(args.out / 'report', {'results.json': m.dump(report)})
    print(json.dumps({'passed': passed, 'case_count': 16, 'positive_count': 2,
                      'negative_count': 14, 'scope': report['scope'], 'model_go': False}, allow_nan=False))
    if not passed:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
