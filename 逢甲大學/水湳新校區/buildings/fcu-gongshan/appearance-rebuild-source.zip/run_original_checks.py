import pathlib,subprocess,json,sys,time
r=pathlib.Path(__file__).parent/'qa-original';out=[]
for s in ['check_raw_mesh.py','validate_model.py','check_thin_features.py','check_layer_components.py','check_all_layers.py','check_feature_rays.py','check_ribbon_rays.py','check_tip_dense_rays.py','check_tip_layer_support.py','check_original_sections.py','check_white_roi_rays.py','check_component_detail.py']:
 t=time.time();p=subprocess.run([sys.executable,str(r/s)],cwd=r,capture_output=True,text=True);(r/(s+'.log')).write_text(p.stdout+p.stderr);out.append({'script':s,'exit_code':p.returncode,'seconds':time.time()-t});(r/'check-results.json').write_text(json.dumps(out,indent=2));print(out[-1],flush=True)
