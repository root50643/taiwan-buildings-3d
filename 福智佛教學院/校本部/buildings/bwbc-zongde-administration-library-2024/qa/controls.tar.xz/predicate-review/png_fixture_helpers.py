"""Tiny independent PNG fixture generator. Writes only when explicitly called.
Forward filtering is independent of the comparator's inverse filtering.
"""
import struct, zlib
SIGNATURE=b'\x89PNG\r\n\x1a\n'
PIXELS=bytes([0,0,0,255,255,254,253,252,3,127,128,129,
              255,0,129,128,1,255,0,254,129,127,3,0,
              128,255,1,0,127,1,255,128,254,3,0,255])
WIDTH=3
HEIGHT=3

def chunk(kind,data):
    return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)

def ihdr(width=WIDTH,height=HEIGHT,depth=8,color=6,compression=0,filter_method=0,interlace=0):
    return chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,depth,color,compression,filter_method,interlace))

def text(key,value):
    return chunk(b'tEXt',key.encode('latin1')+b'\0'+value.encode('latin1'))

def paeth(left,up,upleft):
    # Alternative statement of Paeth: minimize distance from the predictor;
    # Python min keeps the required left, up, upper-left tie priority.
    p=left+up-upleft
    return min((left,up,upleft),key=lambda candidate:abs(p-candidate))

def filtered(pixels=PIXELS,width=WIDTH,height=HEIGHT,filters=(0,0,0)):
    stride=width*4
    if len(pixels)!=stride*height:raise ValueError('bad fixture pixels')
    result=bytearray()
    for row in range(height):
        kind=filters[row%len(filters)];result.append(kind)
        for x in range(stride):
            current=pixels[row*stride+x]
            left=pixels[row*stride+x-4] if x>=4 else 0
            up=pixels[(row-1)*stride+x] if row else 0
            upleft=pixels[(row-1)*stride+x-4] if row and x>=4 else 0
            predictor=(0,left,up,(left+up)//2,paeth(left,up,upleft))[kind]
            result.append((current-predictor)%256)
    return bytes(result)

def png(pixels=PIXELS,width=WIDTH,height=HEIGHT,filters=(0,0,0),before=(),after=(),level=6,split=None,raw=None):
    packed=zlib.compress(filtered(pixels,width,height,filters) if raw is None else raw,level)
    segments=[packed] if split is None else [packed[:split],packed[split:]]
    return SIGNATURE+ihdr(width,height)+b''.join(before)+b''.join(chunk(b'IDAT',s) for s in segments)+b''.join(after)+chunk(b'IEND',b'')

def parts(data):
    result=[];offset=8
    while offset<len(data):
        length=struct.unpack_from('>I',data,offset)[0]
        result.append((data[offset+4:offset+8],data[offset+8:offset+8+length]))
        offset+=12+length
    return result

def assemble(entries):return SIGNATURE+b''.join(chunk(k,v) for k,v in entries)
