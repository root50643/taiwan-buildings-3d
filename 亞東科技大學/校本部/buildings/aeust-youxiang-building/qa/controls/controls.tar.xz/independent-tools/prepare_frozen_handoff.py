"""Read-only exact schema adaptation of the supplied AEUST v15 author freeze.
No member may be removed or rewritten. Original freeze is one additional member.
"""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,sys
STL='46649566e965a049e6e333e9d82b075407c8e926e55c9034f11fbe3dbdf15a5d'
SOURCE='e3e24f4fc32f0682f7e19b7c775118b6786ce4223c060e451d5117ae22cf9ea9'
ARTIFACT='a78a48bc863ca6d12463f1c69865c30e43102558afed6ecb37c369d3f7d78f0f'
VIEWS={'front','rear','west','east','south','north','top','courtyard-gallery','courtyard-arcade'}
def require(v,m):
 if not v:raise RuntimeError(m)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def safe(s):
 require(type(s) is str and s and '\\' not in s and '\0' not in s,'Unsafe path text');p=PurePosixPath(s);require(not p.is_absolute() and p.as_posix()==s and all(x not in ('','.','..') for x in s.split('/')),'Unsafe relative path');return s
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--author',type=Path,required=True);ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--sha256',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();root=a.author.resolve();manifest=a.manifest.resolve();require(not a.out.exists(),'Fresh adapter path required');require(manifest.is_relative_to(root) and sha(manifest)==a.sha256,'Original manifest identity differs')
 rel=safe(manifest.relative_to(root).as_posix());m=json.loads(manifest.read_bytes());require(m.get('revision',m.get('version'))=='v15' and m['stl_sha256']==STL,'Wrong candidate');files=m['files'];require(type(files) is dict and files and rel not in files,'Expected exact dict source schema without recursive self-member');rows=[]
 for name,v in sorted(files.items()):
  safe(name);require(type(v) is dict and set(v)=={'bytes','sha256'},'Original file schema differs');p=root/name;require(p.is_file() and not any(x.is_symlink() for x in [p,*p.parents] if x.is_relative_to(root)),'Nonregular or symlink input');require(type(v['bytes']) is int and v['bytes']>=0 and p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],'Frozen input differs '+name);rows.append({'path':name,**v})
 required={'source/build_model.py','source/render_preview.py','parameters.json','qa/V15-FINAL-ARTIFACT-FREEZE.json','qa/source-review/final-v15/SOURCE-APPEARANCE-GO.json'}
 required|={'models/v15/'+n for n in ['model.stl','scene.blend','build_model.py','render_preview.py','parameters.json','color-regions.json']}
 required|={'previews/v15/'+n+'.png' for n in VIEWS}|{'previews/v15/render-manifest.json'}
 science=['standard/qa-summary.json','standard/raw/raw-mesh-check.json','standard/sections/section-check.json','standard/sections/section-details.json.gz','standard/sections/section-failures.json.gz','standard/dense/dense-check.json','standard/dense/dense-original.csv.xz','standard/dense/dense-flagged-samples.json.gz','standard/dense/dense-short-samples.json.gz','dense-evidence.json','intersections.json','intersections.json.contacts.jsonl.gz']
 for mode in ['normal','optimized']:
  required|={'qa/v15-full/'+mode+'/'+n for n in science}
  required|={'qa/v15-recorded-rays/'+mode+'/'+n for n in ['exact-recorded-ray-summary.json','exact-recorded-ray-details.jsonl.gz']}
 tools=Path(__file__).resolve().parents[1]/'tooling';bindings={}
 for folder in ['verification','tools','render-tools']:
  for p in sorted((tools/folder).glob('*')):
   if p.suffix not in ['.py','.cpp']:continue
   n='qa/'+folder+'/'+p.name;required.add(n);require(n in files and files[n]['sha256']==sha(p),'Author checker differs from independently fresh-tested source '+n);bindings[n]=sha(p)
 require(len(bindings)==28,'Independently tested tool source count changed');require(required<=set(files),'Incomplete freeze required members: '+str(sorted(required-set(files))))
 require(files['models/v15/model.stl']['sha256']==STL and files['qa/source-review/final-v15/SOURCE-APPEARANCE-GO.json']['sha256']==SOURCE and files['qa/V15-FINAL-ARTIFACT-FREEZE.json']['sha256']==ARTIFACT,'Original source/model freeze binding differs')
 old=json.loads((root/'qa/V15-FINAL-ARTIFACT-FREEZE.json').read_bytes());require(all(k in files and files[k]==v for k,v in old['files'].items()),'Original exterior-freeze member lost or changed')
 rows.append({'path':rel,'bytes':manifest.stat().st_size,'sha256':a.sha256});rows.sort(key=lambda x:x['path'])
 adapter={'version':'v15','stl_sha256':STL,'original_author_manifest_path':rel,'original_author_manifest_sha256':a.sha256,'original_source_appearance_go_sha256':SOURCE,'original_artifact_freeze_sha256':ARTIFACT,'tool_sources_identical_to_fresh_independent_controls':bindings,'files':rows,'scope':'Schema-only adapter: every original author member remains exact, plus the unchanged original manifest itself. No scientific result or strict flag is rewritten. This is input validation, not model acceptance.'}
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(adapter,indent=2,allow_nan=False)+'\n');require(sha(manifest)==a.sha256,'Original freeze changed while adapting');print(json.dumps({'passed':True,'original_members':len(files),'runner_members':len(rows),'adapter_sha256':sha(a.out),'source_sha256':sha(__file__)}))
if __name__=='__main__':main()
