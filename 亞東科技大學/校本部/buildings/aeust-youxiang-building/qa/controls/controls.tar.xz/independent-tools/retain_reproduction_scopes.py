"""Use unchanged archive tools to verify/replay and retain exact original scopes."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,sys,tempfile,types
def require(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();q=a.root.resolve();require(not a.out.exists(),'Fresh verification report required');original_self=Path(__file__).read_bytes();manifest_raw=a.manifest.read_bytes();require(sha(manifest_raw)==a.manifest_sha256,'Manifest hash differs');doc=json.loads(manifest_raw);require(doc['model_go'] is False and doc['request_count']==len(doc['files'])==78,'Exact scope request count differs');tracked={}
    def path(name):
        require(isinstance(name,str) and name.startswith('independent/') and '\\' not in name,'Unknown logical root');relative=name[len('independent/'):];require(PurePosixPath(relative).as_posix()==relative and all(p not in ('','.','..') for p in relative.split('/')),'Unsafe relative path');p=q
        for part in relative.split('/'):
            p=p/part;require(not p.is_symlink(),'Symlink in source or target')
        return p
    def data(ref):
        p=path(ref['source_relative_path']);require(p.is_file(),'Required original source absent');b=p.read_bytes();require(len(b)==ref['bytes'] and sha(b)==ref['sha256'],'Original source descriptor differs');require(ref['source_relative_path'] not in tracked or tracked[ref['source_relative_path']]==(len(b),sha(b)),'Original source changed between reads');tracked[ref['source_relative_path']]=(len(b),sha(b));return b
    modules={};tool_sources={}
    for filename,h in [('archive_verify.py','1af27c8212057503323899b7a5f9f9171de42f78a28ff1e3e07f82d688e021fd'),('build_controls_archive.py','e4b23d35449c6321abbfea94e85f4d733ce58be65658255e1e5ba5065b33f637')]:
        p=q/'tooling/tools'/filename;b=p.read_bytes();require(sha(b)==h,'Original archive tool changed');m=types.ModuleType(filename[:-3]);m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);modules[filename]=m;tool_sources[filename]=(p,b)
    verifier=modules['archive_verify.py'];builder=modules['build_controls_archive.py'];rows=[]
    for request in doc['files']:
        archive_bytes=data(request['archive']);index_raw=data(request['archive_index']);selection=json.loads(data(request['selection_input']));result=json.loads(data(request['result_proof']['reference']));data(request['generator_source']);index=json.loads(index_raw)
        require(result['source_sha256']=='1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c' and result['archive_sha256']==sha(archive_bytes) and result['index_sha256']==sha(index_raw),'Original package result bindings differ');require(all(result[k] is True for k in ['passed','sources_unchanged','bitwise_rebuild_verified','safe_extract_all_member_hashes_verified','all_selected_inputs_accounted','all_tracked_dependencies_selected_and_copied']),'Original package result incomplete');require(request['result_proof']['schema']=='package_controls_v2_result','Wrong result proof schema')
        for ref in request['raw_inputs']:data(ref)
        checked,raw,records=verifier.verify(path(request['archive']['source_relative_path']),path(request['archive_index']['source_relative_path']));bindings=request['member_bindings'];require([{k:m[k] for k in ['path','bytes','sha256']} for m in bindings]==index['members'],'All-member request differs from exact index');byname={m['path']:m for m in bindings};require(len(byname)==len(bindings)==len(records),'Member inventory differs');scope=None
        with tempfile.TemporaryDirectory(prefix='aeust-verified-scope-') as temporary:
            restored=Path(temporary)/'restored';verifier.extract_new(restored,raw,records)
            for name,start,end in records:
                member=byname[name];b=raw[start:end];require(len(b)==member['bytes'] and sha(b)==member['sha256'],'Original member bytes differ');p=restored/name;require(p.is_file() and not p.is_symlink() and p.read_bytes()==b,'Safe extracted member readback differs')
                if name=='ARCHIVE-SCOPE.json':scope=b
                else:require(data(member)==b,'Original input is not the exact original archive member')
            rebuilt_raw,rebuilt_archive=builder.make_archive(restored,index['members']);require(rebuilt_raw==raw and rebuilt_archive==archive_bytes,'Full safe-extracted archive bitwise rebuild differs')
        require(scope is not None,'Original scope missing');target_ref=request['scope_to_retain'];require(len(scope)==target_ref['bytes'] and sha(scope)==target_ref['sha256'],'Requested scope is not the exact original member');target=path(target_ref['source_relative_path']);target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        if target.exists():require(target.is_file() and target.read_bytes()==scope,'Existing retained scope differs')
        else:
            with target.open('xb') as stream:stream.write(scope)
        require(target.read_bytes()==scope,'Permanent exact scope readback differs');rows.append({'archive':request['archive'],'original_scope':target_ref,'members':len(records),'all_original_inputs_and_members_equal':True,'safe_extract_and_all_member_readback':True,'bitwise_rebuild_equal':True})
    require(all(path(name).read_bytes().__len__()==n and sha(path(name).read_bytes())==h for name,(n,h) in tracked.items()),'Original input changed after replay');require(all(p.read_bytes()==b for p,b in tool_sources.values()) and a.manifest.read_bytes()==manifest_raw and Path(__file__).read_bytes()==original_self,'Exact tool/request source changed')
    result={'passed':True,'model_go':False,'optimization_level':sys.flags.optimize,'source_sha256':sha(original_self),'request_manifest_sha256':sha(manifest_raw),'archives_verified':len(rows),'original_sources_unchanged':True,'all_members_read_back_and_bitwise_rebuilt':True,'exact_original_scopes_retained':True,'archive_tool_sources_sha256':{n:sha(b) for n,(p,b) in tool_sources.items()},'files':rows,'scope':'Complete original strict archive verification, safe temporary extraction, every-member bytes, and deterministic rebuild. Only exact original ARCHIVE-SCOPE members are permanently retained. No nested control fixture is extracted and no publication/model verdict is granted.'};a.out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({'passed':True,'optimization_level':sys.flags.optimize,'archives_verified':len(rows)}))
if __name__=='__main__':main()
