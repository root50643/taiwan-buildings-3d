# synthetic helper verification/check_original_intersections.py
