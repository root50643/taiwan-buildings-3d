# synthetic helper independent-tools/diagnose_recorded_cpp_rays.py
