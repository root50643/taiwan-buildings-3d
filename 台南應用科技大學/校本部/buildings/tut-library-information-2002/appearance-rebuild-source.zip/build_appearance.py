from pathlib import Path
import numpy as np, trimesh, hashlib,json,zipfile,xml.etree.ElementTree as ET
from shapely.geometry import Polygon
R=Path(__file__).resolve().parent; SRC=R/'source/repo/台南應用科技大學/校本部/buildings/tut-library-information-2002';OUT=R/'payload/台南應用科技大學/校本部/buildings/tut-library-information-2002';OUT.mkdir(parents=True,exist_ok=True)
raw=(SRC/'model.stl').read_bytes();assert hashlib.sha256(raw).hexdigest()=='626aa6e3f19698098e05275514aa5b5db876fe8301107c15c253dd65a142d71f'
ns={'__file__':str(SRC/'build_model.py')};exec((SRC/'build_model.py').read_text().split('solid=Manifold.batch_boolean')[0],ns)
pts=np.asarray(ns['pts']);lo=pts.min(axis=0)-7;hi=pts.max(axis=0)+3;scale=150/max(hi-lo)
mesh=trimesh.load(SRC/'model.stl',process=False);T=np.asarray(mesh.triangles,dtype=np.float64)
palette=[('neutral_unobserved','#A5A8A6'),('observed_pink_masonry','#BD9690'),('observed_green_blue_glass','#468A83'),('observed_light_glass','#70AAA0'),('observed_pale_bands','#D1CDC3'),('observed_gray_canopy','#92978D'),('observed_glazing_frame','#93A39A'),('base_neutral','#A4A49E')]
def category(tri):
 c=tri.mean(axis=0)/scale;c[2]-=1.2
 normal=np.cross(tri[1]-tri[0],tri[2]-tri[0]);normal/=np.linalg.norm(normal)
 if c[2]<=.001:return 7,'base_neutral'
 if c[2]>=45.99:return 0,'unobserved_roof_neutral'
 candidates=[]
 for i in [2,3,4]:
  a,u,n,L=ns['frame'](i);x=(c[:2]-a)@u;d=(c[:2]-a)@n
  if -.03<=x<=L+.03 and -6<d<3.3:candidates.append((abs(d),i,x,d,u,n,L))
 if not candidates:return 0,'unobserved_or_unresolved_neutral'
 _,i,x,d,u,n,L=min(candidates,key=lambda t:t[0]);z=c[2];parallel=abs(normal[:2]@n)>.98
 if i==3:
  if L*.31-.04 <= x <= L*.69+.04 and 5.3 < z < 8.32 and (abs(normal[2])>.1 or d<-.01):return 5,'observed_curved_canopy'
  if d<-1.85:
   if z>5.25:return 5,'observed_curved_canopy'
   return 1,'observed_entry_columns_and_steps'
  if L*.27-.03<x<L*.73+.03 and 11.79<z<27.21 and d<-.85:
   return (2,'observed_central_glazing') if parallel and d> -1.24 else (6,'existing_central_glazing_frame')
  if d>2.7 and z<9.4:return (2,'observed_entry_glazing') if parallel else (4,'entry_reveals')
 elif i==2:
  if L*.35-.03<x<L*.66+.03 and 11.99<z<28.01 and d<-.7:
   return (2,'observed_side_glazing') if parallel and d> -1.0 else (6,'existing_side_glazing_frame')
 if d>.1 and parallel:return (3,'observed_recessed_windows') if i==4 or z<12 else (2,'observed_recessed_windows')
 if not parallel and d>.03:return 4,'observed_window_reveals'
 if i==3 and d<-.15 and z>28:return 4,'observed_existing_upper_frame'
 return 1,'observed_pink_facade'
verts=[];vmap={};faces=[];mats=[];parents=[];labels=[]
def vid(p):
 key=tuple(float(x) for x in p)
 if key not in vmap:vmap[key]=len(verts);verts.append(key)
 return vmap[key]
edge_cache={}
def intersect(a,b,y):
 ka,kb=tuple(a),tuple(b);lo,hi=sorted([ka,kb]);key=(lo,hi,float(y))
 if key not in edge_cache:
  a,b=np.array(lo),np.array(hi);p=a+(b-a)*((y-a[2])/(b[2]-a[2]));p[2]=y;edge_cache[key]=p
 return edge_cache[key]
def clip(poly,y,above):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=(a[2]>=y) if above else (a[2]<=y);ib=(b[2]>=y) if above else (b[2]<=y)
  if ia:out.append(a)
  if ia!=ib:out.append(intersect(a,b,y))
 clean=[]
 for a in out:
  if not clean or not np.array_equal(a,clean[-1]):clean.append(a)
 if len(clean)>1 and np.array_equal(clean[0],clean[-1]):clean.pop()
 return clean
# Global height-plane cuts keep boundary edges conforming. Choose offsets away
# from existing vertices; plane shifts are bounded visual approximations only.
bands=[9.56337,13.71337,17.71337,21.71337,25.71337,29.76337,34.31337,38.81337,43.31337]
cuts=sorted((z+1.2)*scale for b in bands for z in [b,b+.19])
for c in cuts:
 assert np.min(abs(T[:,:,2]-c))>0.0001
for fi,tri in enumerate(T):
 mat,label=category(tri);pieces=[list(tri)]
 for y in cuts:
  if not tri[:,2].min()+1e-10<y<tri[:,2].max()-1e-10:continue
  nxt=[]
  for poly in pieces:
   if min(p[2] for p in poly)<y<max(p[2] for p in poly):nxt.extend([clip(poly,y,False),clip(poly,y,True)])
   else:nxt.append(poly)
  pieces=nxt
 for poly in pieces:
  if len(poly)<3:continue
  ctr=np.mean(poly,axis=0); mm,lab=category(np.array(poly))
  if mm==1 and any(b <= ctr[2]/scale-1.2 <= b+.19 for b in bands):mm=4;lab='observed_light_horizontal_bands_approximate'
  # Convex polygons from clipping a triangle; fan about centroid avoids collinear fan degeneracy.
  if len(poly)==3:ts=[poly]
  else:
   ctr=np.mean(poly,axis=0);ts=[[ctr,a,b] for a,b in zip(poly,poly[1:]+poly[:1])]
  for t in ts:
   if np.linalg.norm(np.cross(t[1]-t[0],t[2]-t[0]))<1e-14:continue
   faces.append([vid(v) for v in t]);mats.append(mm);parents.append(fi);labels.append(lab)
V=np.array(verts);F=np.array(faces);M=np.array(mats);P=np.array(parents)
# Float operations can differ on shared-edge chains. Merge only numerical duplicates
# within 1e-10 mm; retain first original value, never snap to a spatial grid.
from scipy.spatial import cKDTree
pairs=cKDTree(V).query_pairs(1e-10);remap=np.arange(len(V))
for a,b in sorted(pairs):
 while remap[a]!=a:a=remap[a]
 while remap[b]!=b:b=remap[b]
 remap[max(a,b)]=min(a,b)
for i in range(len(V)):
 while remap[i]!=remap[remap[i]]:remap[i]=remap[remap[i]]
unique,inv=np.unique(remap,return_inverse=True);V=V[unique];F=inv[F]
new=trimesh.Trimesh(V,F,process=False);old=trimesh.Trimesh(*[None,None]) if False else mesh
areas=np.bincount(P,weights=new.area_faces,minlength=len(T));oldareas=mesh.area_faces
norm0=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);norm0/=np.linalg.norm(norm0,axis=1)[:,None];norm=norm0[P];plane=np.abs(np.einsum('ij,ikj->ik',norm,V[F]-T[P,0,None,:])).max()
# Per-source face area and plane checks prove planar subdivision, in addition to shell checks.
qa={'original_sha256':hashlib.sha256(raw).hexdigest(),'original_faces':len(T),'appearance_faces':len(F),'appearance_vertices':len(V),'bounds_equal':bool(np.array_equal(new.bounds,mesh.bounds)),'max_per_original_face_area_error_mm2':float(np.max(abs(areas-oldareas))),'max_coplanarity_error_mm':float(plane),'signed_volume_difference_mm3':float(new.volume-mesh.volume),'appearance_watertight':bool(new.is_watertight),'appearance_winding_consistent':bool(new.is_winding_consistent),'appearance_shells':len(new.split(only_watertight=False)),'original_face_provenance_complete':len(set(P))==len(T),'numerical_vertex_merge_tolerance_mm':1e-10,'no_geometry_repair':True,'material_counts':{palette[i][0]:int(np.sum(M==i)) for i in range(len(palette))},'photo_date':'2002-12-08','status':'appearance only; original historical QA untouched'}
assert qa['bounds_equal'] and qa['appearance_watertight'] and qa['appearance_winding_consistent'] and qa['appearance_shells']==1 and plane<1e-9 and max(abs(areas-oldareas))<1e-7 and abs(new.volume-mesh.volume)<1e-7,qa
(OUT/'appearance-geometry-qa.json').write_text(json.dumps(qa,indent=2));(OUT/'appearance-mesh.json').write_text(json.dumps({'vertices':V.tolist(),'faces':F.tolist(),'material_indices':M.tolist(),'source_triangle':P.tolist(),'palette':palette},separators=(',',':')))
(OUT/'material-evidence.json').write_text(json.dumps({'palette':palette,'rules':'Front and two adjacent photographed facades only: pink masonry, green-blue recessed glazing, pale horizontal bands and framing, gray curved canopy. Hidden north/rear/roof remain neutral. Bands and colors are uncalibrated visual approximations. No photo texture, lettering, added window geometry, or silhouette changes.','counts_by_source_label':{s:labels.count(s) for s in sorted(set(labels))},'photo_url':'https://www.flickr.com/photos/techexpo/9357548628/','photo_date':'2002-12-08','photo_sha256':'7e8f88b28b3636041f08e2110c1fc5b75bd6e505b3f6d50104f11a94024b3173','geometry_source_years':[2002,2018,2022,2025]},indent=2))
# 3MF Core base materials preserve triangle-level colors without proprietary slicer data.
NS='http://schemas.microsoft.com/3dmanufacturing/core/2015/02';ET.register_namespace('',NS)
def sub(e,n,**attrs):return ET.SubElement(e,'{'+NS+'}'+n,{k:str(v) for k,v in attrs.items()})
model=ET.Element('{'+NS+'}model',{'unit':'millimeter'});res=sub(model,'resources');bm=sub(res,'basematerials',id=1)
for name,col in palette:sub(bm,'base',name=name,displaycolor=col+'FF')
obj=sub(res,'object',id=2,type='model',pid=1,pindex=0);me=sub(obj,'mesh');vs=sub(me,'vertices');fs=sub(me,'triangles')
for v in V:sub(vs,'vertex',x=format(v[0],'.17g'),y=format(v[1],'.17g'),z=format(v[2],'.17g'))
for f,m in zip(F,M):sub(fs,'triangle',v1=f[0],v2=f[1],v3=f[2],pid=1,p1=m)
sub(sub(model,'build'),'item',objectid=2)
with zipfile.ZipFile(OUT/'appearance.3mf','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
 z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
 z.writestr('3D/3dmodel.model',ET.tostring(model,encoding='utf-8',xml_declaration=True))
print(json.dumps(qa,indent=2))
