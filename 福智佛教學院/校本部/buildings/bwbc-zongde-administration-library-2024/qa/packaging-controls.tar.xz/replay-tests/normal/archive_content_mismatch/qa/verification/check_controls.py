# synthetic helper verification/check_controls.py
