"""Read-only two-mode independent SDNA profiles for hash-bound control fixtures.
Raw diagnostic outputs remain private; the manifest contains only clean fields.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,stat,subprocess,sys
EXPECTED_DECODER='48b96072e1c68b3fd6acd7d5abcc4d0dd8b7b222a81f080e0356fa31da713fd2'
FIELDS=['block_code','struct','field','field_type','field_absolute_byte_offset','marker_absolute_byte_offset','marker_offset_in_field','field_buffer_bytes','field_buffer_sha256','after_first_nul_nonzero_bytes']
def require(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(v):return (json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
def safe(v):return isinstance(v,str) and bool(v) and not v.startswith('/') and '\\' not in v and '\0' not in v and all(x not in ('','.','..') for x in v.split('/')) and PurePosixPath(v).as_posix()==v

def open_absolute_directory(path):
 path=Path(os.path.abspath(path));require(all(x not in ('.','..') for x in path.parts),'Unsafe source-root components');fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in path.parts[1:]:
   child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=child
  return fd
 except Exception:os.close(fd);raise
def source_bytes(rootfd,relative):
 require(safe(relative),'Unsafe relative source');fd=os.dup(rootfd)
 try:
  parts=relative.split('/')
  for part in parts[:-1]:
   child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=child
  filefd=os.open(parts[-1],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
  with os.fdopen(filefd,'rb') as stream:
   before=os.fstat(stream.fileno());require(stat.S_ISREG(before.st_mode),'Candidate is not regular');data=stream.read();after=os.fstat(stream.fileno());require(before.st_size==len(data) and (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'Candidate changed while reading');return data
 finally:os.close(fd)
POLICY_REJECTIONS={'Invalid Blender header','Unsupported control Blend SDNA format','Truncated Blender block','Incomplete or trailing Blender block stream','Missing or duplicated SDNA block','Invalid SDNA tag','Unexpected path field, location or buffer bytes'}

def clean(d):
 require(d.get('passed') is True and d.get('exact_known_generic_field_buffers_only') is True and d.get('source_sha256')==EXPECTED_DECODER,'Decoder evidence differs');findings=d['field_findings'];require(len(findings)==2,'Exactly two known generic fields required')
 return {'blend_sha256':d['blend_sha256'],'version':d['version'],'pointer_bytes':d['pointer_bytes'],'byte_order':d['byte_order'],'field_findings':[{'classification':label,**{k:f[k] for k in FIELDS}} for label,f in zip(['generic_file_browser_home','generic_unrendered_output_default'],findings)]}
def main():
 os.umask(0o077)
 ap=argparse.ArgumentParser();ap.add_argument('--roster',type=Path,required=True);ap.add_argument('--source-root',action='append',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();require(not a.out.exists() and not a.out.is_symlink() and len(os.sched_getaffinity(0))==1,'Fresh output and single CPU required');parentfd=open_absolute_directory(a.out.parent);os.close(parentfd);a.out.mkdir();raw=a.roster.read_bytes();roster=json.loads(raw);candidates=roster['blend_candidates'];require(isinstance(candidates,list),'Missing Blend roster');roots={}
 for entry in a.source_root:
  label,sep,path=entry.partition('=');require(sep and safe(label) and '/' not in label and label not in roots,'Invalid source root');roots[label]=open_absolute_directory(path)
 batch_source=Path(__file__).read_bytes();env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1';decoder=Path(__file__).with_name('audit_control_blend_sdna.py');source=decoder.read_bytes();require(sha(source)==EXPECTED_DECODER,'Unexpected decoder source');accepted=[];rejected=[];seen=set();tracked=[]
 for n,row in enumerate(candidates):
  name=row['source_relative_path'];require(safe(name) and name not in seen and type(row['bytes']) is int,'Unsafe or duplicate candidate');seen.add(name);label,sep,rel=name.partition('/');require(sep and label in roots and safe(rel),'Unknown candidate source');b=source_bytes(roots[label],rel);require(len(b)==row['bytes'] and sha(b)==row['sha256'],'Candidate identity differs');tracked.append((label,rel,row['bytes'],row['sha256']));fixture=a.out/f'{n:05d}-original.blend';fixture.write_bytes(b);profiles=[];diagnostics=[];outcomes=[];reasons=[]
  for mode,opts in [('normal',[]),('optimized',['-O'])]:
   basename=f'{n:05d}-{mode}';result=a.out/(basename+'.json');cp=subprocess.run([sys.executable,'-B',*opts,str(decoder),'--blend',str(fixture),'--expected-sha256',row['sha256'],'--out',str(result)],capture_output=True,text=True,env=env);stdout=a.out/(basename+'.stdout.txt');stderr=a.out/(basename+'.stderr.txt');stdout.write_text(cp.stdout);stderr.write_text(cp.stderr);diag={'mode':mode,'returncode':cp.returncode,'stdout_sha256':sha(stdout.read_bytes()),'stderr_sha256':sha(stderr.read_bytes()),'result_sha256':sha(result.read_bytes()) if result.exists() else None};diagnostics.append(diag);outcomes.append(cp.returncode==0)
   if cp.returncode==0:
    value=json.loads(result.read_text());require(type(value.get('optimization_level')) is int and value['optimization_level']==(0 if mode=='normal' else 1),'Decoder actual optimization mode differs');profiles.append(clean(value))
   else:
    lines=cp.stderr.strip().splitlines();last=lines[-1] if lines else '';prefix='RuntimeError: ';reason=last[len(prefix):] if last.startswith(prefix) else '';require(cp.returncode==1 and reason in POLICY_REJECTIONS,'Unclassified decoder/infrastructure failure');reasons.append(reason)
  require(outcomes[0]==outcomes[1],'Decoder mode acceptance differs');identity={k:row[k] for k in ['source_relative_path','bytes','sha256']}
  if outcomes[0]:
   require(profiles[0]==profiles[1] and profiles[0]['blend_sha256']==row['sha256'],'Decoder mode profile differs');accepted.append({**identity,'kind':'blend_generic_defaults','sdna_profile':profiles[0],'independent_diagnostic_bindings':diagnostics})
  else:
   require(reasons[0]==reasons[1],'Decoder policy rejection differs between modes');rejected.append({**identity,'policy_rejection_verified':True,'policy_rejection':reasons[0],'diagnostics':diagnostics,'reason':'Exact original fixture did not satisfy the independently controlled two-buffer generic SDNA policy; original bytes and diagnostic payload must remain private unless separately reviewed.'})
  require(source_bytes(roots[label],rel)==b and fixture.read_bytes()==b,'Original candidate or diagnostic fixture changed')
 require(a.roster.read_bytes()==raw and decoder.read_bytes()==source and Path(__file__).read_bytes()==batch_source,'Roster/decoder/batch source changed');require(all(len(source_bytes(roots[label],rel))==n and sha(source_bytes(roots[label],rel))==h for label,rel,n,h in tracked),'Original candidate changed after its profile');report={'passed':True,'model_go':False,'candidate_count':len(candidates),'files':accepted,'rejected':rejected,'roster_sha256':sha(raw),'decoder_source_sha256':EXPECTED_DECODER,'batch_source_sha256':sha(batch_source),'all_source_bytes_unchanged':True,'both_mode_profile_equivalence_verified':True,'scope':'Exact per-file private-data profile only. Does not grant model acceptance or generic binary exemption. Public archive scanner independently decodes every accepted original again.'};(a.out/'blend-profiles.json').write_bytes(dump(report));[os.close(fd) for fd in roots.values()];print(json.dumps({'passed':True,'candidates':len(candidates),'accepted':len(accepted),'rejected':len(rejected)}))
if __name__=='__main__':main()
