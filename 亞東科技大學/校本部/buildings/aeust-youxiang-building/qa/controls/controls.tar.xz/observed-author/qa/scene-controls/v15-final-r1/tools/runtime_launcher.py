import hashlib, json, os, runpy, sys
from pathlib import Path
import bpy
args=sys.argv[sys.argv.index('--')+1:]
script=Path(args[0]); target_args=args[1:]
affinity=sorted(os.sched_getaffinity(0))
record={'optimization_level':sys.flags.optimize,'affinity':affinity,
        'blender_version':bpy.app.version_string,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
        'target_argv':target_args,'no_image_render_requested':True}
Path(os.environ['AEUST_RUNTIME_RECORD']).write_text(json.dumps(record,indent=2)+'\n')
if sys.flags.optimize!=int(os.environ['AEUST_EXPECTED_OPT']):raise RuntimeError('Child optimization level mismatch')
if affinity!=[int(os.environ['AEUST_EXPECTED_CPU'])]:raise RuntimeError('Child CPU affinity mismatch')
sys.argv=['blender','--',*target_args]
runpy.run_path(str(script),run_name='__main__')
