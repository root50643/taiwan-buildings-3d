# 共善樓外觀配色：最小完整離線重建源包

從此目錄執行：

1. Python 3.12 建立虛擬環境，pip install -r requirements-rebuild.txt
2. 安裝官方 Blender 4.3.2，確認 blender 在 PATH
3. python rebuild_all.py

輸出在 payload/逢甲大學/水湳新校區/buildings/fcu-gongshan/。
每一階段都有獨立腳本：build_appearance.py、render_appearance.py、run_original_checks.py、verify_appearance.py、verify_edit_roundtrip.py、prepare_docs.py。
原始model.stl只讀；build_model.py只在臨時目錄重建QA。來源STL與原Blend來自固定遠端commit並核對雜湊。新配色mesh不是遺失前版的bytes恢復。

原嚴格component檢查因62個>1%警示預期exit1，重建流程保留原始exit並驗證其他檢查成功，不改門檻。3類原例外仍保留。色彩與條帶為照片支持的近似，無新鄰樓。沒有切片器或實體試印。

原始官方照片不在此包；只列URL及SHA256於photo-evidence.json。離線重建不需重新下載照片。需重新人工檢視時按URL取得並核對hash。不得稱日期未知照片為2026現況。

來源包不含虛擬環境、帳號、憑證或來源照片。manifest-source.json記錄每一源檔bytes/hash。Blender與3MF容器metadata可能隨時間或工具版本不同；重現以mesh/material/provenance及QA為準，不聲稱容器bytes永遠一致。
