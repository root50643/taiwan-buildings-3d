# Reused generic checkers, newly executed evidence required
These generic original-STL checking programs were copied from the locally restored public USC package solely as verification tools. No report, result, pass status, control output, or waiver was copied. Every claimed result for BWBC must bind to the newly exported BWBC STL SHA-256 and the actual checker inventory used by that run.
