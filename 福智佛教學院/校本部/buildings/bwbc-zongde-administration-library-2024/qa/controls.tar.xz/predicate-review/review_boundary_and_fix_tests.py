from pathlib import Path
from fractions import Fraction as F
import contextlib, gzip, hashlib, importlib.util, io, json, struct, sys
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current',ROOT.parent/'independent-tools/exact_ray_diagnosis.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def cube(a,b):
 x0,y0,z0=a;x1,y1,z1=b;v=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)];faces=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(1,2,6),(1,6,5),(2,3,7),(2,7,6),(3,0,4),(3,4,7)];return [tuple(v[i] for i in f) for f in faces]
def encode(ts):return bytes(80)+struct.pack('<I',len(ts))+b''.join(struct.pack('<12fH',0,0,1,*(v for p in t for v in p),0) for t in ts)
rows=[]
def check(name,c,**fields):
 if not c:raise RuntimeError(name)
 rows.append(dict(test=name,passed=True,**fields))
outer=cube((0,0,0),(60,60,60));inner=[tuple(reversed(t)) for t in cube((40,20,3),(50,30,5))]
row=m.Mesh(outer+inner,5).diagnose(0,0);states=[x['state'] for x in row['classified_open_intervals']]
check('cavity_boundary_glide_stops_conservative_chord',states==['inside','boundary','inside','outside'] and row['conservative_first_surface_chord_squared_mm2_exact']=='9/25' and not row['conservative_first_surface_chord_ge_0p8mm'],states=states,squared=row['conservative_first_surface_chord_squared_mm2_exact'])
# A tetrahedral cavity touches the ray at a single vertex, without an interval.
p=[(40,20,3),(45,20,2),(40,25,2),(45,25,4)];cavity=[]
for opposite in range(4):
 t=tuple(p[j] for j in range(4) if j!=opposite)
 # Choose normals pointing into tetrahedron = outward normals for material.
 if m.dot(m.cross(m.sub(t[1],t[0]),m.sub(t[2],t[0])),m.sub(p[opposite],t[0]))<0:t=tuple(reversed(t))
 cavity.append(t)
row=m.Mesh(outer+cavity,5).diagnose(0,0);states=[x['state'] for x in row['classified_open_intervals']]
check('tangent_vertex_stops_chord_before_reentry',states==['inside','inside','outside'] and row['conservative_first_surface_chord_squared_mm2_exact']=='9/25' and not row['conservative_first_surface_chord_ge_0p8mm'],states=states,squared=row['conservative_first_surface_chord_squared_mm2_exact'])
# Re-run precisely the input-change defect against the parent's corrected file.
suffix='optimized' if sys.flags.optimize else 'normal'
stl=ROOT/f'fixed-hash-{suffix}.stl';flags=ROOT/f'fixed-hash-{suffix}.json.gz';out=ROOT/f'fixed-hash-result-{suffix}'
stl.write_bytes(encode(cube((0,0,0),(10,10,10))))
with gzip.open(flags,'wt') as f:json.dump([dict(original_face_index=0,sample_index=0,reasons=['synthetic'])],f)
original=m.Mesh.diagnose
def mutate(self,*args):
 row=original(self,*args)
 with flags.open('ab') as f:f.write(b'changed-after-input-read')
 return row
m.Mesh.diagnose=mutate
sys.argv=['exact_ray_diagnosis.py','--stl',str(stl),'--flags',str(flags),'--expected-sha256',hashlib.sha256(stl.read_bytes()).hexdigest(),'--out',str(out)]
with contextlib.redirect_stdout(io.StringIO()):code=m.main()
report=json.loads((out/'exact-ray-summary.json').read_text())
check('input_mutation_fails_closed_after_fix',code==1 and all(report[k] is False for k in ['completed','all_selected_rays_exactly_classified','all_selected_first_chords_ge_0p8mm','all_selected_outward_offsets_clear']) and report.get('error')=='Original input changed during diagnosis',exit_code=code,summary=report)
summary=dict(passed=True,case_count=len(rows),optimization_level=sys.flags.optimize,reviewed_source_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),cases=rows)
(ROOT/f'boundary-and-fix-{suffix}.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='cases'}))
