"""Fresh final-scene controls for the narrow HDUT view/camera adapter.
All scene mutants stay isolated. No image is rendered and original inputs stay exact.
"""
from pathlib import Path
import argparse,copy,hashlib,json,os,shutil,subprocess,sys

def require(value,message):
    if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();require(not a.out.exists(),'Fresh output required');a.out.mkdir(parents=True)
    run=a.run.resolve();out=a.out.resolve();execution=json.loads((run/'independent-execution-summary.json').read_text());require(execution['completed'] is True,'Completed frozen execution required')
    version=execution['version'];frozen=run/'frozen';model=frozen/'models'/version;manifest=frozen/'previews'/version/'render-manifest.json';tool=frozen/'qa/render-tools';stl=model/'model.stl';blend=model/'scene.blend';expected=execution['stl_sha256'];require(sha(stl)==expected,'Frozen STL changed')
    tracked=[stl,blend,manifest,model/'render_preview.py',model/'parameters.json',model/'color-regions.json',*[tool/n for n in ['make_render_negative_fixtures.py','inspect_and_rerender_blend.py','compare_source_scene.py','png_exact_compare.py']]];initial={str(p):sha(p) for p in tracked};rows=[]
    def execute(label,script,args,mode):
        env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
        if mode=='optimized':env['PYTHONOPTIMIZE']='1'
        command=['blender','--background','--threads','1','--python-use-system-env','--python-exit-code','1','--python',str(script),'--',*map(str,args)]
        log=out/'logs'/(label+'.log');log.parent.mkdir(exist_ok=True)
        with log.open('w') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,env=env)
        return result.returncode,sha(log)
    code,loghash=execute('make-mutants',tool/'make_render_negative_fixtures.py',['--blend',blend,'--manifest',manifest,'--out',out/'fixtures'],'normal');require(code==0,'Fixture generation failed')
    original=json.loads(manifest.read_text());shift=copy.deepcopy(original);shift['views']['courtyard-gallery']['camera'][0][0]+=1
    write(out/'fixtures/shifted-camera/render-manifest.json',shift)
    def inspect(name,mode,expected_accept,flag=None,error=None):
        src=out/'fixtures'/name if name!='unchanged' else None;b=src/'scene.blend' if src else blend;mf=src/'render-manifest.json' if src else manifest;dest=out/mode/('inspect-'+name)
        code,lh=execute(mode+'-inspect-'+name,tool/'inspect_and_rerender_blend.py',['--blend',b,'--stl',stl,'--manifest',mf,'--expected-sha256',expected,'--out',dest,'--inspect-only'],mode);report=json.loads((dest/'blend-rerender-audit.json').read_text());accepted=report.get('passed') is True
        reason=(report.get('checks',{}).get(flag) is False) if flag else (error in report.get('error','')) if error else True
        verified=accepted is expected_accept and code==(0 if expected_accept else 1) and reason and report.get('inspect_only',True) is True
        row={'mode':mode,'case':'inspect-'+name,'expected_accept':expected_accept,'accepted':accepted,'returncode':code,'expected_false_flag':flag,'expected_error':error,'passed':verified,'report_sha256':sha(dest/'blend-rerender-audit.json'),'private_log_sha256':lh};rows.append(row);require(verified,'Inspection control failed: '+mode+'/'+name)
    def scene(name,mode,expected_accept):
        base=out/mode/('scene-'+name);repro=base/'reproduction';(repro/'source').mkdir(parents=True);m=repro/'models'/version;m.mkdir(parents=True)
        for filename in ['model.stl','color-regions.json','parameters.json']:shutil.copyfile(model/filename,m/filename)
        shutil.copyfile(model/'render_preview.py',repro/'source/render_preview.py')
        b=(out/'fixtures/material-changed/scene.blend') if name=='material-changed' else blend;mf=(out/'fixtures/shifted-camera/render-manifest.json') if name=='shifted-camera' else manifest;dest=base/'comparison'
        code,lh=execute(mode+'-scene-'+name,tool/'compare_source_scene.py',['--source',repro/'source/render_preview.py','--version',version,'--original-blend',b,'--manifest',mf,'--expected-stl-sha256',expected,'--out',dest],mode);report=json.loads((dest/'source-scene-audit.json').read_text());accepted=report.get('passed') is True
        reason=report.get('state_difference_count',0)>0 and any('/materials/wall/' in d for d in report.get('state_differences',[])) if name=='material-changed' else report.get('camera_definition_checks',{}).get('courtyard-gallery') is False if name=='shifted-camera' else True
        verified=accepted is expected_accept and code==(0 if expected_accept else 1) and reason
        row={'mode':mode,'case':'source-'+name,'expected_accept':expected_accept,'accepted':accepted,'returncode':code,'expected_rejection_kind':name if not expected_accept else None,'passed':verified,'report_sha256':sha(dest/'source-scene-audit.json'),'private_log_sha256':lh};rows.append(row);require(verified,'Source-scene control failed: '+mode+'/'+name)
    for mode in ['normal','optimized']:
        inspect('unchanged',mode,True)
        for name,flag in [('lens26','saved_initial_camera_matches_front'),('samples32','exactly_64_samples'),('denoising-on','denoising_disabled')]:inspect(name,mode,False,flag=flag)
        for name in ['wrong-view-set','missing-view','extra-view']:inspect(name,mode,False,error='View manifest does not contain exactly the nine required views')
        for name in ['projection-changed','declared-lens-changed']:inspect(name,mode,False,error='Declared per-view projection/lens differs from fixed HDUT camera policy')
        for name,expected_accept in [('unchanged',True),('material-changed',False),('shifted-camera',False)]:scene(name,mode,expected_accept)
    require(all(sha(p)==h for p,h in initial.items()),'Original input/tool changed')
    write(out/'results.json',{'passed':True,'case_count':len(rows),'version':version,'stl_sha256':expected,'original_blend_sha256':sha(blend),'original_manifest_sha256':sha(manifest),'test_source_sha256':sha(__file__),'tools_sha256':{p.name:sha(p) for p in tracked if p.parent==tool},'all_original_inputs_unchanged':True,'no_images_rendered':True,'cases':rows,'scope':'Fresh normal/-O checks of the final frozen scene and exact camera definitions, using isolated scene/manifest mutations. Includes source-state material mutation and non-front camera-position mutation. No geometry acceptance is inferred from these controls.'})
    print(json.dumps({'passed':True,'case_count':len(rows)}))
if __name__=='__main__':main()
