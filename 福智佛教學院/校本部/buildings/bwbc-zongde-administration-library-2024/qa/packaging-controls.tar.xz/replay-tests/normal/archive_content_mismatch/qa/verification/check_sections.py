# synthetic helper verification/check_sections.py
