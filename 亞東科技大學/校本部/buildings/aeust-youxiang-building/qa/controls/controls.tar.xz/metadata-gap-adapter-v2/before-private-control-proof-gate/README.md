# Historical metadata acknowledgment v2: explicit source-copy chain

## Status and scope

Prepared source and tests only. Neither v2 Python file was executed, imported,
compiled, scanned or tested during preparation. No production acknowledgment or
active production plan was created. The first original finalize's 409 HOLDs are
ineligible. Pure controls are never evidence that production has run or that the
model is GO.

The original v1 source, test and README remain byte-identical. The parent also
retained their separate `before-required-scope-gates` snapshot. This new directory
contains the independent v2 sources, complete v1-to-v2 diffs and provenance.
The frozen original generator, v2 scanner, public helper and all existing
HOLD/results files are untouched.

This revision fixes two specific v1 policy gaps:

1. Deferred direct sources must be exactly the original nine paths, not an
   arbitrary subset of the base181 public contract.
2. Required proof closure explicitly includes terminal references, adapter
   sources/tests/preinventory, control results, original plans/results/outputs,
   inventories, all actual proof-document reads and upstream chain proofs. Each
   is rejected if it uses the historical gap's path or byte identity. Snapshot
   hashing alone does not make the newer current WORK-STATE a required proof.

It also introduces an independently verified, exact-four source-copy chain.

## Only historical identity eligible for acknowledgment

- `source_relative_path`: `independent/WORK-STATE.json`
- `bytes`: `3814`
- `sha256`: `6e3f0b0e1e31a2e0385ecf3b66bad84158d4d1afaa0a231e60096740f8f17faf`

The historical private progress-state bytes are unavailable. The old baseline's
exact descriptor, original missing list, `historical_descriptor_only` and
`retained_at:null` are preserved. No bytes are reconstructed. A newer current
version at that same path is a separate retained original; it may not be used as
a required terminal/source/control/proof dependency for this acknowledgment.

Every successful derivative explicitly says `all_historical_retained:false`,
`gap_acknowledged:true`, and `model_go:false`. Scientific producer verdicts,
including original numerical strict=false, never change.

## Explicit original-five to remaining-one chain

The original generator is still pinned to SHA256
`60633de97fbb0e39e565b44e94cc6f8174eb81405eca6ba246ff4fc11695d786`.
Its original result, generating plan and every one of its eight outputs are read
and exact-hash bound. The raw original result permanently remains `passed:false`
and `hold_count:5` in the chained path.

Its five HOLDs must be exactly:

- Four `Decoded byte safety limit exceeded` findings, with the original exact
  scan reason, for `independent/handoff-controls-{normal,optimized}-v15/fixture/`
  followed by `qa/v15-full/{normal,optimized}/standard/dense/dense-original.csv.xz`
- One original historical-missing finding containing only the eligible WORK-STATE
  descriptor above

Each of the four copy identities is 31,965,628 bytes with SHA256
`c628b2150cecf8b894bf3f0716b5e60420bec9e77eec31c320ad8e34456b4016`.

An independently prepared source-copy adapter first resolves only those four
copy dispositions. The metadata adapter does not import or execute its code.
It independently validates:

- The source-copy adapter's exact pinned source/test and reviewed normal/-O
  30-case control result identities, all already publicly selected in raw606
- Its original-result, original-plan and all eight original-output references
- Its complete graph evidence, fixed source/freeze/producer/control anchors,
  original 15-case handoff controls, exact four copy and four canonical science
  identities, complete mapping counts and original strict-false science evidence
- Every referenced proof source's actual bytes and its required-set gap exclusion
- Exactly four new private omissions, with the fixed category
  `duplicate_reproduction_or_scratch` and fixed complete rationale
- Exactly those four inventory-row disposition/category/reason changes, plus
  the recomputed disposition counts
- Original selection file rows unchanged, original historical accounting and
  missing list unchanged, and findings reduced to precisely the original gap
- Whole-document equality against the independent allowed transformation:
  no extra field, row, readiness promotion or unrelated HOLD removal is allowed
- The full explicit transition: original five, four copies resolved, one remains,
  `historical_gap_acknowledged:false`, unchanged canonical full-stream privacy
  requirement, unchanged 512 MiB generic decoded-byte limit, and `model_go:false`

Only then does v2 apply its historical-gap gate to the remaining one HOLD. This
internal gate input is labeled as derived metadata, never as a native raw606
result. The final report says `original_hold_count:5`, `original_passed:false`,
`acknowledged_input_hold_count:1`, and
`input_stage:source_copy_derived_remaining_gap`.

The existing native-one route remains available only when no source-copy chain
is requested and raw606 itself has exactly the single eligible historical HOLD.
It retains every original v1 exact identity, disposition, terminal, scanner,
freeze and source-unchanged gate, with v2's strengthened proof/deferred checks.
There is no route for arbitrary 4/5-HOLD sets or the initial 409-HOLD result.

## Frozen upstream source-copy identities

The source-copy adapter's existing paths are under
`independent/public-preparation/source-copy-adapter-v1/`:

- `source_copy_duplicate_adapter.py`, 43962 bytes, SHA256
  `76aa6c42900004cf367fc616df12cbf8c667fb2c848fbbe546454f7e8ccc6e31`
- `test_source_copy_duplicate_adapter.py`, 51278 bytes, SHA256
  `ba50d20a2a499d826aa7042f9a975f8051f8f166fd1e552026933cbb7a090bd6`

Both upstream results are 43363 bytes and have schema
`aeust-exact-source-copy-controls-v1`, 30 cases, 2 positive and 28 negative:

- `independent/source-copy-controls-normal-v15/results.json`, SHA256
  `6500c375b9a339f4e2eb2d6733dbca542f95ec03ffe608c492c0783e412eb7e6`
- `independent/source-copy-controls-optimized-v15/results.json`, SHA256
  `99a30733e6b70f1f71af33958c6eec84639e0faa2442b0b3ec0dece160927a54`

The parent reported those upstream synthetic runs completed successfully. This
worker only read their evidence; it did not execute them. They do not imply
source-copy production or metadata production has occurred. The parent-reviewed
v2 plan must still specify those same complete exact references.

## Complete required sets and the exact nine deferrals

The four original anchor references remain mandatory:

- `science`: `author/qa/V15-SCIENTIFIC-HANDOFF-FREEZE.json`, SHA256
  `a46bf5d5eba7ba570dd0bd4adb832663f43146858751118d619b18f2ceab6224`
- `runner`: `independent/V15-RUNNER-FREEZE-ADAPTER.json`, SHA256
  `11794b224ea898237e21a54b387956ba2cfbab26c8161e2da1be467f0474d368`
- `tooling`: `independent/FINAL-INDEPENDENT-TOOLING-FREEZE.json`, SHA256
  `68c9fa4e5a0f9fb555b4b48d6ca37545711a2eac467d56e03f8ecaeaf29c05fa`
- `public_base`: `independent/public-preparation/PUBLIC-DIRECT-PATH-CONTRACT.json`,
  SHA256 `508bf1f9ae233f221952e45f6e550e44f881849125210a4e8e82ce7ea8a7235d`

Science3690, runner3691, tooling, base181, the active original-plan direct map,
seed selection, replay requirements, malformed/negative proof dependencies and
all other required proof sources are individually exact-bound. The old gap's
path and identity must both be absent. Active direct mappings must preserve all
base181 rows exactly. Additional active rows must exist and match their current
identities; they do not increase the deferral permission.

The only deferred paths are `independent/public-controls-v15/` plus exactly:

1. `controls-index.json`
2. `controls-selection.json`
3. `controls.tar.xz`
4. `malformed-fixture-allowlist.json`
5. `negative-archive-allowlist.json`
6. `package_controls_v2.py`
7. `packaging-result.json`
8. `privacy-allowlist.json`
9. `replay-verification.json`

Duplicate entries, fewer paths, extra paths or substituting another base181 path
are refused. Future bytes and hashes are never invented.

## Original snapshot and exact post-finalize additions

The whole raw606 current snapshot is rehashed and compared by path, bytes/SHA and
inode identity. Its original nine finite generated metadata files remain bound
by the original result. Newly generated source-copy artifacts are allowed only
as this explicit, individually hash-bound set:

- Its generating invocation plan, with a readable canonical logical reference
- Its four fixed `*-SOURCE-COPY-ACK.json` derivative documents
- Its `source-copy-duplicate-result.json`

The source-copy output directory must be a single
`independent/archive-preparation/source-copy-resolution-*` child, but the
adapter does **not** exclude that directory or prefix. Only the verified exact
filenames above are accounted as post-finalize additions. Any extra log,
untracked sibling, disappeared input or changed original still causes refusal.
No addition may replace an original current snapshot path.

The metadata adapter's own independently SHA-bound invocation plan is similarly
recorded as generated metadata if inside a source root. When outside the roots,
its bytes/hash and inode are rechecked through the explicit CLI path; no private
physical path is included in the public report. Its own fresh derivative
filenames and one temporary pending-report filename are finite output-only
exceptions while writing. `post_finalize_bound_additions` lists the exact
upstream additions and in-root metadata invocation plan, with no wildcard.

## Execution sequence: each production stage once

1. Review v2 source/tests. Parent runs its 26 synthetic controls in normal and
   optimized modes, serially under the approved shared lock, using fresh outputs.
2. Include all new source/test/diff/README/provenance files, both source-copy
   30-case output trees and both metadata 26-case output trees/logs in the next
   original generator complete finalize. Keep source writers quiescent.
3. Complete the authorized current dispositions/proofs. The anticipated raw606
   production result has exactly the four specified CSV HOLDs plus the gap.
   Preserve that original result and all eight raw outputs unchanged.
4. Parent creates an exact source-copy production plan, then runs source-copy
   production **once in normal mode** to a fresh directory. Its raw606 five-HOLD
   input remains unchanged; its derivative leaves the one historical HOLD.
5. Parent creates the exact v2 metadata plan, then runs metadata production
   **once in normal mode** to a fresh directory. It validates the full chain and
   all current original source bytes before publication metadata can be ready.
6. Only after both reports exist may the public worker create a new public
   contract that retains base181 and adds the actual source/control/report
   identities. Do not introduce future report paths into original finalization
   or expand the nine deferred paths to break a hash cycle.

Synthetic controls run in both modes. Production does not run twice merely to
obtain normal/-O labels: a second production output would be a new unexplained
snapshot addition and must not be excused. Any separately authorized optimized
read-only validation of exact existing derivatives is a different operation.
Subsequent archive controls/public verification still use their required two
modes, and the outer archive's 512 MiB bound remains unchanged.

Keep live production stdout/stderr captures outside the finalized roots until
acknowledgment has committed, or use a separately authorized later inventory.
A growing in-root log is a genuine source change. No general log exception exists.

## v2 plan and production CLI

Examples are documentation only, not a preparation execution record:

```sh
python -B acknowledge_metadata_gap.py \
  --plan REVIEWED-METADATA-PLAN.json --plan-sha256 EXACT_PLAN_SHA256 \
  --root "independent=$Q" --root "author=$Q/final-v15-r1/frozen" \
  --out "$Q/archive-preparation/metadata-gap-acknowledgment-r2"
```

The output directory must be absent; its parent must exist and be traversable
without symlinks. Every reference contains canonical `source_relative_path`,
integer `bytes` and lowercase `sha256`. No placeholder descriptor is accepted.

Required plan fields:

- `schema`: `aeust-metadata-gap-acknowledgment-plan-v2`
- `ready_for_gap_acknowledgment:true`, `model_go:false`
- `acknowledged_gap`: the exact sole eligible descriptor
- `original_generator`: exact frozen606 reference
- `original_plan`: exact generating original plan reference
- `original_result`: exact raw606 result reference, never a source-copy report
- `source_inventories`: exactly original-plan `baseline_inventories`, then
  `source_roster`, in that order
- `frozen_sets`: exact `science`, `runner`, `tooling`, `public_base` references
- `adapter_source`, `adapter_test_source`: these exact v2 files
- `adapter_controls`: a list of two v2 result references, mode0 then mode1
- `preinventoried_adapter_files`: exact already-finalized source/test/control
  references, plus intended README/provenance/diff references. The source, test
  and both control results are mandatory; full snapshot checking covers siblings.
- `source_copy_adapter`, for the five-HOLD chain:
  - `result`: the existing `source-copy-duplicate-result.json` exact reference
  - `source`: the pinned upstream adapter source reference
  - `test`: the pinned upstream test source reference
  - `controls`: an object with exact `normal` and `optimized` result references

The exact upstream generating plan is read from its report's `adapter_plan` and
must be a readable logical reference. It is checked against all parent-plan
source/test/control/original-result/original-plan identities. Its report carries
its complete `graph_evidence` and `ref_bound_sources`; both are validated.

## Four outputs and consumer semantics

Output names remain:

- `private-original-payload-inventory-GAP-ACK.json`
- `controls-selection-GAP-ACK.json`
- `private-omissions-GAP-ACK.json`
- `metadata-gap-acknowledgment-result.json`

The first three preserve the original document schemas. In the chained route,
only the previously verified source-copy four-row transformation is inherited.
The historical stage changes readiness and adds explicit disclosure; it never
rewrites the effective `files` arrays or original historical missing/accounting
rows. Every derivative adds `all_historical_retained:false`,
`gap_acknowledged:true`, `model_go:false` and `gap_acknowledgment`.

The report schema is `aeust-metadata-gap-acknowledgment-result-v2`. It contains the
exact original raw result, all eight original outputs, original plan/generator,
source inventories, v2 source/test and both26 control references, complete
required-set evidence/count/digests, exact additions and all three new output
hashes. It also explicitly records:

- `original_hold_count:5` and `original_passed:false` for the chained path
- `acknowledged_input_hold_count:1`
- `input_stage:source_copy_derived_remaining_gap`
- `source_copy_chain`: upstream result/source/test/both30 controls, generating
  plan, all four upstream derivative references, proof references and exact
  transition, retaining original5 and remaining1 separately
- `all_historical_retained:false`, `gap_acknowledged:true`, `model_go:false`
- `original_outputs_rewritten:false`, `missing_bytes_reconstructed:false`,
  `original_scientific_verdict_unchanged:true`, `archive_created:false`

All public report paths are logical references; physical workspace paths and
original private bytes are not published. The original selection's snapshot
coverage flag remains a snapshot statement. It must never be paraphrased as all
historical bytes being retained.

The success report is committed last. Derived payloads are written with
exclusive fd-relative creation, fsynced and read back. A pending report is
written/read back; original sources, snapshots and invocation identities are
rechecked; all derivative identities/inodes and pending bytes are rechecked;
only then is the final report name created without replacement. Failed checks
may leave a partial fresh directory or pending file, but never a valid final
success report. Never reuse that directory or consume its partial metadata.

## Parent-scheduled 26-case controls and public replay layout

The test harness needs only its sibling `acknowledge_metadata_gap.py` and Python
standard-library modules. It has no package installation, root search, v1 import,
source-copy import or external original-data dependency. It hashes and compiles
that sibling's same source bytes once into a module without pycache. It works
from any current working directory when given the correct script path and a
fresh output whose parent exists.

```sh
python -B test_metadata_gap_adapter.py --out FRESH-NORMAL
python -B -O test_metadata_gap_adapter.py --out FRESH-OPTIMIZED
```

Results are `FRESH/report/results.json`, schema
`aeust-metadata-gap-synthetic-controls-v2`, 26 cases, 3 positive and 23 negative,
with exact source/test hashes and optimization level. Results explicitly state
`synthetic_helper_level_not_real_cli`, `real_cli_success_exercised:false`, and
`model_go:false`. No full production CLI success is fabricated.

Suggested public archive layout preserves the two source files as siblings
under `metadata-gap-adapter-v2/`. With an already-created fresh `replay-results`
parent, use:

```sh
python -B metadata-gap-adapter-v2/test_metadata_gap_adapter.py \
  --out replay-results/metadata-gap-normal
python -B -O metadata-gap-adapter-v2/test_metadata_gap_adapter.py \
  --out replay-results/metadata-gap-optimized
```

Never write replay results over archived observations. These new paths do not
modify the original generator's fixed replay-root reservation policy.

The original 16 cases remain: exact gap; newer retained current version at the
same path; wrong path/size/hash; second missing identity; science, runner, public,
replay/seed and malformed/negative/other proof dependencies; extra HOLD;
unresolved current disposition; changed binding; source mutation/replacement;
and unsafe reads/strict JSON/fresh-output refusal.

Ten additions are:

17. Positive exact four-copy-to-one-gap chain, preserving raw original five.
18. Changed upstream source/test binding, including the fixed frozen identities.
19. Changed raw original-output chain reference.
20. A substituted non-four-CSV HOLD or an extra sixth HOLD.
21. An unrelated inventory-row delta in upstream metadata.
22. Widened, narrowed or substituted deferred-source sets.
23. Historical path used as a required proof with a different current identity.
24. Historical old identity used as proof at a different path.
25. Late source failure prevents the final success report.
26. Failed derivative readback or late derivative mutation prevents that report.

Some cases include related subchecks; case totals are not inflated into claims
of independent full production scenarios. CSV/science fixtures in the chain
controls are explicitly synthetic metadata descriptors, not real 32 MB CSV
streams or complete3690/3691 manifests.

The FIFO control records a relative path/type/descriptor SHA and rejection
result. In `finally` it removes only the FIFO it created after checking device,
inode and type; it refuses to delete a substituted endpoint. No FIFO/socket is
left for the later real inventory. Symlinks remain descriptor-only and are never
followed. No Blend or malformed container payload is created by these controls.
