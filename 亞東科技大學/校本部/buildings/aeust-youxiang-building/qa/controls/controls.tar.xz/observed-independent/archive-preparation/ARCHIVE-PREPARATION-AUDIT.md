# AEUST controls archive preparation: static review only

## Result

The fixed snapshot accounts for 8,614 original paths. Every regular file has byte count and SHA256; every symlink has a target-descriptor hash and is never followed. 4,533 original files are public identity-copy candidates. The original sources, positive cases, negative cases, scientific output and replay prerequisites are covered. Current author controls are inventoried separately pending the final freeze. The public selection deliberately remains `passed: false` until integration and runtime verification.

No producer tool, geometry, Blender, test suite, archive construction or archive extraction was executed here. Only read-only file/hash/JSON inspection and AST parsing of the new preparation code were used. No pre-existing file was modified. Outputs are confined to this preparation directory. This is not a model GO, architectural certification or physical-print guarantee.

## Deliverables

- `controls-selection-v1.json`: explicit public file selection with logical source labels, exact bytes/hash and archive destinations; compatible with the new explicit-file v2 schema after review. It is intentionally not accepted by v1's root-only schema.
- `private-original-payload-inventory-v1.json`: complete original snapshot accounting, including private data, logs/cache, nonregular descriptors and pending final controls. This file is private review material, not a public archive member.
- `malformed-fixture-allowlist-v1.json`: 36 selected malformed compressed original payloads, including safe-replay duplicates. Exact raw identity, expected failure, original result/generator hashes and bounded decode method are recorded.
- `negative-archive-fixture-allowlist-v1.json`: 372 exact archive-control inputs with expected rejected nested archive semantics. These cover structural tar mutations as well as compression controls. A sibling failure report alone never authorizes a malformed payload.
- `private-publication-review-findings-v1.json`: exact private-marker findings and narrowly reviewed default-field candidates; never treat the ordinary word token as a credential.
- `replay-plan-v1.json`: public-relative entry points, requirements and fresh-output reservations.
- `package_controls_v2.py`, `test_package_controls_v2.py`: new reviewed code and 101 prepared controls per mode. They have been AST-parsed only; runtime success is not asserted.
- `v2-source-provenance.json` and the two private full diffs: original-v1/new-v2 bindings. Neither v1 source nor its original nine controls was changed.

## Selected dependency closure revision

The preceding v2 source/test/provenance/diffs/docs are preserved byte-for-byte in `v2-before-selected-dependency-gate/`, with an exact snapshot manifest. The current v2 rejects any proof, generator or local result that remains readable from a source root but is absent from the public selection. Every dependency must match the selected SHA256 and byte count. `Scanner.complete()` checks all `Sources.tracked` entries, including future reads outside the proof helper; the package additionally checks those bindings against actual archive copies before publication. Both wrapper and packager proof families have a prepared negative control retaining the exact generator on disk while removing its selection row. Constructors, logical source labels, file/copy schema and public filenames are unchanged. Runtime status remains unexecuted.

## SDNA-bound generic Blend defaults revision

The dependency-closed d9a9/b351 v2 revision is preserved in `v2-before-blend-default-gate/`. The new `blend_generic_defaults` allowance is part of the existing privacy-file list. It binds the logical path, whole-file SHA256 and byte count, and an exact path-free SDNA profile. A bounded read-only parser independently locates `FileSelectParams.dir[1090]` and `Scene.r.pic[1024]` from actual block and struct layouts. It supports only the reviewed Blender 403 / 64-bit / little-endian format. Both complete buffers must match the fixed reviewed hashes, including NUL tails. Caller-supplied offsets or arbitrary buffer hashes cannot authorize an exception.

Only the two first-NUL effective generic strings are replaced with spaces in a temporary scan view. The original blob, all NUL-tail bytes and every other byte remain unchanged. `Scanner.plain()` returns that checked view so the public verifier's extra credential/path checks share the exact same policy. Fourteen prepared controls exercise successful exact binding and public metadata, wrong whole hash/size, wrong buffer/offset/field/type/classification, mutated NUL tail with rebound hashes, extra markers outside the fields, missing allowance and a caller profile inconsistent with actual SDNA.

`blend-generic-default-privacy-contract.json` documents the exact public schema without embedding effective path strings. No actual Blend allowance is generated here: the sixteen inventoried Blend files remain pending until each frozen file receives its own exact actual profile and manifest/proof binding. Runtime remains unexecuted.

## Exact-source loader and finite JSON revision

The reviewed Blend-policy revision is retained in `v2-before-exact-loader-gate/`. Archive tools now load from one read of their source bytes, verify the bound SHA256 and compile/execute those same bytes. Existing timestamp/size-valid Python bytecode caches cannot replace the verified source. A prepared regression control supplies matching poisoned caches for both original archive tools; successful packaging must ignore them. JSON parsing additionally rejects finite-syntax exponents that overflow to nonfinite floating-point values, with both signs covered by prepared controls. The total prepared suite is 101 cases per mode, still unexecuted.

## Exact original payload coverage versus public replay

These are different claims. Original v1 packaging privacy-test source contains prohibited private-path marker literals, and the two old `not xz` inputs depended on that source. Its original bytes stay private and fully hash-accounted. The prepared v2 tests first reject the identical six-byte input with public v2 source, then produce `public-malformed-fixture-allowlist.json` and `original-to-public-replay-binding.json`. Those files record the new public proof alongside the unchanged original proof. They do not rewrite the old result or pretend it had different provenance. The other 34 compressed-negative payloads retain their original public source/proof bindings.

The prepared v2 test source uses an explicit public source map after extraction, so original logical paths resolve to relocated archive members. Final assembly must include the new source, public proof, both mode results and all their dependencies before claiming the public suite is self-contained.

## Privacy and container rules

Private original wrappers, restore ZIP/index, private path-bearing scientific reports and routine logs are explicitly recorded rather than silently dropped. A path marker in scientific JSON never causes a rewritten producer report. Such data remains privately preserved until an authorized public derivative or a reviewed exact exception exists.

There is no general temporary-directory exemption. Eighteen current author scene JSON records have the exact Blender default at `/render/filepath`; future allowances must bind the whole file bytes/hash and that exact pointer/value. Sixteen binary Blend files await per-file actual SDNA profiles under the new fixed-buffer policy; no entry is automatically enabled by filename or by matching a generic string. Credential scans recognize credential-shaped patterns; code keywords are not secrets. Reference photographs are outside the selected roots and unapproved photo formats remain private.

For approved negative compressed inputs, scan raw bytes, decoded recoverable prefix and exact unused tail, while preserving the entire original input unchanged. Unknown malformed streams, extra tails, missing/mutated proofs or source changes reject. Nested tar/ZIP contents are inspected only in memory. Link/unsafe member names remain inert data; no nested fixture is extracted. Ordinary tar padding, terminators and ZIP directory entries fail closed. Only exact hash-bound negative tar fixtures receive structural exceptions.

The outer package still uses the original strict USTAR/single-XZ verifier. Every outer member must have its exact bytes/hash, ordinary type and safe path. Safe extraction goes to a fresh owner-only directory using the original fd-relative implementation, followed by all-member readback and bitwise rebuild using the original builder.

## Layout and replay

Keep `tooling/`, `independent-tools/` and `synthetic-recorded-ray/` at archive root. Original completed wrapper outputs and summaries belong in `observed-independent/`. Do not pre-create the fixed wrapper output directories or `replay-results/` in the archive. The wrapper reviewers read both recorded synthetic baseline modes and write only their fresh root output names. The two private shell orchestrators are not public entry points.

Relative replay commands and package metadata are recorded separately from legacy observed provenance. Existing observed `ARCHIVE-SCOPE.json` commands retain their original bytes and are run only from their own nested legacy source directory. The new outer archive's trusted replay plan is authoritative for root-level execution.

## Remaining gates

The current release is HOLD. Run normal and optimized v2 controls under the shared lock; add new sources/proofs/results and frozen author/final independent controls; review every pending private-path/default finding; verify all original payload coverage; construct the archive; then verify outer safe extraction, every member hash, deterministic rebuild and all public replay paths. Final model postflight and render controls remain explicitly pending and cannot be inferred from synthetic tool success.
