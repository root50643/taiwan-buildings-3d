"""Control-flow tests using synthetic row-result injection, not model findings."""
from pathlib import Path
import contextlib,csv,gzip,importlib.util,io,json,lzma,shutil,sys
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'synthetic-recorded-ray';MODE='optimized' if sys.flags.optimize else 'normal'
BASE=ROOT.parent/f'wrapper-exit-final-tests-{MODE}';BASE.mkdir();sys.path.insert(0,str(ROOT.parent/'tooling/tools'))
results=[]
for version,folder,expected_exit in [('final','wrapper-snapshot-final',1)]:
 for scenario in ['classified_short_row','partial_selected_coverage']:
  spec=importlib.util.spec_from_file_location('wrapper_'+version+'_'+scenario,ROOT.parent/'tooling/tools/diagnose_recorded_cpp_rays.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  p=BASE/(version+'-'+scenario);p.mkdir();shutil.copy2(SOURCE/'fixture.stl',p/'fixture.stl');src=SOURCE/'normal'
  for a,b in [(src/'raw/raw-mesh-check.json','raw.json'),(src/'intersections.json','intersections.json'),(src/'dense/dense-check.json','dense.json'),(src/'dense/dense-flagged-samples.json.gz','flags.json.gz'),(src/'dense/dense-original.csv.xz','dense-original.csv.xz')]:shutil.copy2(a,p/b)
  extra=[]
  if scenario=='classified_short_row':
   original=m.classify
   def injected(*args):
    row=original(*args);row.update(conservative_first_solid_chord_squared_mm2_exact='1/4',conservative_first_solid_chord_mm_approx=0.5,conservative_first_solid_chord_ge_0p8mm=False);return row
   m.classify=injected
  else:
   with gzip.open(p/'flags.json.gz','rt') as f:flags=json.load(f)
   with lzma.open(p/'dense-original.csv.xz','rt') as f:second=next(csv.DictReader(f))
   flags.append(dict(original_face_index=int(second['face']),sample_index=int(second['sample']),original_cpp_row=second,reasons=['synthetic additional selected key for control-flow test']))
   with gzip.open(p/'flags.json.gz','wt') as f:json.dump(flags,f)
   report=json.loads((p/'dense.json').read_text());report['flagged_samples_sha256']=m.sha(p/'flags.json.gz');report['flagged_sample_count']=len(flags);(p/'dense.json').write_text(json.dumps(report));extra=['--limit','1']
  sys.argv=['wrapper','--stl',str(p/'fixture.stl'),'--flags',str(p/'flags.json.gz'),'--dense-report',str(p/'dense.json'),'--raw-report',str(p/'raw.json'),'--intersections-report',str(p/'intersections.json'),'--expected-sha256',m.sha(p/'fixture.stl'),'--out',str(p/'result')]+extra
  with contextlib.redirect_stdout(io.StringIO()):code=m.main()
  report=json.loads((p/'result/exact-recorded-ray-summary.json').read_text())
  m.require(code==expected_exit and report['completed'] and report['all_selected_rays_exactly_classified'],'Exit/completion semantics mismatch')
  m.require((not report['all_selected_first_chords_ge_0p8mm']) if scenario=='classified_short_row' else (not report['all_flagged_samples_selected']),'Expected rejection condition missing')
  results.append(dict(version=version,scenario=scenario,passed=True,exit_code=code,completed=report['completed'],all_classified=report['all_selected_rays_exactly_classified'],all_thick=report['all_selected_first_chords_ge_0p8mm'],all_flags_selected=report['all_flagged_samples_selected'],source_sha256=m.sha(Path(m.__file__))))
summary=dict(passed=True,case_count=len(results),optimization_level=sys.flags.optimize,scope='Unit control-flow only. The short-row result is deliberately injected after classification; it is not a measurement of the glide fixture. Partial coverage uses an additional synthetic flag for another authentic CSV row.',cases=results)
(ROOT.parent/f'wrapper-exit-final-semantics-{MODE}.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
