# synthetic helper independent-tools/png_exact_compare.py
