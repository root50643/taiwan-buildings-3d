"""Serial pure synthetic inventory controls; caller owns the shared heavy lock."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
Q=Path(__file__).resolve().parents[1]
P=Q/'archive-preparation'
def require(value,message):
    if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def main():
    require(len(os.sched_getaffinity(0))==1,'One CPU required')
    require(json.loads((Q/'packaging-controls-v15-r1/results.json').read_text())['passed'] is True,'Prior packaging controls required')
    freeze_path=Q/'INVENTORY-CONTROLS-TOOLING-FREEZE-v15.json'
    freeze=json.loads(freeze_path.read_text())
    def sources_ok():return all(sha(Q/k)==v['sha256'] and (Q/k).stat().st_size==v['bytes'] for k,v in freeze['files'].items())
    require(sources_ok(),'Frozen inventory control source differs')
    out=Q/'inventory-controls-v15-r1';out.mkdir(exist_ok=False)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1');env.pop('PYTHONOPTIMIZE',None)
    rows=[]
    for mode,opts in [('normal',[]),('optimized',['-O'])]:
        result_root=P/('generator-controls-'+mode+'-v1')
        cmd=[sys.executable,'-B',*opts,str(P/'test_generate_final_inventory.py'),'--out',str(result_root)]
        log=out/(mode+'.log');start=time.time()
        with log.open('w') as stream:cp=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=Q)
        row={'mode':mode,'command':cmd,'returncode':cp.returncode,'elapsed_seconds':time.time()-start,'log_sha256':sha(log)};rows.append(row);write(out/'executions.json',rows)
        print(json.dumps({'mode':mode,'returncode':cp.returncode}),flush=True)
        require(cp.returncode==0,'Inventory controls failed '+mode)
        result=result_root/'results.json';d=json.loads(result.read_text())
        require(d['passed'] is True and d['case_count']==45 and d['optimization_level']==(0 if mode=='normal' else 1),'Complete inventory controls differ')
        row['result_sha256']=sha(result);row['cases']=45
    require(sources_ok(),'Inventory control sources changed')
    write(out/'results.json',{'passed':True,'model_go':False,'all_sources_unchanged':True,'tooling_freeze_sha256':sha(freeze_path),'executions':rows,'scope':'Pure synthetic final-inventory controls only; actual full inventory and publication remain separate.'})
if __name__=='__main__':main()
