"""Offline complete rebuild. Install requirements-rebuild.txt and Blender 4.3.2 first."""
from pathlib import Path
import subprocess,sys,shutil,json,hashlib
R=Path(__file__).resolve().parent;S=R/'source/repo/逢甲大學/水湳新校區/buildings/fcu-gongshan';Q=R/'qa-original';Q.mkdir(exist_ok=True)
for p in S.iterdir():
 if p.is_file():shutil.copy2(p,Q/p.name)
for cmd in [[sys.executable,'build_appearance.py'],['blender','-b','-t','4','--python-exit-code','1','-P',str(R/'render_appearance.py')],[sys.executable,'run_original_checks.py'],[sys.executable,'verify_appearance.py'],[sys.executable,'verify_edit_roundtrip.py'],[sys.executable,'prepare_docs.py']]:
 subprocess.run(cmd,cwd=R,check=True)
print('Rebuild complete. The original strict component test intentionally remains exit 1 for 62 unchanged warnings.')
