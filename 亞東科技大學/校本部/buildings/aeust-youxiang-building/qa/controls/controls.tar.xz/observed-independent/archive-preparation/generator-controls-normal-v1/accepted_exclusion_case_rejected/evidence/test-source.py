# synthetic exclusion test generator
