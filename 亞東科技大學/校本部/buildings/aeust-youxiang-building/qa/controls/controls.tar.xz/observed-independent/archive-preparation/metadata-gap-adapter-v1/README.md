# Historical progress-metadata acknowledgment adapter, v1

## Preparation status and limits

This directory contains newly prepared source and a 16-case **synthetic,
helper-level** control suite. During preparation neither source was executed,
imported, compiled, scanned or tested. No real acknowledgment plan was created.
No successful real production CLI run is claimed. The first original finalize
result in `final-inventory-r1` has 409 HOLDs and is expressly ineligible.

The adapter does not edit the original generator, scanner, public helper, source
inventory, selection, omissions, findings, results or HOLD evidence. It does not
run geometry, Blender, scanners, compression, extraction, archive assembly or a
model acceptance decision. It does not reconstruct unavailable bytes.

The sole eligible historical descriptor is:

- `source_relative_path`: `independent/WORK-STATE.json`
- `bytes`: `3814`
- `sha256`: `6e3f0b0e1e31a2e0385ecf3b66bad84158d4d1afaa0a231e60096740f8f17faf`

That identity is a historical private progress-state record from the exact old
`private-original-payload-inventory-v1.json`. Its original bytes have not been
found. A currently present file at that path is a different version; its current
original bytes must remain separately accounted. This acknowledgment cannot be
applied to any other path, size, identity, missing version or unresolved HOLD.

## Safety and policy gates

Production acceptance requires every condition below:

1. A parent-reviewed adapter plan is independently bound by `--plan-sha256`.
2. The original generator is exactly SHA256
   `60633de97fbb0e39e565b44e94cc6f8174eb81405eca6ba246ff4fc11695d786`.
   Its result, generating plan, all eight output files, baseline inventories and
   roster are independently exact-byte bound. The generator is never imported.
3. Original `passed=false`, `model_go=false`, `hold_count=1`; the findings `holds`
   array is exactly one original historical-missing finding with exactly the
   descriptor above. The inventory's missing list is exactly that descriptor;
   its sole historical descriptor-only row still has `retained_at:null`.
4. Every current regular-file row has a complete selected, direct or private
   disposition. Selected and omitted identities, destinations and private
   categories/reasons agree with the original rows. Only the original three
   generated allowlist sidecars may be selected outside the original snapshot.
5. Original terminal requirements equal the original plan and their exact
   referenced JSON assertions are reevaluated. The frozen scanner/helper hashes
   and `all_source_bytes_unchanged=true` are verified. The original result has no
   fabricated `generator_source_sha256` or `all_scanner_passed` field. Scanner
   closure is inferred narrowly from the exact generator implementation, the
   exact sole historical HOLD and the complete dispositions. No scanner rerun
   is claimed.
6. The original science3690, runner3691, tooling freeze, fixed base181 direct
   mapping, active original-generator direct mapping, seed selection, replay
   requirements and malformed/negative/other proof dependencies are individually
   exact-bound against current regular originals. Both the historical path and
   old byte identity must be absent from every required family. Proof result,
   generator and local-result paths retain their own SHA bindings. The base181
   rows must be an unchanged subset of an already-existing active direct map;
   additional active rows are checked too. No wider future-output deferral is
   introduced. Absent original nine future direct products remain explicitly
   deferred, with no invented hash or claim that they exist.
7. The historical accounting is reproduced from all original baseline/roster
   rows, including original prior dispositions. No historical row is removed.
8. The adapter source, test source and both-mode 16-case results must already be
   exact current originals in the **next original generator complete finalize**.
   All fixture/output siblings also fall within that complete snapshot. Results
   must bind both exact source hashes, optimization modes 0 and 1, ordered case
   names, 2 positive/14 negative expectations, and the helper-level scope.
9. The whole finalized source tree is hashed again with the same logical alias
   policy. No new or disappeared input may be silently ignored. Only the
   original generator's exact nine generated metadata names and the one
   independently bound invocation-plan file, if inside a source root, may be
   excluded. A second full snapshot and each bound input's hash/inode identity
   must agree. After writing derived documents, all originals are checked again
   before committing the success report last.

All source directory and leaf opens are fd-relative with `O_NOFOLLOW`; leaf
reads also use `O_NONBLOCK`, then require a regular file, so FIFO reads cannot
block. Symlinks in ordinary reads are rejected; inventory link descriptors are
read without following. Reads compare before/after/named file identity including
inode, size and nanosecond times. JSON rejects duplicate keys and nonfinite
numbers. Critical checks use explicit exceptions, so `python -O` cannot remove
them. The adapter performs no dynamic source loading. The test harness loads the
adapter once from the same bytes it hashes, using `compile`/`exec` without
pycache, only when the parent later executes the test suite.

A failed run never overwrites an old output. If writing derived metadata or a
late unchanged check fails, the fresh directory may contain partial new derived
documents, but no successful acknowledgment result is committed. Such a
partial directory must not be consumed, retried in place or treated as GO.

## Sequencing without a circular hash dependency

1. Preserve all original files, including `final-inventory-r1`, unchanged.
2. Independently review these new source files; then the parent may run the
   synthetic controls serially under the approved shared lock in normal and
   optimized modes, with fresh output directories. Capture logs as new files.
3. Include the adapter directory, both control result trees and logs in the
   next original generator complete finalize. Resolve all unrelated current
   HOLDs through their authorized exact proofs/dispositions. Preserve the fixed
   base181 direct contract at this stage if the future acknowledgment report
   does not yet exist. Never add a nonexistent report as an undeferred direct
   input, and never expand the original nine deferred sources to get around it.
4. Only after the original generator emits a complete result with the sole
   exact historical metadata HOLD may the parent create a fresh exact adapter
   plan. Do not rewrite a plan or result whose hash was already recorded.
5. Execute this adapter with that plan and a fresh output directory. Publish
   only after checking the result and all derived-output hashes. The public
   worker can then build a separate new public contract, preserving base181 and
   adding the now-existing public-safe proof and source/control identities.

The original finalize metadata and the post-finalize invocation plan remain
independent exact inputs; a source file is never required to contain its own
hash. This directory does not supply an active real plan or an authorization to
execute the production acknowledgment.

## Production CLI and exact plan schema

Example only, not executed during preparation:

```sh
python -B acknowledge_metadata_gap.py \
  --plan REVIEWED-ADAPTER-PLAN.json --plan-sha256 EXACT_REVIEWED_PLAN_SHA256 \
  --root "independent=$Q" --root "author=$Q/final-v15-r1/frozen" \
  --out "$Q/archive-preparation/metadata-gap-acknowledgment-r1"
```

The parent should hold the approved shared lock, quiesce source writers and keep
live invocation logs outside the inventoried roots until acknowledgment commits.
A log being appended within a finalized root is an actual source change and
must cause refusal. `--out` must be absent; its parent must already exist and be
accessible without symlinks. Every source reference below is a JSON object
containing exactly the meaningful identity fields `source_relative_path`, integer
`bytes`, and lowercase 64-character `sha256`. Additional producer metadata on
file rows remains preserved. Use only canonical logical paths in the plan.

Required top-level plan fields:

- `schema`: `aeust-metadata-gap-acknowledgment-plan-v1`
- `ready_for_gap_acknowledgment`: `true` only after the single-gap original run
- `model_go`: `false`
- `acknowledged_gap`: the sole exact three-field descriptor above
- `original_generator`: exact reference to the pinned generator
- `original_plan`: exact reference to the plan that produced that original result
- `original_result`: exact reference to its `final-inventory-generation-result.json`
- `source_inventories`: exactly the generating plan's `baseline_inventories`
  followed by its `source_roster`, preserving order
- `adapter_source`: exact reference to `acknowledge_metadata_gap.py`
- `adapter_test_source`: exact reference to `test_metadata_gap_adapter.py`
- `adapter_controls`: two exact result references, optimization 0 then 1, each
  pointing to that mode's `report/results.json`
- `preinventoried_adapter_files`: exact references to the adapter source, test,
  README, both results and any additional provenance intended for the handoff;
  all must be present unchanged in the original finalized current inventory.
  Sources, tests and both result references are mandatory. Complete current-tree
  snapshot validation also covers all other newly prepared/run siblings.
- `frozen_sets`: the four exact references below, keyed by their stated names

Frozen anchors:

- `science`: `author/qa/V15-SCIENTIFIC-HANDOFF-FREEZE.json`, SHA256
  `a46bf5d5eba7ba570dd0bd4adb832663f43146858751118d619b18f2ceab6224`
- `runner`: `independent/V15-RUNNER-FREEZE-ADAPTER.json`, SHA256
  `11794b224ea898237e21a54b387956ba2cfbab26c8161e2da1be467f0474d368`
- `tooling`: `independent/FINAL-INDEPENDENT-TOOLING-FREEZE.json`, SHA256
  `68c9fa4e5a0f9fb555b4b48d6ca37545711a2eac467d56e03f8ecaeaf29c05fa`
- `public_base`: `independent/public-preparation/PUBLIC-DIRECT-PATH-CONTRACT.json`,
  SHA256 `508bf1f9ae233f221952e45f6e550e44f881849125210a4e8e82ce7ea8a7235d`

The parent supplies their real byte counts; no placeholder descriptor is
accepted. The exact historical baseline SHA is pinned to
`80c942e0c36610cbfc02bb38b8d2b557164e8fc33d2e550160c9517afcc3f636`.

## Output and public consumer contract

Four new files are produced:

1. `private-original-payload-inventory-GAP-ACK.json`
2. `controls-selection-GAP-ACK.json`
3. `private-omissions-GAP-ACK.json`
4. `metadata-gap-acknowledgment-result.json`, committed last

The first three retain the original document schemas, original `files` arrays
and all producer rows exactly. The inventory retains the original missing list,
`historical_descriptor_only` status and `retained_at:null` untouched. Added
truthful disclosure fields are `all_historical_retained:false`,
`gap_acknowledged:true`, `model_go:false`, and `gap_acknowledgment`. Public
readiness changes are limited to `ready_for_final_assembly:true`, and for the
selection `passed:true` and `all_selected_dependencies_publicly_mapped:true`.
The original selection's `original_payload_inventory_complete` field is retained
as its snapshot-coverage claim; the explicit new historical-retention flag is
false and must never be presented as full historical-byte completeness.

The public-safe report schema is
`aeust-metadata-gap-acknowledgment-result-v1`. It contains:

- `passed:true`, `ready_for_final_assembly:true`, `model_go:false`
- `all_historical_retained:false`, `gap_acknowledged:true`, `acknowledged_gap`
- `original_passed:false`, `original_hold_count:1`
- Exact `original_result`, all eight `original_outputs`, `original_generator`,
  `original_plan`, `source_inventories`, `adapter_source`, `adapter_test_source`,
  both `adapter_controls`, and `adapter_plan` identity
- `frozen_sets`, exact `required_set_evidence`, per-family unique count and
  ordered exact-binding digest in `required_sets`; these summaries explicitly
  record gap path/identity exclusion
- `derived_outputs`, mapping each of the three derivative basenames to bytes/SHA
- `all_current_source_bytes_unchanged:true`,
  `original_scientific_verdict_unchanged:true`, `original_outputs_rewritten:false`,
  `missing_bytes_reconstructed:false`, `archive_created:false`
- A precise scanner-closure explanation and explicit synthetic control scope

The report contains only canonical logical source references and identities,
never actual workspace paths or private source bytes. The original result and
all original outputs are covered by exact SHA references; their original bytes
are retained in place. Consumers must verify these exact identities, the three
derived outputs and the public contract. A plain `passed:true` from this report
means only this narrowly scoped metadata acknowledgment, never scientific/model
GO or proof that the unavailable historical bytes were retained.

## Parent-scheduled synthetic controls

Commands below are examples only; no test has run during this preparation:

```sh
python -B test_metadata_gap_adapter.py --out FRESH-NORMAL-OUTPUT
python -B -O test_metadata_gap_adapter.py --out FRESH-OPTIMIZED-OUTPUT
```

Use the parent's approved lock/CPU policy. Each mode writes its result at
`OUTPUT/report/results.json`. Exit 0 means all 16 helper-level cases passed;
exit 2 means a case or source-unchanged check failed. The schema is
`aeust-metadata-gap-synthetic-controls-v1`, with exact adapter/test hashes,
`optimization_level`, `positive_count:2`, `negative_count:14`, and an ordered
`cases` array. It explicitly sets `scope:synthetic_helper_level_not_real_cli`,
`real_cli_success_exercised:false`, and `model_go:false`.

Two positive cases:

1. Exact eligible synthetic historical gap preserves all original evidence and
   creates truthful derived synthetic metadata.
2. New current bytes at the same path remain privately retained while the old
   historical identity stays missing.

Fourteen negative cases:

3. Wrong historical path.
4. Wrong historical size.
5. Wrong historical SHA.
6. A second historical missing identity.
7. Science dependency by either old path or old byte identity.
8. Runner dependency by either old path or old byte identity.
9. Base/active public dependency by either path or identity.
10. Replay/seed dependency by either path or identity.
11. Malformed, negative and other proof dependency by either path or identity.
12. Extra HOLD, including deliberately false `hold_count`.
13. Unresolved current regular-file disposition.
14. Mutated exact SHA/size binding and boolean byte count.
15. Source mutation or same-byte inode replacement after binding.
16. Ancestor/leaf symlink and nonblocking FIFO rejection; duplicate/nonfinite
    JSON; unsafe logical paths; refusal to overwrite existing output directories.

Some numbered cases contain related subchecks; this remains exactly 16 cases,
not an inflated claim of 16 complete CLI scenarios. Temporary FIFO objects are
removed by the control itself, so no special file prevents the later original
full inventory. Other synthetic originals/results remain available to inventory.
No full-size scientific manifest or real successful production acknowledgment is
fabricated to turn these controls into a model acceptance claim.
