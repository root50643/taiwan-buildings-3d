# Preserved parser source versions

- v14-pre-migration: direct pre-v15 snapshot of the final v14 code used by parser-controls-v2 (150 test methods).
- v14-parser-v1-recovered: the earlier v1 sources (146 test methods), including exact inverse-patch recovery of two files, each proven byte-identical to the original execution inventory.
- Each directory includes every tested shared generic/scene source under shared-qa-sources and REPRODUCIBILITY-BINDING.json; original result/log directories remain untouched.

Replay by materializing the original relative qa paths into an isolated copy of the author project with the same toolchain layout and original synthetic-evidence tree. These snapshots are storage, not runnable in place because scripts derive their QA root from their location. Do not overwrite active v15 sources or evidence to replay. No model, failed image, core source or old result was changed.
