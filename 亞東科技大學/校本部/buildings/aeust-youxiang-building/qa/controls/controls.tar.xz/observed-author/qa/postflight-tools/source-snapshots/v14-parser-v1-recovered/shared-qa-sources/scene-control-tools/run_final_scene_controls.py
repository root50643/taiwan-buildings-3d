"""Frozen final-scene positive/negative controls, both Python modes, no rendering.
Orchestration only: core checkers and all their predicates remain unchanged.
Holds qa/.heavy.lock itself; do not wrap this command in another flock.
"""
from pathlib import Path
import argparse
import copy
import fcntl
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

QA = Path(__file__).resolve().parents[1]
VIEWS = {'front', 'rear', 'east', 'west', 'south', 'north', 'top', 'courtyard-gallery', 'courtyard-arcade'}
CORE_TOOLS = ('make_render_negative_fixtures.py', 'inspect_and_rerender_blend.py',
              'compare_source_scene.py', 'png_exact_compare.py')
VIEW_ERROR = 'View manifest does not contain exactly the nine required views'
POLICY_ERROR = 'Declared per-view projection/lens differs from fixed nine-view camera policy'
INSPECT_CASES = (
    ('unchanged', None, None),
    ('lens26', 'saved_initial_camera_matches_front', None),
    ('samples32', 'exactly_64_samples', None),
    ('denoising-on', 'denoising_disabled', None),
    ('wrong-view-set', None, VIEW_ERROR),
    ('missing-view', None, VIEW_ERROR),
    ('extra-view', None, VIEW_ERROR),
    ('projection-changed', None, POLICY_ERROR),
    ('declared-lens-changed', None, POLICY_ERROR),
)
SOURCE_CASES = ('unchanged', 'material-changed', 'shifted-camera')
# A small runtime launcher records the actual child interpreter mode and affinity,
# then executes the exact copied checker bytes with their own __file__ and argv.
BOOTSTRAP = '''import hashlib, json, os, runpy, sys
from pathlib import Path
import bpy
args=sys.argv[sys.argv.index('--')+1:]
script=Path(args[0]); target_args=args[1:]
affinity=sorted(os.sched_getaffinity(0))
record={'optimization_level':sys.flags.optimize,'affinity':affinity,
        'blender_version':bpy.app.version_string,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
        'target_argv':target_args,'no_image_render_requested':True}
Path(os.environ['AEUST_RUNTIME_RECORD']).write_text(json.dumps(record,indent=2)+'\\n')
if sys.flags.optimize!=int(os.environ['AEUST_EXPECTED_OPT']):raise RuntimeError('Child optimization level mismatch')
if affinity!=[int(os.environ['AEUST_EXPECTED_CPU'])]:raise RuntimeError('Child CPU affinity mismatch')
sys.argv=['blender','--',*target_args]
runpy.run_path(str(script),run_name='__main__')
'''


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def read(path):
    return json.loads(Path(path).read_text())


def camera_checks(report):
    value = report.get('camera_definition_checks')
    require(type(value) is dict and set(value) == VIEWS, 'Missing/unexpected camera definition checks')
    require(all(type(v) is bool for v in value.values()), 'Camera checks must be Boolean')
    return value


def inspect_outcome(report, code, case, flag=None, error=None):
    """Fail closed on a wrong failure reason or unrelated false inspection flag."""
    expected = case == 'unchanged'
    require(type(code) is int and code == (0 if expected else 1), 'Unexpected inspector exit')
    require(report.get('passed') is expected and report.get('strict_passed') is expected,
            'Unexpected inspector Boolean outcome')
    checks = report.get('checks')
    require(type(checks) is dict and checks and all(type(v) is bool for v in checks.values()),
            'Missing/non-Boolean inspector checks')
    false = sorted(k for k, v in checks.items() if v is False)
    if error:
        require(report.get('error_type') == 'RuntimeError' and report.get('error') == error,
                'Inspector rejected for a different reason')
        require(not false, 'Unrelated inspection predicate failed before manifest rejection')
    else:
        require('error' not in report and report.get('inspect_only') is True,
                'Inspector did not finish inspect-only path')
        require(report.get('views') == [], 'Inspector unexpectedly produced render views')
        require(false == ([flag] if flag else []), 'Unexpected false inspection predicates')
        for key in ('inspector_source_unchanged', 'png_comparator_source_unchanged',
                    'original_blend_unchanged', 'original_stl_unchanged', 'original_manifest_unchanged'):
            require(checks.get(key) is True, 'Missing inspector immutability proof: ' + key)
    return {'accepted': expected, 'false_checks': false, 'error': report.get('error')}


def source_outcome(report, code, case):
    expected = case == 'unchanged'
    require(type(code) is int and code == (0 if expected else 1), 'Unexpected source checker exit')
    require(report.get('passed') is expected and 'error' not in report,
            'Unexpected source Boolean outcome or premature failure')
    for key in ('source_unchanged', 'original_blend_unchanged', 'manifest_unchanged'):
        require(report.get(key) is True, 'Missing source immutability proof: ' + key)
    cameras = camera_checks(report)
    deltas = report.get('state_differences')
    require(type(deltas) is list and type(report.get('state_difference_count')) is int
            and report['state_difference_count'] == len(deltas), 'Source difference count mismatch')
    if case == 'material-changed':
        require(report.get('all_nine_camera_definitions_match') is True and all(cameras.values()),
                'Material control also changed cameras')
        require(report.get('exact_scene_state_matches') is False and deltas
                and all('/materials/wall/' in value for value in deltas),
                'Material control did not isolate wall-material state differences')
    elif case == 'shifted-camera':
        require(report.get('all_nine_camera_definitions_match') is False
                and {k for k, v in cameras.items() if not v} == {'courtyard-gallery'},
                'Shifted non-front camera was not the sole camera-definition failure')
        require(report.get('exact_scene_state_matches') is True and deltas == [],
                'Manifest camera control unexpectedly changed scene state')
    else:
        require(report.get('all_nine_camera_definitions_match') is True and all(cameras.values())
                and report.get('exact_scene_state_matches') is True and deltas == [],
                'Unchanged source scene did not match exactly')
    return {'accepted': expected, 'camera_definition_checks': cameras,
            'state_differences': deltas, 'exact_scene_state_matches': report['exact_scene_state_matches']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frozen-root', type=Path, required=True)
    parser.add_argument('--version', required=True)
    parser.add_argument('--expected-stl-sha256', required=True)
    parser.add_argument('--manifest', type=Path, help='Default: frozen-root/previews/version/render-manifest.json')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', args.version) is not None,
            'Version must be a simple directory component')
    require(re.fullmatch(r'[0-9a-f]{64}', args.expected_stl_sha256) is not None, 'Invalid SHA256')
    root = args.frozen_root.resolve()
    out = args.out.resolve()
    require(out.is_relative_to(QA / 'scene-controls'), 'Output must be below this project qa/scene-controls')
    require(not out.exists(), 'Output must be new; never overwrite evidence')
    manifest_path = (args.manifest or root / 'previews' / args.version / 'render-manifest.json').resolve()
    require(manifest_path.is_relative_to(root), 'Manifest must be within the supplied frozen root')
    model = root / 'models' / args.version
    expected_cases = {kind + '-' + name for kind, names in
                      [('inspect', [x[0] for x in INSPECT_CASES]), ('source', SOURCE_CASES)] for name in names}
    executions, cases = [], []
    report = {'passed': False, 'completed': False, 'version': args.version,
              'stl_sha256': args.expected_stl_sha256, 'expected_case_count': 24,
              'case_count': 0, 'cases': cases, 'executions': executions,
              'orchestrator_sha256': sha(__file__), 'no_image_rendering': True,
              'scope': 'Fresh final-scene controls only; not a geometry pass or nine-image reproduction pass.',
              'view_semantics': 'Fixed identifiers denote AEUST paper/model axes, not geographic headings.'}
    original, snapshots, core = {}, {}, {}
    lock = (QA / '.heavy.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX)
    try:
        # Recheck output after waiting for the shared resource.
        require(not out.exists(), 'Output appeared while waiting for the lock')
        out.mkdir(parents=True)
        cpu = min(os.sched_getaffinity(0))
        os.sched_setaffinity(0, {cpu})
        report['execution_policy'] = {'lock': str(QA / '.heavy.lock'), 'cpu': cpu,
            'affinity': sorted(os.sched_getaffinity(0)), 'serial_children': True, 'render_threads': 1}
        for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
            os.environ[key] = '1'
        os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
        binding_path = QA / 'TOOLING-REUSE-BINDING.json'
        old_binding = read(binding_path)
        allowed = {r['path']: r['copied_sha256'] for r in old_binding['rows']}
        for name in CORE_TOOLS:
            src = QA / 'render-tools' / name
            require(sha(src) == allowed['render-tools/' + name], 'Audited core tool binding differs: ' + name)
            dest = out / 'tools' / name
            dest.parent.mkdir(exist_ok=True)
            shutil.copyfile(src, dest)
            require(sha(dest) == sha(src), 'Tool snapshot differs')
            original[str(src)] = sha(src)
            snapshots[str(dest)] = sha(dest)
            core[name] = dest
        report['tool_reuse_binding_sha256'] = sha(binding_path)
        original[str(binding_path)] = sha(binding_path)
        original[str(Path(__file__).resolve())] = report['orchestrator_sha256']
        shutil.copyfile(__file__, out / 'orchestrator.py')
        snapshots[str(out / 'orchestrator.py')] = sha(out / 'orchestrator.py')
        launch = out / 'tools' / 'runtime_launcher.py'
        launch.write_text(BOOTSTRAP)
        snapshots[str(launch)] = sha(launch)

        def freeze(path):
            require(path.is_file() and not path.is_symlink(), 'Missing or symbolic input: ' + str(path))
            rel = path.relative_to(root)
            dest = out / 'frozen' / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            original[str(path)] = sha(path)
            shutil.copyfile(path, dest)
            require(sha(dest) == original[str(path)], 'Frozen input copy differs')
            snapshots[str(dest)] = sha(dest)
            return dest

        for name in ('model.stl', 'scene.blend', 'render_preview.py', 'parameters.json', 'color-regions.json'):
            freeze(model / name)
        mf = freeze(manifest_path)
        frozen_model = out / 'frozen' / model.relative_to(root)
        stl, blend = frozen_model / 'model.stl', frozen_model / 'scene.blend'
        manifest = read(mf)
        require(sha(stl) == args.expected_stl_sha256 == manifest['stl_sha256'], 'Frozen STL binding differs')
        require(manifest['blend_sha256'] == sha(blend), 'Frozen Blend binding differs')
        require(manifest['render_source_sha256'] == sha(frozen_model / 'render_preview.py'), 'Render source binding differs')
        require(set(manifest['views']) == VIEWS, 'Exactly nine final manifest views are required')
        for name, item in manifest['views'].items():
            expected = ('PERSP', 20) if name.startswith('courtyard-') else ('ORTHO', 50)
            require((item.get('projection'), item.get('lens_mm')) == expected, 'Frozen camera policy differs')
            require(sha(freeze(manifest_path.parent / (name + '.png'))) == item['sha256'], 'Final PNG binding differs: ' + name)
        write(out / 'input-freeze.json', {'original_sha256': original, 'snapshot_sha256': snapshots})

        def execute(label, script, arguments, mode):
            opt = 1 if mode == 'optimized' else 0
            runtime = out / 'runtime' / (label + '.json')
            runtime.parent.mkdir(exist_ok=True)
            log = out / 'logs' / (label + '.log')
            log.parent.mkdir(exist_ok=True)
            env = dict(os.environ)
            env.pop('PYTHONOPTIMIZE', None)
            if opt:
                env['PYTHONOPTIMIZE'] = '1'
            env.update(AEUST_RUNTIME_RECORD=str(runtime), AEUST_EXPECTED_OPT=str(opt), AEUST_EXPECTED_CPU=str(cpu))
            argv = ['blender', '--background', '--threads', '1', '--python-use-system-env',
                    '--python-exit-code', '1', '--python', str(launch), '--', str(script), *map(str, arguments)]
            start = time.monotonic()
            with log.open('w') as stream:
                process = subprocess.run(argv, env=env, stdout=stream, stderr=subprocess.STDOUT)
            row = {'label': label, 'mode': mode, 'command': argv, 'returncode': process.returncode,
                   'seconds': time.monotonic() - start, 'log': str(log.relative_to(out)), 'log_sha256': sha(log)}
            executions.append(row)
            write(out / 'executions.json', executions)
            state = read(runtime)
            require(state['optimization_level'] == opt and state['affinity'] == [cpu]
                    and state['script_sha256'] == sha(script), 'Actual child runtime binding differs')
            require(state['blender_version'] == manifest['blender_version'], 'Blender version differs from final manifest')
            row.update(runtime_record=str(runtime.relative_to(out)), runtime_sha256=sha(runtime))
            write(out / 'executions.json', executions)
            return process.returncode

        code = execute('make-fixtures', core['make_render_negative_fixtures.py'],
                       ['--blend', blend, '--manifest', mf, '--out', out / 'fixtures'], 'normal')
        require(code == 0, 'Fixture generation failed')
        fixture_binding = read(out / 'fixtures' / 'FIXTURE-BINDING.json')
        require(fixture_binding.get('passed') is True and fixture_binding.get('no_images_rendered') is True
                and fixture_binding['source_blend_sha256'] == sha(blend)
                and fixture_binding['source_manifest_sha256'] == sha(mf), 'Fixture binding differs')
        shifted = copy.deepcopy(manifest)
        before_camera = copy.deepcopy(shifted['views']['courtyard-gallery']['camera'])
        shifted['views']['courtyard-gallery']['camera'][0][0] += 1
        shifted_path = out / 'fixtures' / 'shifted-camera' / 'render-manifest.json'
        write(shifted_path, shifted)
        write(out / 'fixtures' / 'shifted-camera' / 'MUTATION.json', {
            'source_manifest_sha256': sha(mf), 'mutated_manifest_sha256': sha(shifted_path),
            'changed_json_path': '/views/courtyard-gallery/camera/0/0', 'delta_model_mm': 1,
            'original_camera': before_camera, 'mutated_camera': shifted['views']['courtyard-gallery']['camera']})
        fixture_files = {str(p): sha(p) for p in sorted((out / 'fixtures').rglob('*')) if p.is_file()}
        snapshots.update(fixture_files)
        write(out / 'fixture-inventory.json', fixture_files)

        def record_case(mode, kind, name, run_case):
            row = {'mode': mode, 'case': kind + '-' + name, 'expected_accept': name == 'unchanged', 'passed': False}
            try:
                row.update(run_case())
                row['passed'] = True
            except Exception as error:
                row.update(error_type=type(error).__name__, error=str(error))
            cases.append(row)
            report['case_count'] = len(cases)
            write(out / 'results-in-progress.json', report)
            print(json.dumps({'mode': mode, 'case': row['case'], 'passed': row['passed']}), flush=True)

        for mode in ('normal', 'optimized'):
            for name, flag, error in INSPECT_CASES:
                def inspect_case(name=name, flag=flag, error=error):
                    b = blend if name == 'unchanged' else out / 'fixtures' / name / 'scene.blend'
                    m = mf if name == 'unchanged' else out / 'fixtures' / name / 'render-manifest.json'
                    dest = out / mode / ('inspect-' + name)
                    code = execute(mode + '-inspect-' + name, core['inspect_and_rerender_blend.py'],
                        ['--blend', b, '--stl', stl, '--manifest', m, '--expected-sha256', args.expected_stl_sha256,
                         '--out', dest, '--inspect-only'], mode)
                    p = dest / 'blend-rerender-audit.json'; data = read(p)
                    require(data['original_blend_sha256'] == sha(b) and data['original_stl_sha256'] == sha(stl)
                            and data['original_manifest_sha256'] == sha(m)
                            and data['source_sha256'] == sha(core['inspect_and_rerender_blend.py'])
                            and data['png_comparator_source_sha256'] == sha(core['png_exact_compare.py']),
                            'Inspector report binding differs')
                    result = inspect_outcome(data, code, name, flag, error)
                    return {'returncode': code, 'expected_false_flag': flag, 'expected_error': error,
                            'science': result, 'report': str(p.relative_to(out)), 'report_sha256': sha(p)}
                record_case(mode, 'inspect', name, inspect_case)
            for name in SOURCE_CASES:
                def source_case(name=name):
                    base = out / mode / ('source-' + name)
                    repro = base / 'reproduction'
                    (repro / 'source').mkdir(parents=True)
                    local_model = repro / 'models' / args.version
                    local_model.mkdir(parents=True)
                    for filename in ('model.stl', 'parameters.json', 'color-regions.json'):
                        shutil.copyfile(frozen_model / filename, local_model / filename)
                    src = repro / 'source' / 'render_preview.py'
                    shutil.copyfile(frozen_model / 'render_preview.py', src)
                    b = out / 'fixtures' / 'material-changed' / 'scene.blend' if name == 'material-changed' else blend
                    m = shifted_path if name == 'shifted-camera' else mf
                    dest = base / 'comparison'
                    code = execute(mode + '-source-' + name, core['compare_source_scene.py'],
                        ['--source', src, '--version', args.version, '--original-blend', b, '--manifest', m,
                         '--expected-stl-sha256', args.expected_stl_sha256, '--out', dest], mode)
                    p = dest / 'source-scene-audit.json'; data = read(p)
                    require(data['source_sha256'] == sha(src) == sha(frozen_model / 'render_preview.py')
                            and data['original_blend_sha256'] == sha(b) and data['manifest_sha256'] == sha(m)
                            and data['checker_sha256'] == sha(core['compare_source_scene.py']),
                            'Source report binding differs')
                    result = source_outcome(data, code, name)
                    return {'returncode': code, 'science': result,
                            'report': str(p.relative_to(out)), 'report_sha256': sha(p)}
                record_case(mode, 'source', name, source_case)
        require(len(cases) == 24 and all({r['case'] for r in cases if r['mode'] == mode} == expected_cases
                and len([r for r in cases if r['mode'] == mode]) == 12 for mode in ('normal', 'optimized')),
                'Missing, duplicate, or unexpected control cases')
        require(all(r['passed'] is True for r in cases), 'One or more controls did not produce the required outcome')
        science = {mode: {r['case']: r['science'] for r in cases if r['mode'] == mode} for mode in ('normal', 'optimized')}
        require(science['normal'] == science['optimized'], 'Normal/-O control scientific outcomes differ')
        report['normal_optimized_outcomes_identical'] = True
        report['completed'] = True
    except Exception as error:
        report.update(error_type=type(error).__name__, error=str(error))
    finally:
        if out.is_dir():
            report['original_input_and_tool_rechecks'] = {p: Path(p).is_file() and sha(p) == h for p, h in original.items()}
            report['snapshot_and_fixture_rechecks'] = {p: Path(p).is_file() and sha(p) == h for p, h in snapshots.items()}
            report['all_original_inputs_and_tools_unchanged'] = bool(original) and all(report['original_input_and_tool_rechecks'].values())
            report['all_snapshots_and_fixtures_unchanged'] = bool(snapshots) and all(report['snapshot_and_fixture_rechecks'].values())
            # No PNG may be generated outside the immutable frozen input copy.
            generated_png = [str(p.relative_to(out)) for p in out.rglob('*.png') if not p.is_relative_to(out / 'frozen')]
            report['unexpected_generated_png_files'] = generated_png
            report['passed'] = (report['completed'] and report['all_original_inputs_and_tools_unchanged']
                and report['all_snapshots_and_fixtures_unchanged'] and not generated_png and 'error' not in report)
            report['evidence_inventory'] = {str(p.relative_to(out)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                for p in sorted(out.rglob('*')) if p.is_file() and p != out / 'results.json'}
            write(out / 'results.json', report)
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()
    print(json.dumps({'passed': report['passed'], 'completed': report['completed'],
                      'case_count': report['case_count'], 'error': report.get('error'), 'out': str(out)}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
