from pathlib import Path
import itertools,json,sys
from fractions import Fraction as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'independent-tools'))
from exact_ray_diagnosis import Triangle,Mesh,require

def cube(a,b):
 x0,y0,z0=a;x1,y1,z1=b
 v=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
 f=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(1,2,6),(1,6,5),(2,3,7),(2,7,6),(3,0,4),(3,4,7)]
 return [tuple(v[i] for i in q) for q in f]
rows=[]
# All face vertex permutations, both ray direction signs, and exact edge cases.
a=((0,0,0),(4,0,0),(0,4,0))
cases=[('interior',((1,1,1),1,(0,0,-1)),(F(1),F(1),False,False)),
 ('edge',((2,0,1),1,(0,0,-1)),(F(1),F(1),False,True)),
 ('vertex',((0,0,1),1,(0,0,-1)),(F(1),F(1),False,True)),
 ('coplanar_interval',((-1,1,0),1,(1,0,0)),(F(1),F(4),True,True)),
 ('coplanar_edge_interval',((-1,0,0),1,(1,0,0)),(F(1),F(5),True,True)),
 ('coplanar_single_vertex',((-1,1,0),1,(1,-1,0)),(F(1),F(1),True,True)),
 ('miss',((4,4,1),1,(0,0,-1)),None),('behind',((1,1,-1),1,(0,0,-1)),None)]
for perm in itertools.permutations(a):
 for name,args,expected in cases:
  got=Triangle(perm).contact(*args);actual=None if got is None else (got['lo'],got['hi'],got['coplanar'],got['edge_contact']);require(actual==expected,f'{name}: {actual} != {expected}');rows.append({'test':name,'passed':True})
# Explicit solid classification and all 120 samples in a thick box.
m=Mesh(cube((0,0,0),(30,20,10)),1)
for p,expected in [((15,10,5),'inside'),((30,10,5),'boundary'),((31,10,5),'outside'),((0,0,0),'boundary')]:
 state,proof=m.status(p,1);require(state==expected,f'Box state {state}');rows.append({'test':'box_'+expected,'passed':True})
for i in range(12):
 for s in range(10):
  r=m.diagnose(i,s);require(r['exact_classification_completed'] and r['conservative_first_surface_chord_ge_0p8mm'],'Thick box ray failed');rows.append({'test':'box_original_face_sample','face':i,'sample':s,'passed':True})
# The exact v12-style boundary glide: a 10x10x10 cube plus an outward low block
# at x=5..8,y=-5..0,z=0..5. Remove the shared faces and triangulate the union
# with manifold3d in the caller only for fixture construction.
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tooling-snapshot'))
from check_controls import triangles_of,union,box
from exact_ray_diagnosis import load
from check_controls import encode
import tempfile
solid=union([box(0,10,0,10,0,10),box(5,8,-5,0,0,5)])
with tempfile.NamedTemporaryFile(suffix='.stl') as f:
 f.write(encode(triangles_of(solid)));f.flush();_,ts,den=load(f.name)
 glide=Mesh(ts,den);o=(5*den,10*den,2*den);d=(0,-1,0);hits=glide.contacts(o,1,d)
 contacts=[(h['lo']/den,h['hi']/den,h['coplanar']) for h in hits]
 intervals=sorted((x,y) for x,y,c in contacts if c and y>x);cursor=F(10)
 for x,y in intervals:
  require(x<=cursor,'Gap in boundary interval coverage');cursor=max(cursor,y)
 require(cursor==F(15),'Boundary interval missing')
 for p,state in [((5,5,2),'inside'),((5,-2,2),'boundary'),((5,-6,2),'outside')]:
  got,_=glide.status(tuple(x*den for x in p),1);require(got==state,'Boundary glide state incorrect')
 rows.append({'test':'closed_union_boundary_glide_preserved_and_classified','passed':True,'contact_count':len(hits)})
# 0.6 mm slab must be classified exactly and fail minimum chord on its Z faces.
thin=Mesh(cube((0,0,0),(300,200,6)),10)
for i in range(4):
 for s in range(10):
  r=thin.diagnose(i,s);require(r['exact_classification_completed'] and not r['conservative_first_surface_chord_ge_0p8mm'],'Thin slab not rejected');rows.append({'test':'thin_0p6mm_slab','face':i,'sample':s,'passed':True})
# Exact BVH traversal must match a brute-force triangle loop on rational rays.
import random
rng=random.Random(410239)
for trial in range(20):
 ts=[]
 while len(ts)<25:
  t=tuple(tuple(rng.randrange(-12,13) for _ in range(3)) for _ in range(3))
  try:Triangle(t)
  except RuntimeError:continue
  ts.append(t)
 mesh=Mesh(ts,1)
 for j in range(8):
  o=tuple(rng.randrange(-25,26) for _ in range(3));q=rng.randrange(1,8);d=tuple(rng.randrange(-4,5) for _ in range(3))
  if d==(0,0,0):d=(1,0,0)
  actual=mesh.contacts(o,q,d);brute=[]
  for i,t in enumerate(mesh.ts):
   h=t.contact(o,q,d)
   if h is not None:brute.append(dict(h,face=i))
  brute.sort(key=lambda h:(h['lo'],h['hi'],h['face']))
  require(actual==brute,'Exact ray BVH omitted/duplicated triangle contact')
  rows.append({'test':'bvh_equals_bruteforce_rational_ray','trial':trial,'ray':j,'passed':True})
out={'passed':all(r['passed'] for r in rows),'optimization_level':sys.flags.optimize,'cases':rows,'case_count':len(rows)}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print({'passed':out['passed'],'case_count':len(rows)})
