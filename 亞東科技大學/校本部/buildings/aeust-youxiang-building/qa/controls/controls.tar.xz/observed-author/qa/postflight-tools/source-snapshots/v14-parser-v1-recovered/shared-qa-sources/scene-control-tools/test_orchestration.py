"""Tiny synthetic outcome-parser controls. No Blender or model is loaded."""
import copy
import unittest
from run_final_scene_controls import inspect_outcome, source_outcome, VIEWS, VIEW_ERROR


def inspector():
    return {'passed': True, 'strict_passed': True, 'inspect_only': True, 'views': [],
        'checks': {k: True for k in ('geometry', 'exactly_64_samples', 'saved_initial_camera_matches_front',
            'inspector_source_unchanged', 'png_comparator_source_unchanged', 'original_blend_unchanged',
            'original_stl_unchanged', 'original_manifest_unchanged')}}


def source():
    return {'passed': True, 'source_unchanged': True, 'original_blend_unchanged': True,
        'manifest_unchanged': True, 'camera_definition_checks': {k: True for k in VIEWS},
        'all_nine_camera_definitions_match': True, 'state_differences': [],
        'state_difference_count': 0, 'exact_scene_state_matches': True}


class Outcomes(unittest.TestCase):
    def rejects(self, function, *args):
        with self.assertRaises(RuntimeError): function(*args)

    def test_inspect_positive(self):
        self.assertTrue(inspect_outcome(inspector(), 0, 'unchanged')['accepted'])

    def test_inspect_negative_correct_flag(self):
        r = inspector(); r.update(passed=False, strict_passed=False); r['checks']['exactly_64_samples'] = False
        self.assertFalse(inspect_outcome(r, 1, 'samples32', 'exactly_64_samples')['accepted'])

    def test_inspect_missing_mutation(self):
        r = inspector(); r.update(passed=False, strict_passed=False)
        self.rejects(inspect_outcome, r, 1, 'samples32', 'exactly_64_samples')

    def test_inspect_unrelated_failure(self):
        r = inspector(); r.update(passed=False, strict_passed=False); r['checks']['geometry'] = False
        self.rejects(inspect_outcome, r, 1, 'samples32', 'exactly_64_samples')

    def test_inspect_extra_failure(self):
        r = inspector(); r.update(passed=False, strict_passed=False)
        r['checks'].update(geometry=False, exactly_64_samples=False)
        self.rejects(inspect_outcome, r, 1, 'samples32', 'exactly_64_samples')

    def test_inspect_wrong_exit(self):
        self.rejects(inspect_outcome, inspector(), 1, 'unchanged')

    def test_inspect_boolean_exit(self):
        self.rejects(inspect_outcome, inspector(), False, 'unchanged')

    def test_inspect_nonboolean_pass(self):
        r = inspector(); r['passed'] = 'true'
        self.rejects(inspect_outcome, r, 0, 'unchanged')

    def test_inspect_unexpected_render(self):
        r = inspector(); r['views'] = ['rendered']
        self.rejects(inspect_outcome, r, 0, 'unchanged')

    def test_inspect_manifest_expected_error(self):
        r = inspector(); r.update(passed=False, strict_passed=False, error_type='RuntimeError', error=VIEW_ERROR)
        self.assertFalse(inspect_outcome(r, 1, 'missing-view', error=VIEW_ERROR)['accepted'])

    def test_inspect_manifest_wrong_error(self):
        r = inspector(); r.update(passed=False, strict_passed=False, error_type='RuntimeError', error='Other failure')
        self.rejects(inspect_outcome, r, 1, 'missing-view', None, VIEW_ERROR)

    def test_source_positive(self):
        self.assertTrue(source_outcome(source(), 0, 'unchanged')['accepted'])

    def test_source_material_expected(self):
        r = source(); r.update(passed=False, exact_scene_state_matches=False,
            state_differences=['/materials/wall/nodes/Roughness: value differs'], state_difference_count=1)
        self.assertFalse(source_outcome(r, 1, 'material-changed')['accepted'])

    def test_source_material_wrong_difference(self):
        r = source(); r.update(passed=False, exact_scene_state_matches=False,
            state_differences=['/world/Background: value differs'], state_difference_count=1)
        self.rejects(source_outcome, r, 1, 'material-changed')

    def test_source_shift_expected(self):
        r = source(); r.update(passed=False, all_nine_camera_definitions_match=False)
        r['camera_definition_checks']['courtyard-gallery'] = False
        self.assertFalse(source_outcome(r, 1, 'shifted-camera')['accepted'])

    def test_source_shift_wrong_camera(self):
        r = source(); r.update(passed=False, all_nine_camera_definitions_match=False)
        r['camera_definition_checks']['front'] = False
        self.rejects(source_outcome, r, 1, 'shifted-camera')

    def test_source_shift_two_cameras(self):
        r = source(); r.update(passed=False, all_nine_camera_definitions_match=False)
        r['camera_definition_checks'].update(front=False, **{'courtyard-gallery': False})
        self.rejects(source_outcome, r, 1, 'shifted-camera')

    def test_source_missing_camera(self):
        r = source(); r['camera_definition_checks'].pop('rear')
        self.rejects(source_outcome, r, 0, 'unchanged')

    def test_source_nonboolean_camera(self):
        r = source(); r['camera_definition_checks']['rear'] = 1
        self.rejects(source_outcome, r, 0, 'unchanged')

    def test_source_mutated_input(self):
        r = source(); r['manifest_unchanged'] = False
        self.rejects(source_outcome, r, 0, 'unchanged')


if __name__ == '__main__':
    unittest.main()
