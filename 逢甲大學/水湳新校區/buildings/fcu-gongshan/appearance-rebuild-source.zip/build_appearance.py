"""Rebuild appearance from immutable original STL. No Boolean or silhouette edits.
All triangles receive provenance; roof stripe boundaries subdivide planar faces.
Official photographs are visual evidence, not photogrammetric calibration.
"""
from pathlib import Path
import numpy as np, trimesh, hashlib,json,zipfile,xml.etree.ElementTree as ET
from shapely.geometry import Polygon,Point
R=Path(__file__).resolve().parent; SRC=R/'source/repo/逢甲大學/水湳新校區/buildings/fcu-gongshan';OUT=R/'payload/逢甲大學/水湳新校區/buildings/fcu-gongshan';OUT.mkdir(parents=True,exist_ok=True)
raw=(SRC/'model.stl').read_bytes();assert hashlib.sha256(raw).hexdigest()=='b81c4c9b53abc38982bc69a5cffb6742871a04e352ab5a1bf60929a649f8bc4d'
# Definitions and component outlines only; never execute original export statements.
ns={'__file__':str(SRC/'build_model.py')};exec((SRC/'build_model.py').read_text().split('solid=Manifold.batch_boolean')[0],ns)
mesh=trimesh.load(SRC/'model.stl',process=False);T=np.asarray(mesh.triangles,dtype=np.float64)
roofs=[];fins=[]
for name,poly,zfun in ns['ROOFS']:
 p=Polygon(poly).buffer(.8,join_style=2);inner=p.buffer(-18,join_style=2)
 if name=='east_fold':inner=Polygon(poly).buffer(-18,join_style=2)
 if name=='north_west':inner=Polygon([(1233,126),(1342,123),(1167,635),(1036,500)]).buffer(-4,join_style=2)
 roofs.append((name,p,inner,zfun))
 pts=list(inner.exterior.coords)[:-1]
 for a,b in zip(pts,pts[1:]+pts[:1]):
  a=np.array(a);b=np.array(b)
  for t in np.linspace(.12,.88,max(2,int(np.linalg.norm(b-a)/30))):
   q=a+(b-a)*t;x,y=ns['xy'](q);h=zfun(q)-3.15
   if h>1.2:fins.append((x,y,2.3,2.3+h))
palette=[('neutral_unobserved','#ABAFAE'),('plaza_gray','#999E9F'),('roof_silver','#C5CBCB'),('roof_green','#778B52'),('eave_light_gray','#D3D5D0'),('glazing_green_gray','#344F4D'),('existing_frame_warm_brown','#826A4C'),('landscape_green','#6F824F')]
def pq(v):return (v[0]/.125+950,650-v[1]/.125)
def category(tri):
 c=tri.mean(axis=0);q=pq(c);pt=Point(q);n=np.cross(tri[1]-tri[0],tri[2]-tri[0]);n=n/np.linalg.norm(n)
 # Only exact source roof planes may carry stripes.
 for name,p,inner,zf in roofs:
  if n[2]>.8 and p.buffer(.001).covers(pt) and max(abs(v[2]-zf(pq(v))) for v in tri)<1e-4:return 2,'roof:'+name
 if n[2]>.8 and np.linalg.norm(c[:2]-[2.65,-60.55])<.801 and abs(c[2]-ns['MAIN_Z'](q))<1e-4:return 2,'roof:rounded_tip'
 # Facade fins are the original boxes. No added framing geometry.
 if abs(n[2])<.01:
  for x,y,z0,z1 in fins:
   dx,dy=abs(c[0]-x),abs(c[1]-y)
   if z0-1e-5<=c[2]<=z1+1e-5 and dx<=.65001 and dy<=.65001 and min(abs(dx-.65),abs(dy-.65))<1e-5:return 6,'existing_fin'
  for name,p,inner,zf in roofs:
   if inner.boundary.distance(pt)<.001 and 2.4<c[2]<zf(q)-1.3:return 5,'glazing:'+name
   if p.boundary.distance(pt)<.001 and zf(q)-1.601<c[2]<=zf(q)+.01:return 4,'eave:'+name
   if inner.buffer(4,join_style=2).boundary.distance(pt)<.001 and 10.099<c[2]<11.001:return 4,'existing_horizontal_band'
 # Ribbon glass and its existing raised narrow framing, from the source outlines.
 aa,bb,nu=ns['aa'],ns['bb'],ns['nunit'];ab=bb-aa
 t=np.dot(np.array(q)-aa,ab)/np.dot(ab,ab);d=np.dot(np.array(q)-aa,nu)
 if abs(n[2])<.01 and 0<=t<=.67 and c[2]>7.9 and c[2]<ns['ribbon_wall_top'](q)+.01:
  if abs(d-4)<.001:return 5,'ribbon_glazing'
  if 1.599<=d<=5.001:return 6,'existing_ribbon_frame'
 # White/light grey source-visible canopy tops; never paint shaded undersides black.
 for poly,zf in [([(737,156),(795,180),(980,405),(1036,500),(1127,752),(1135,785),(1080,815),(930,416)],ns['MAIN_Z']), ([(1090,805),(1127,752),(1318,870),(1312,880)],lambda q:ns['MAIN_Z'](q) if q[0]<1200 else 7.9)]:
  if Polygon(poly).buffer(.001).covers(pt) and n[2]>.3 and abs(c[2]-zf(q))<.02:return 4,'canopy'
 for poly in [[(710,1050),(900,1050),(755,510)],[(1390,150),(1480,450),(1480,750),(1420,860),(1315,845),(1438,610)]]:
  if n[2]>.8 and Polygon(poly).covers(pt) and c[2]<6.5:return 7,'existing_landscaped_berm'
 if n[2]>.1 and c[2]<=7.9001:return 1,'plaza_and_grade'
 return 0,'unobserved_or_unresolved_neutral'
# Split roof faces at stripe boundaries, then conform neighbor edges. Canonical
# edge intersection caching ensures adjacent triangles share identical vertices.
verts=[];vmap={};faces=[];mats=[];parents=[];labels=[]
def vid(p):
 key=tuple(float(x) for x in p)
 if key not in vmap:vmap[key]=len(verts);verts.append(key)
 return vmap[key]
edge_cache={}
def intersect(a,b,y):
 ka,kb=tuple(a),tuple(b);lo,hi=sorted([ka,kb]);key=(lo,hi,float(y))
 if key not in edge_cache:
  a,b=np.array(lo),np.array(hi);p=a+(b-a)*((y-a[1])/(b[1]-a[1]));p[1]=y;edge_cache[key]=p
 return edge_cache[key]
def clip(poly,y,above):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=(a[1]>=y) if above else (a[1]<=y);ib=(b[1]>=y) if above else (b[1]<=y)
  if ia:out.append(a)
  if ia!=ib:out.append(intersect(a,b,y))
 clean=[]
 for a in out:
  if not clean or not np.array_equal(a,clean[-1]):clean.append(a)
 if len(clean)>1 and np.array_equal(clean[0],clean[-1]):clean.pop()
 return clean
# Global y cuts across every face avoid T-junctions at roof perimeter edges.
# Green strips are 2.4 mm wide in a 4.625 mm rhythm, a bounded visual approximation.
cuts=sorted(set(float(y) for base in np.arange(-69.98663,71,4.625) for y in [base,base+2.4]))
for fi,tri in enumerate(T):
 mat,label=category(tri);pieces=[list(tri)]
 for y in cuts:
  if not tri[:,1].min()+1e-10<y<tri[:,1].max()-1e-10:continue
  nxt=[]
  for poly in pieces:
   if min(p[1] for p in poly)<y<max(p[1] for p in poly):nxt.extend([clip(poly,y,False),clip(poly,y,True)])
   else:nxt.append(poly)
  pieces=nxt
 for poly in pieces:
  if len(poly)<3:continue
  mm=3 if mat==2 and ((sum(p[1] for p in poly)/len(poly)+69.98663)%4.625)<2.4 else mat
  # Convex polygons from clipping a triangle; fan about centroid avoids collinear fan degeneracy.
  if len(poly)==3:ts=[poly]
  else:
   ctr=np.mean(poly,axis=0);ts=[[ctr,a,b] for a,b in zip(poly,poly[1:]+poly[:1])]
  for t in ts:
   if np.linalg.norm(np.cross(t[1]-t[0],t[2]-t[0]))<1e-14:continue
   faces.append([vid(v) for v in t]);mats.append(mm);parents.append(fi);labels.append(label)
V=np.array(verts);F=np.array(faces);M=np.array(mats);P=np.array(parents)
# Float operations can differ on shared-edge chains. Merge only numerical duplicates
# within 1e-10 mm; retain first original value, never snap to a spatial grid.
from scipy.spatial import cKDTree
pairs=cKDTree(V).query_pairs(1e-10);remap=np.arange(len(V))
for a,b in sorted(pairs):
 while remap[a]!=a:a=remap[a]
 while remap[b]!=b:b=remap[b]
 remap[max(a,b)]=min(a,b)
for i in range(len(V)):
 while remap[i]!=remap[remap[i]]:remap[i]=remap[remap[i]]
unique,inv=np.unique(remap,return_inverse=True);V=V[unique];F=inv[F]
new=trimesh.Trimesh(V,F,process=False);old=trimesh.Trimesh(*[None,None]) if False else mesh
areas=np.bincount(P,weights=new.area_faces,minlength=len(T));oldareas=mesh.area_faces
norm0=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);norm0/=np.linalg.norm(norm0,axis=1)[:,None];norm=norm0[P];plane=np.abs(np.einsum('ij,ikj->ik',norm,V[F]-T[P,0,None,:])).max()
# Per-source face area and plane checks prove planar subdivision, in addition to shell checks.
qa={'original_sha256':hashlib.sha256(raw).hexdigest(),'original_faces':len(T),'appearance_faces':len(F),'appearance_vertices':len(V),'bounds_equal':bool(np.array_equal(new.bounds,mesh.bounds)),'max_per_original_face_area_error_mm2':float(np.max(abs(areas-oldareas))),'max_coplanarity_error_mm':float(plane),'signed_volume_difference_mm3':float(new.volume-mesh.volume),'appearance_watertight':bool(new.is_watertight),'appearance_winding_consistent':bool(new.is_winding_consistent),'appearance_shells':len(new.split(only_watertight=False)),'original_face_provenance_complete':len(set(P))==len(T),'numerical_vertex_merge_tolerance_mm':1e-10,'no_geometry_repair':True,'material_counts':{palette[i][0]:int(np.sum(M==i)) for i in range(len(palette))},'photo_date':'unknown','status':'appearance only; original 62 warnings and three exception classes retained'}
assert qa['bounds_equal'] and qa['appearance_watertight'] and qa['appearance_winding_consistent'] and qa['appearance_shells']==1 and plane<1e-9 and max(abs(areas-oldareas))<1e-7 and abs(new.volume-mesh.volume)<1e-7,qa
(OUT/'appearance-geometry-qa.json').write_text(json.dumps(qa,indent=2));(OUT/'appearance-mesh.json').write_text(json.dumps({'vertices':V.tolist(),'faces':F.tolist(),'material_indices':M.tolist(),'source_triangle':P.tolist(),'palette':palette},separators=(',',':')))
(OUT/'material-evidence.json').write_text(json.dumps({'palette':palette,'rules':'Exact source roof planes, source fin boxes, inset glazing perimeters and existing bands. Other unresolved faces neutral. Stripes approximate observed pattern; no photo texture or newly modeled detail. Global planar cuts preserve the original closed shell.','counts_by_source_label':{s:labels.count(s) for s in sorted(set(labels))},'photo_urls':['https://focus.fcu.edu.tw/virtuosihall/images/hero-2-day-aerial.jpg','https://focus.fcu.edu.tw/virtuosihall/images/hero-3-skyline-aerial.jpg'],'photo_dates_unknown':True},indent=2))
# 3MF Core base materials preserve triangle-level colors without proprietary slicer data.
NS='http://schemas.microsoft.com/3dmanufacturing/core/2015/02';ET.register_namespace('',NS)
def sub(e,n,**attrs):return ET.SubElement(e,'{'+NS+'}'+n,{k:str(v) for k,v in attrs.items()})
model=ET.Element('{'+NS+'}model',{'unit':'millimeter'});res=sub(model,'resources');bm=sub(res,'basematerials',id=1)
for name,col in palette:sub(bm,'base',name=name,displaycolor=col+'FF')
obj=sub(res,'object',id=2,type='model',pid=1,pindex=0);me=sub(obj,'mesh');vs=sub(me,'vertices');fs=sub(me,'triangles')
for v in V:sub(vs,'vertex',x=format(v[0],'.17g'),y=format(v[1],'.17g'),z=format(v[2],'.17g'))
for f,m in zip(F,M):sub(fs,'triangle',v1=f[0],v2=f[1],v3=f[2],pid=1,p1=m)
sub(sub(model,'build'),'item',objectid=2)
with zipfile.ZipFile(OUT/'appearance.3mf','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
 z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
 z.writestr('3D/3dmodel.model',ET.tostring(model,encoding='utf-8',xml_declaration=True))
print(json.dumps(qa,indent=2))
