"""Retain exact ARCHIVE-SCOPE bytes after unchanged original archive verification.

This is metadata extraction only. The frozen inventory generator must still
independently validate every proposed duplicate's complete dependency graph.
"""
from pathlib import Path
import argparse,hashlib,json,sys,types
def require(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    q=a.root;w=q/'identity-witness-v15-r2';require(not a.out.exists() and not a.out.is_symlink(),'Fresh report required')
    vp=q/'tooling/tools/archive_verify.py';source=vp.read_bytes();require(sha(source)=='1af27c8212057503323899b7a5f9f9171de42f78a28ff1e3e07f82d688e021fd','Exact original verifier required')
    module=types.ModuleType('witness_original_archive_verify');module.__file__=str(vp);exec(compile(source,str(vp),'exec'),module.__dict__)
    selection_raw=(w/'controls-selection.json').read_bytes();selection=json.loads(selection_raw);privacy_raw=(w/'privacy-allowlist.json').read_bytes();records=[];scopes=[];inputs={}
    for mode in ['normal','optimized']:
        root=w/mode;archive=root/'controls.tar.xz';index=root/'controls-index.json';result=root/'packaging-result.json'
        for p in [archive,index,result]:inputs[str(p.relative_to(q))]=sha(p.read_bytes())
        report=json.loads(result.read_text());require(report['passed'] is True and report['model_go'] is False and report['selection_sha256']==sha(selection_raw),'Actual witness result binding differs')
        require(all(report[k] is True for k in ['all_selected_inputs_accounted','sources_unchanged','all_tracked_dependencies_selected_and_copied','safe_extract_all_member_hashes_verified','bitwise_rebuild_verified']),'Incomplete original witness construction/replay')
        require(report['source_sha256']=='1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c','Wrong original public scanner')
        checked,raw,members=module.verify(archive,index);scope_rows=[r for r in members if r[0]=='ARCHIVE-SCOPE.json'];require(len(scope_rows)==1,'Exactly one bound original scope required');_,begin,end=scope_rows[0];scope=raw[begin:end];scopes.append(scope)
        parsed=json.loads(scope);require(parsed['selection_sha256']==sha(selection_raw) and parsed['privacy_allowlist_sha256']==sha(privacy_raw) and parsed['copies']==report['copies'],'Exact original scope dependency mapping differs')
        expected=[{k:r[k] for k in ['source_relative_path','archive_path','bytes','sha256']} for r in sorted(selection['files'],key=lambda x:x['archive_path'])];require(parsed['copies']==expected,'Original scope copies differ from selection')
        require(report['archive_sha256']==sha(archive.read_bytes()) and report['index_sha256']==sha(index.read_bytes()) and report['members']==len(members)==43 and report['copy_count']==len(expected)==42,'Original archive/result/member count differs')
        records.append({'mode':mode,'archive_sha256':sha(archive.read_bytes()),'index_sha256':sha(index.read_bytes()),'result_sha256':sha(result.read_bytes()),'tar_bytes':len(raw),'all_members_verified':len(members),'scope_bytes':len(scope),'scope_sha256':sha(scope)})
    require(scopes[0]==scopes[1] and records[0]['archive_sha256']==records[1]['archive_sha256'] and records[0]['index_sha256']==records[1]['index_sha256'],'Mode archives/index/scope differ')
    target=w/'ARCHIVE-SCOPE.json';require(not target.is_symlink(),'Scope target must not be a link')
    if target.exists():require(target.is_file() and target.read_bytes()==scopes[0],'Retained original scope differs')
    else:
        with target.open('xb') as stream:stream.write(scopes[0])
    require(all(sha((q/p).read_bytes())==h for p,h in inputs.items()) and vp.read_bytes()==source and (w/'controls-selection.json').read_bytes()==selection_raw and (w/'privacy-allowlist.json').read_bytes()==privacy_raw,'Original witness input changed')
    value={'passed':True,'model_go':False,'optimization_level':sys.flags.optimize,'source_sha256':sha(Path(__file__).read_bytes()),'original_archive_verifier_sha256':sha(source),'all_original_inputs_unchanged':True,'both_original_mode_archives_bitwise_identical':True,'exact_original_scope_retained':True,'mode_verifications':records,'scope':'Exact original scope retained after strict original all-member archive verification. Original packager already performed safe extraction, all-member byte readback and bitwise reconstruction in each mode. This report grants no duplicate omission or model GO.'}
    a.out.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');print(json.dumps({'passed':True,'optimization_level':sys.flags.optimize,'scope_sha256':sha(scopes[0])}))
if __name__=='__main__':main()
