# synthetic helper verification/check_raw_mesh.py
