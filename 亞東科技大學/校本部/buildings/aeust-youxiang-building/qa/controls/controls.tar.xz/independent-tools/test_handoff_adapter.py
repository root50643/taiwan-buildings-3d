"""Fresh positive and fail-closed controls using read-only hardlink fixture copies.
The original author files are never opened for writing. Each manifest is private.
"""
from pathlib import Path
import argparse,copy,hashlib,json,os,subprocess,sys

def require(v,m):
 if not v:raise RuntimeError(m)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--author',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();require(not a.out.exists(),'Fresh output required');a.out.mkdir(parents=True);author=a.author.resolve();out=a.out.resolve();manifest_rel='qa/V15-SCIENTIFIC-HANDOFF-FREEZE.json';original=author/manifest_rel;original_hash=sha(original);data=json.loads(original.read_text());fixture=out/'fixture';fixture.mkdir();tracked={}
 for rel,row in data['files'].items():
  p=author/rel;require(p.is_file() and not p.is_symlink() and sha(p)==row['sha256'],'Original fixture binding differs');dst=fixture/rel;dst.parent.mkdir(parents=True,exist_ok=True);os.link(p,dst);tracked[rel]=row['sha256']
 manifest=fixture/manifest_rel;tool=Path(__file__).with_name('prepare_frozen_handoff.py');toolhash=sha(tool);cases=[]
 def case(name,expected,needle='',mutate=None,symlink=False):
  m=copy.deepcopy(data)
  if mutate:mutate(m)
  manifest.parent.mkdir(parents=True,exist_ok=True);manifest.write_text(json.dumps(m,indent=2)+'\n')
  link=fixture/'source/build_model.py'
  if symlink:link.unlink();link.symlink_to(author/'source/build_model.py')
  try:
   command=[sys.executable,'-B',*(['-O'] if sys.flags.optimize else []),str(tool),'--author',str(fixture),'--manifest',str(manifest),'--sha256',sha(manifest),'--out',str(out/(name+'-adapter.json'))]
   completed=subprocess.run(command,capture_output=True,text=True);(out/(name+'.stdout.txt')).write_text(completed.stdout);(out/(name+'.stderr.txt')).write_text(completed.stderr);accepted=completed.returncode==0;verified=accepted is expected and (expected or needle in completed.stderr)
   cases.append({'name':name,'expected_accept':expected,'accepted':accepted,'returncode':completed.returncode,'expected_error':needle or None,'passed':verified,'manifest_sha256':sha(manifest),'stdout_sha256':sha(out/(name+'.stdout.txt')),'stderr_sha256':sha(out/(name+'.stderr.txt'))});require(verified,'Adapter control failed: '+name)
   if expected:
    result=json.loads((out/(name+'-adapter.json')).read_text());require(len(result['files'])==len(data['files'])+1,'Successful adapter count differs');require({r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in result['files'] if r['path']!=manifest_rel}==data['files'],'Successful mapping differs')
  finally:
   if symlink:link.unlink();os.link(author/'source/build_model.py',link)
 case('genuine_complete_exact_mapping',True)
 case('wrong_revision',False,'Wrong candidate',lambda m:m.__setitem__('revision','v14'))
 case('wrong_stl',False,'Wrong candidate',lambda m:m.__setitem__('stl_sha256','0'*64))
 case('empty_members',False,'Expected exact dict source schema',lambda m:m.__setitem__('files',{}))
 case('recursive_self_member',False,'Expected exact dict source schema',lambda m:m['files'].__setitem__(manifest_rel,{'bytes':0,'sha256':'0'*64}))
 case('missing_required_original_source',False,'Incomplete freeze required members',lambda m:m['files'].pop('source/build_model.py'))
 case('missing_tested_core_source',False,'Author checker differs',lambda m:m['files'].pop('qa/verification/check_dense_surface.py'))
 case('wrong_file_hash',False,'Frozen input differs',lambda m:m['files']['models/v15/model.stl'].__setitem__('sha256','0'*64))
 case('boolean_byte_count',False,'Frozen input differs',lambda m:m['files']['models/v15/model.stl'].__setitem__('bytes',True))
 case('extra_member_metadata',False,'Original file schema differs',lambda m:m['files']['models/v15/model.stl'].__setitem__('extra',1))
 for name,path in [('traversal','../escape'),('absolute','/escape'),('backslash','a\\b'),('dot_segment','a/./b')]:
  case(name,False,'Unsafe',lambda m,p=path:m['files'].__setitem__(p,{'bytes':0,'sha256':'0'*64}))
 case('symlink_input',False,'Nonregular or symlink input',symlink=True)
 require(sha(original)==original_hash and sha(tool)==toolhash and all(sha(author/r)==h for r,h in tracked.items()),'Original author input or adapter changed');result={'passed':True,'optimization_level':sys.flags.optimize,'case_count':len(cases),'cases':cases,'test_source_sha256':sha(__file__),'adapter_source_sha256':toolhash,'original_author_freeze_sha256':original_hash,'all_original_author_files_unchanged':True,'scope':'Schema-only handoff controls. Complete scientific/model acceptance still requires the independent original-STL execution and final reviews.'};(out/'adapter-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'optimization_level':sys.flags.optimize,'case_count':len(cases)}))
if __name__=='__main__':main()
