# v15 作者驗證摘要

2026-10-17 UTC。作者階段已可交付獨立驗證；尚未發布、未試印，獨立全量與正式九圖 replay 尚未完成。

- 原 STL：47,770 三角形、單一殼，219×107×119 mm；所有尺寸為模型估值，沒有真實 1:N 比例。
- normal／-O 各 1,785 XY 截層、22,364 原多邊形全部通過原 0.8 mm opening／1% 個別損失門檻。
- 各 477,700 原射線、5,732,400 lossless hex 描述欄全部驗證；零數值短線，有限採樣最短首弦為 0.8499984741210938 mm。
- 各 851,184 原面 closed-AABB 候選對完成精確分類，374,637 合法接觸，零不合法相交。
- 各 26 個數值 crossing／parity flags 仍在原報告。原 generic strict=false、full 實際 exit1 未變。
- 所有原 flags 均使用同次實際記錄 hex 射線完成精確分類與首弦有理數比較；兩 exact 程序 exit0。作者 normal／-O r2 彙整及比較為 bounded_supplemental_pass=true，科學內容一致。
- 首版作者彙整器因 sum 與逐項 += 語義不同而拒絕出結果。原失敗、舊來源完整保存；最小修正使用原 producer 同序 builtin sum，仍 exact ==，沒有容差。獨立核對與 154 回歸控通過。
- 原碼重建 STL 逐byte相同、完整場景狀態一致，saved Blend 為原三角形同一網格。24 個 final-scene normal／-O 控制全部通過。
- 九張正式原圖已獲獨立來源／外觀 GO。公開用 PNG 只清除指定時間／私人路徑 metadata，完整對照見 metadata-cleanup-binding.json；原圖未覆寫。唯一正式九圖 replay 留待獨立 QA。

全部精確路徑與 SHA256 見 AUTHOR-VERIFICATION-SUMMARY.json。有限通過不代表全域壁厚、結構強度、支撐可拆或列印成功；原嚴格結果與補證結論不可合併冒稱 generic strict pass。
