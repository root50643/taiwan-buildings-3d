# Terminal plan and exact exclusions: fill procedure

Prepared while the parent's serialized pipeline is running. Do not hash a final
roster or replace terminal placeholders until the parent explicitly releases
that step. Preserve all frozen source bytes. Use new plan/decision filenames at
every revision, never overwrite a file already captured by a source roster.

## 1. Bind the completed stages

Read and hash the original reports, rather than infer success from a log tail.
The current expected independent paths are:

- `final-v15-r1/independent-execution-summary.json`
- `postflight-v15-r1/postflight-summary.json`
- `packaging-controls-v15-r1/results.json`
- `inventory-controls-v15-r1/results.json`
- `package-controls-{normal,optimized}-v2/results.json`: 101 each
- `public-bundle-controls-{normal,optimized}-v15/results.json`: 27 each
- `control-blend-profile-controls-{normal,optimized}-v15/results.json`: 11 each
- `private-checkpoint-controls-{normal,optimized}-v15/results.json`: 28 each
- `archive-preparation/generator-controls-{normal,optimized}-v1/results.json`:
  45 each
- `blend-sdna-controls-{normal,optimized}-v15/results.json`: primary decoder
- `control-blend-sdna-controls-{normal,optimized}-v15/results.json`: control
  decoder, 11 each

Confirm actual field names, expected counts, optimization modes and unchanged
source gates against the frozen source and final result. Bind each file with
logical path, integer bytes and full SHA256. Both normal and optimized runs are
required. The model's original strict false result remains false.

The inventory source freeze is
`INVENTORY-CONTROLS-TOOLING-FREEZE-v15.json`, SHA256
`5fb768e3eb694269eb1d0e92ca4eef2c9b41afede0829b1d4552cc034b130b63`.
Its generator/test hashes are `60633de9…` and `6814a899…`. The current public
helper is `75f1604d…`; full hashes are in the source freeze and controls document.

## 2. Prepare exact Blend exclusion proposals

There is one intentionally unclassified SDNA-index error in each batch suite.
Its rejection is itself a successful negative control; running it again as an
ordinary profile candidate must correctly HOLD. Candidate paths to examine,
without assuming their existence or approval, are the following two suffixes
under each completed `control-blend-profile-controls-{mode}-v15` directory:

- `unclassified_decoder_error_is_not_policy_success/inputs/fixture.blend`
- `unclassified_decoder_error_is_not_policy_success/profiles/00000-original.blend`

For every actual regular candidate, bind its raw bytes/SHA and the exact
completed report's matching rejection case. Require the report's generator and
tested batch source hashes, exact return/error semantics, and fixture SHA.
Produce individual proposed rows for parent review, including repeated
identities at different original paths. Do not grant exclusion to all files in
the case directory or to a matching filename alone. The row schema is described
in `FINAL-INVENTORY-GENERATOR.md`; only parent-approved exact rows enter
`reviewed_blend_profile_exclusions`.

Other malformed Blend controls remain in the candidate roster unless separately
reviewed with a supported exact exclusion proof. An independent two-mode policy
rejection later records the original privately; an unknown decoder exception
still stops the batch.

## 3. Preserve complete original scope

Use independent = complete QA tree and author = its frozen author root, with
the canonical alias from `independent/final-v15-r1/frozen` to `author`. Do not
exclude failed runs, audit directories, logs, bytecode, support files, nested
archives or synthetic fixtures by directory or extension.

Specifically retain the parent's cache-guard lifecycle records and original
failed-postflight payloads. The historical author bytecode has been preserved
at `independent/audit/runtime-bytecode-quarantine-v15/historical-author-py312/qa_common.cpython-312.pyc`:
6,703 bytes, SHA256
`df96223a63f6111e1710a71627a1d1710aa70ee94acc734de6de44e8f240fa0b`.
The generator's identity lookup can bind the old author namespace row to this
preserved original. Inventory all additional quarantine files and failed-run
siblings that actually exist; this one known identity is not a directory waiver.

## 4. Roster, profile batch and final snapshot

After the parent approves the exact exclusions, create a new roster plan from
the inactive template. Run the prepared roster CLI only at the authorized
terminal point. Bind both resulting roster files in a new final plan. Then the
parent's independent profile batch emits accepted/rejected exact rows and raw
diagnostics. The generator independently reparses accepted Blend originals and
checks candidate coverage, both-mode diagnostic identities and retained copies.

Refresh the complete tree at finalize. All current regular source paths must
be direct, selected into the controls archive, or individually omitted with
exact bytes/SHA and an allowed category plus a specific reason. Preserve every
original version referenced by both the historical baseline and first-stage
roster. New metadata gets new filenames; it must not erase the roster's earlier
source version.

## 5. Resolve HOLD rows, then hand off

Treat new malformed/nested payloads as HOLD. A private-control omission needs
an exact reviewed original row; a duplicate-reproduction omission additionally
needs complete controlled v2 generation and selected all-member evidence,
including the retained exact `ARCHIVE-SCOPE.json` member. Never infer that a
scientific payload is disposable because a scan encountered private text.

The public direct path contract remains the exact 181-path contract. Its four
large direct science CSVs use the public helper's narrow streaming branch;
unknown large archive candidates receive no generic exception. Exclude direct
and archive-selected rows from final omissions, accounting for intentional
direct/archive overlap without losing either binding.

Hand off actual new file identities and final paths to the public worker.
Selection readiness is only controls/publication evidence readiness, not model
GO. The final original-tool safe-extract/all-member verification and deterministic
archive rebuild remain separate execution steps under the parent's lock.
