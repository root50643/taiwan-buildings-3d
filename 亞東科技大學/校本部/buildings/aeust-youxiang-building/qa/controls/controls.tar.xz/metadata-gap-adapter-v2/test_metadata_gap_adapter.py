"""Twenty-eight synthetic helper-level controls. No real CLI success claimed.

Run only when the parent schedules the pure normal/-O controls. All fixtures are
new synthetic bytes. No science, scanner, compression, model, or real HOLD edits.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import types

sys.dont_write_bytecode = True
CASE_NAMES = (
    'exact_gap_preserves_original_evidence',
    'same_path_current_bytes_remain_separately_retained',
    'wrong_gap_path_rejected', 'wrong_gap_size_rejected', 'wrong_gap_hash_rejected',
    'second_historical_missing_rejected', 'science_dependency_rejected',
    'runner_dependency_rejected', 'public_dependency_rejected', 'replay_dependency_rejected',
    'malformed_and_negative_proof_dependency_rejected', 'extra_hold_rejected',
    'current_unresolved_rejected', 'mutated_exact_binding_rejected',
    'source_changed_or_replaced_rejected', 'unsafe_read_and_strict_metadata_rejected',
    'exact_four_copy_then_gap_chain_preserves_original_five',
    'changed_upstream_source_binding_rejected', 'changed_original_output_chain_binding_rejected',
    'non_four_copy_extra_hold_rejected', 'unapproved_chain_row_delta_rejected',
    'widened_or_narrowed_deferred_set_rejected', 'required_proof_gap_path_rejected',
    'required_proof_gap_identity_rejected', 'late_source_change_prevents_success_report',
    'failed_derived_readback_prevents_success_report',
    'reported_case_namespace_differs_from_actual_fixture',
    'true_private_control_dependency_mutation_rejected')
EXPECTATIONS = ['accept'] * 2 + ['reject'] * 14 + ['accept'] + ['reject'] * 9 + ['accept', 'reject']


def check(value, message):
    if not value:
        raise RuntimeError(message)


def bootstrap_read(path):
    path = Path(os.path.abspath(path))
    parent = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            parent = child
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        try:
            before = os.fstat(fd)
            check(stat.S_ISREG(before.st_mode), 'Bootstrap source is nonregular')
            parts = []
            while True:
                part = os.read(fd, 1024 * 1024)
                if not part:
                    break
                parts.append(part)
            after = os.fstat(fd)
            named = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
            fields = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns)
            check(fields(before) == fields(after) == fields(named), 'Bootstrap source changed')
            data = b''.join(parts)
            check(len(data) == before.st_size, 'Bootstrap source size changed')
            return data
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def load_adapter(path):
    raw = bootstrap_read(path)
    module = types.ModuleType('metadata_gap_adapter_under_test')
    module.__file__ = str(Path(os.path.abspath(path)))
    module.__package__ = ''
    # Exactly these bytes are hashed, compiled once, and executed without pycache.
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    return module, raw


def rejected(fn, message):
    try:
        fn()
    except (ValueError, OSError, KeyError, TypeError, IndexError):
        return
    raise RuntimeError(message)


def synthetic_bundle(m):
    def descriptor(name, raw):
        return {'source_relative_path': name, 'bytes': len(raw), 'sha256': m.digest(raw)}
    selected = {**descriptor('independent/synthetic-selected.txt', b'synthetic selected\n'),
                'archive_path': 'synthetic-selected.txt', 'transformation': 'identity'}
    omitted = {**descriptor('independent/synthetic-private.txt', b'synthetic private\n'),
               'category': 'private_execution_log', 'reason': 'Pure synthetic private bytes retained without publication.'}
    direct = {**descriptor('author/synthetic-direct.txt', b'synthetic direct\n'),
              'type': 'regular', 'disposition': 'public_direct_identity',
              'public_relative_path': 'synthetic-direct.txt'}
    inventory = {'all_snapshot_paths_accounted': True, 'source_changes_during_static_read': [],
                 'regular_file_count': 3,
                 'files': [{**selected, 'type': 'regular', 'disposition': 'preserve_original_bytes'},
                           {**omitted, 'type': 'regular', 'disposition': 'private_original_retained'}, direct],
                 'historical_nonroutine_versions_missing': [copy.deepcopy(m.GAP)],
                 'historical_original_version_accounting': [
                     {**m.GAP, 'status': 'historical_descriptor_only', 'retained_at': None,
                      'prior_disposition': 'omit_private_content'}]}
    result = {'passed': False, 'model_go': False, 'hold_count': 1,
              'all_source_bytes_unchanged': True, 'scanner_source_sha256': m.SCANNER_SHA,
              'public_scanner_helper_sha256': m.HELPER_SHA,
              'source_inventory_regular_count': 3, 'selected_count': 1, 'private_omission_count': 1}
    selection = {'passed': False, 'model_go': False, 'files': [selected],
                 'original_payload_inventory_complete': True, 'all_selected_dependencies_publicly_mapped': False}
    omissions = {'ready_for_final_assembly': False, 'files': [omitted]}
    findings = {'private': True, 'holds': [{'reason': m.HISTORICAL_REASON, 'files': [copy.deepcopy(m.GAP)]}]}
    required = {name: [m.ref(selected)] for name in m.SET_NAMES}
    return [result, inventory, selection, omissions, findings, required]


def gate(m, bundle):
    return m.validate_only_gap(*bundle)


def positive_exact(m, directory):
    bundle = synthetic_bundle(m)
    before = copy.deepcopy(bundle)
    disclosure = gate(m, bundle)
    derived = m.derive_documents(bundle[1], bundle[2], bundle[3], disclosure)
    check(bundle == before, 'Inputs mutated')
    check(derived['selection']['passed'] is True and derived['omissions']['ready_for_final_assembly'] is True,
          'Derived readiness absent')
    for name, value in derived.items():
        check(value['gap_acknowledged'] is True and value['all_historical_retained'] is False
              and value['model_go'] is False, 'Truthful gap/model flags absent')
    check(derived['inventory']['historical_nonroutine_versions_missing'] == [m.GAP], 'Missing row rewritten')
    check(derived['inventory']['historical_original_version_accounting']
          == bundle[1]['historical_original_version_accounting'], 'Historical retention rewritten')
    m.write_fresh_bundle(directory / 'derived-synthetic',
                         {m.DERIVED[key]: m.dump(value) for key, value in derived.items()})


def positive_current_path(m, directory):
    bundle = synthetic_bundle(m)
    latest = {'source_relative_path': m.GAP['source_relative_path'], 'bytes': 19,
              'sha256': m.digest(b'new synthetic state'), 'category': 'private_path_report',
              'reason': 'Current synthetic progress metadata is independently retained.'}
    bundle[1]['files'].append({**latest, 'type': 'regular', 'disposition': 'private_original_retained'})
    bundle[1]['regular_file_count'] += 1
    bundle[0]['source_inventory_regular_count'] += 1
    bundle[0]['private_omission_count'] += 1
    bundle[3]['files'].append(latest)
    gate(m, bundle)
    check(bundle[1]['historical_nonroutine_versions_missing'] == [m.GAP], 'Old missing identity erased')


def wrong_gap(m, key, value):
    bundle = synthetic_bundle(m)
    bundle[4]['holds'][0]['files'][0][key] = value
    bundle[1]['historical_nonroutine_versions_missing'][0][key] = value
    bundle[1]['historical_original_version_accounting'][0][key] = value
    rejected(lambda: gate(m, bundle), 'Different gap accepted')


def second_missing(m, directory):
    bundle = synthetic_bundle(m)
    second = {**m.GAP, 'source_relative_path': 'independent/another-historical.json'}
    bundle[1]['historical_nonroutine_versions_missing'].append(second)
    bundle[1]['historical_original_version_accounting'].append(
        {**second, 'status': 'historical_descriptor_only', 'retained_at': None})
    bundle[4]['holds'][0]['files'].append(second)
    rejected(lambda: gate(m, bundle), 'Second missing accepted')


def dependency(m, families):
    for family in families:
        for variant in ('path', 'identity'):
            bundle = synthetic_bundle(m)
            row = copy.deepcopy(m.GAP)
            if variant == 'path':
                row['sha256'] = m.digest(b'different current byte identity')
                row['bytes'] = 31
            else:
                row['source_relative_path'] = 'independent/different-name-same-identity.json'
            bundle[5][family].append(row)
            rejected(lambda: gate(m, bundle), 'Required gap dependency accepted: ' + family)


def extra_hold(m, directory):
    bundle = synthetic_bundle(m)
    bundle[0]['hold_count'] = 2
    bundle[4]['holds'].append({'reason': 'Final selected dependency/scanner closure failed'})
    rejected(lambda: gate(m, bundle), 'Extra HOLD accepted')
    bundle[0]['hold_count'] = 1
    rejected(lambda: gate(m, bundle), 'Miscounted extra HOLD accepted')


def current_unresolved(m, directory):
    bundle = synthetic_bundle(m)
    bundle[1]['files'][0]['disposition'] = 'HOLD_unresolved_exact_publication_disposition'
    rejected(lambda: gate(m, bundle), 'Unresolved current disposition accepted')


def synthetic_sources(m, directory):
    root = directory / 'synthetic-independent'
    root.mkdir()
    author = root / 'frozen'
    author.mkdir()
    path = root / 'input.txt'
    path.write_bytes(b'synthetic input\n')
    source = m.Sources({'independent': root, 'author': author}, {'independent/frozen': 'author'})
    bound = {'source_relative_path': 'independent/input.txt', 'bytes': 16,
             'sha256': m.digest(b'synthetic input\n')}
    return source, path, bound


def mutated_binding(m, directory):
    source, path, bound = synthetic_sources(m, directory)
    wrong = {**bound, 'sha256': '0' * 64}
    rejected(lambda: source.data(wrong), 'Mutated SHA binding accepted')
    wrong = {**bound, 'bytes': True}
    rejected(lambda: source.data(wrong), 'Boolean byte count accepted')
    wrong = {**bound, 'bytes': bound['bytes'] + 1}
    rejected(lambda: source.data(wrong), 'Mutated size binding accepted')


def source_changed(m, directory):
    source, path, bound = synthetic_sources(m, directory)
    source.data(bound)
    replacement = path.with_name('replacement.txt')
    replacement.write_bytes(b'synthetic input\n')
    os.replace(replacement, path)
    rejected(source.unchanged, 'Same-byte replaced inode accepted')
    source2, path2, bound2 = synthetic_sources(m, directory / 'second')
    source2.data(bound2)
    path2.write_bytes(b'mutated content\n')
    rejected(source2.unchanged, 'Changed source bytes accepted')


def unsafe_and_strict(m, directory):
    real = directory / 'regular.txt'
    real.write_bytes(b'synthetic')
    leaf_link = directory / 'leaf-link'
    leaf_link.symlink_to(real.name)
    rejected(lambda: m.read_path(leaf_link), 'Leaf symlink read accepted')
    ancestor = directory / 'ancestor-link'
    ancestor.symlink_to('.', target_is_directory=True)
    rejected(lambda: m.read_path(ancestor / 'regular.txt'), 'Ancestor symlink read accepted')
    fifo = directory / 'fifo'
    os.mkfifo(fifo)
    created_fifo = fifo.lstat()
    fifo_rejected = False
    try:
        rejected(lambda: m.read_path(fifo), 'FIFO read accepted')
        fifo_rejected = True
    finally:
        current_fifo = fifo.lstat()
        check(stat.S_ISFIFO(current_fifo.st_mode)
              and (created_fifo.st_dev, created_fifo.st_ino) == (current_fifo.st_dev, current_fifo.st_ino),
              'Refuse removal of a substituted FIFO path')
        fifo.unlink()
    fifo_descriptor = {'relative_path': 'fifo', 'type': 'fifo'}
    (directory / 'fifo-control-descriptor.json').write_bytes(m.dump({
        **fifo_descriptor, 'descriptor_sha256': m.digest(m.dump(fifo_descriptor)),
        'unsafe_read_rejected': fifo_rejected, 'own_fifo_removed': not os.path.lexists(fifo)}))
    for raw in (b'{"x": 1, "x": 2}', b'{"x": NaN}', b'{"x": Infinity}', b'{"x": 1e999}'):
        rejected(lambda raw=raw: m.parse(raw), 'Non-strict JSON accepted')
    for name in ('../escape', '/absolute', 'a/../b', 'a\\b', 'a//b'):
        rejected(lambda name=name: m.safe(name), 'Unsafe logical path accepted')
    m.write_fresh_bundle(directory / 'fresh', {'one.json': b'{}\n'})
    rejected(lambda: m.write_fresh_bundle(directory / 'fresh', {'one.json': b'{}\n'}),
             'Existing output accepted')


def synthetic_chain(m):
    """Descriptor-only tiny fixtures: no real CSV bytes or full manifests exist."""
    bundle = synthetic_bundle(m)
    result, inventory, selection, omissions, findings, required = bundle
    original_names = ('private-original-payload-inventory-FINAL.json', 'controls-selection-FINAL.json',
                      'private-omissions-FINAL.json', 'private-inventory-findings-FINAL.json')
    for name in m.COPY_PATHS:
        inventory['files'].append({'source_relative_path': name, **m.CSV, 'type': 'regular',
                                  'disposition': 'HOLD_unresolved_exact_publication_disposition'})
    for name, destination in m.CANONICAL.items():
        inventory['files'].append({'source_relative_path': name, **m.CSV, 'type': 'regular',
                                  'disposition': 'public_direct_identity', 'public_relative_path': destination})
    for name in sorted(m.COPY_DEPENDENCIES):
        raw = ('synthetic proof ' + name).encode()
        row = {'source_relative_path': name, 'bytes': len(raw), 'sha256': m.digest(raw),
               'archive_path': 'synthetic/' + name, 'transformation': 'identity'}
        inventory['files'].append({**row, 'type': 'regular', 'disposition': 'preserve_original_bytes'})
        selection['files'].append(row)
    inventory['regular_file_count'] = len(inventory['files'])
    result.update(source_inventory_regular_count=len(inventory['files']), selected_count=len(selection['files']), hold_count=5)
    findings['holds'] = [{'source_relative_path': name,
        'reason': 'Exact public scan rejected; review proof/profile or explicit private disposition',
        'error': 'Decoded byte safety limit exceeded'} for name in m.COPY_PATHS] + findings['holds']
    originals = dict(zip(original_names, (inventory, selection, omissions, findings)))
    def binding(name):
        raw = ('synthetic binding ' + name).encode()
        return {'source_relative_path': 'independent/synthetic-chain/' + name,
                'bytes': len(raw), 'sha256': m.digest(raw)}
    expected = {'original_result': binding('original-result.json'), 'original_plan': binding('original-plan.json'),
                'original_outputs': {name: binding(name) for name in sorted(m.ORIGINAL_OUTPUTS)},
                'adapter_source': binding('upstream.py'), 'adapter_test_source': binding('upstream-tests.py'),
                'adapter_controls': {mode: binding('upstream-' + mode + '.json') for mode in m.MODES}}
    entries = {'qa/v15-full/' + mode + '/' + m.CSV_REL: copy.deepcopy(m.CSV) for mode in m.MODES}
    science = {'strict_passed': False, 'audit_passed': True, 'audit_completed': True,
              'audit_original_numerical_strict_passed': False, 'csv_data_rows': 477700,
              'compressed_bytes': m.CSV['bytes'], 'compressed_sha256': m.CSV['sha256'],
              'decoded_bytes': 580378890,
              'decoded_sha256': '8534788024a73b04e27e1184fa23cacc59da04aa5f2c2180d8b7b528315deedc',
              'all_original_numerical_flag_predicates_recomputed': True,
              'all_expected_flag_indices_and_reasons_match': True,
              'stl_sha256': '46649566e965a049e6e333e9d82b075407c8e926e55c9034f11fbe3dbdf15a5d',
              'dense_report_hash_bound': True}
    evidence = {'anchors': copy.deepcopy(m.COPY_ANCHORS),
        'fixture_descriptors': [{'source_relative_path': name, **m.CSV} for name in m.COPY_PATHS],
        'canonical_descriptors': [{'source_relative_path': name, **m.CSV} for name in m.CANONICAL],
        'direct_mappings': copy.deepcopy(m.CANONICAL),
        'actual_descriptors': {name: copy.deepcopy(m.CSV) for name in set(m.COPY_PATHS) | set(m.CANONICAL)},
        'freeze_count': 3690, 'adapter_mapping_counts': {mode: 3691 for mode in m.MODES},
        'freeze_entries': entries, 'adapter_entries': {mode: copy.deepcopy(entries) for mode in m.MODES},
        'control_results': {mode: {'passed': True, 'optimization_level': level, 'case_count': 15,
                                  'all_cases_passed': True, 'positive_complete_mapping_passed': True,
                                  'all_original_author_files_unchanged': True} for level, mode in enumerate(m.MODES)},
        'comparison_rows': [{'mode': mode, 'logical_file': m.CSV_REL, 'author_sha256': m.CSV['sha256'],
                             'independent_sha256': m.CSV['sha256'], 'bitwise_identical': True,
                             'only_allowed_non_scientific_differences': [], 'scientific_evidence_identical': True}
                            for mode in m.MODES],
        'canonical_science_reports': {name: copy.deepcopy(science) for name in m.CANONICAL},
        'publicly_retained_dependencies': sorted(m.COPY_DEPENDENCIES)}
    derived = {key: copy.deepcopy(value) for key, value in zip(
        ('inventory', 'selection', 'omissions', 'findings'), (inventory, selection, omissions, findings))}
    added = [{'source_relative_path': name, **m.CSV, 'category': 'duplicate_reproduction_or_scratch',
              'reason': m.COPY_OMISSION_REASON} for name in m.COPY_PATHS]
    for row in derived['inventory']['files']:
        if row['source_relative_path'] in m.COPY_PATHS:
            row.update(disposition='private_original_retained', category='duplicate_reproduction_or_scratch',
                       reason=m.COPY_OMISSION_REASON)
    from collections import Counter
    derived['inventory']['disposition_counts'] = dict(Counter(row['disposition'] for row in derived['inventory']['files']))
    derived['omissions']['files'] = sorted(omissions['files'] + added, key=lambda row: row['source_relative_path'])
    derived['findings']['holds'] = [{'reason': m.HISTORICAL_REASON, 'files': [copy.deepcopy(m.GAP)]}]
    transition = {'exact_source_copy_count': 4, 'category': 'duplicate_reproduction_or_scratch',
        'original_passed': False, 'original_hold_count': 5, 'remaining_hold_count': 1,
        'remaining_holds': copy.deepcopy(derived['findings']['holds']), 'historical_gap_acknowledged': False,
        'all_historical_retained': False, 'canonical_complete_science_must_remain_direct': True,
        'canonical_whole_stream_privacy_scan_still_required': True, 'generic_decoded_byte_limit_unchanged': 536870912,
        'selection_file_rows_unchanged': True, 'historical_accounting_unchanged': True,
        'added_private_dispositions': added, 'model_go': False}
    upstream = {'schema': 'aeust-exact-source-copy-duplicate-result-v1', 'model_go': False,
                **copy.deepcopy(expected), 'graph_evidence': evidence, 'transition': transition}
    return result, originals, upstream, derived, expected, required


def positive_chain(m, directory):
    fixture = synthetic_chain(m)
    before = copy.deepcopy(fixture)
    remaining, transition = m.validate_source_copy_chain(*fixture[:5])
    check(fixture == before and fixture[0]['hold_count'] == 5 and fixture[0]['passed'] is False,
          'Original five-HOLD result changed')
    check(remaining['hold_count'] == 1 and transition['historical_gap_acknowledged'] is False,
          'Upstream must leave one historical HOLD')
    d = fixture[3]
    disclosure = m.validate_only_gap(remaining, d['inventory'], d['selection'], d['omissions'], d['findings'], fixture[5])
    check(disclosure['model_go'] is False and disclosure['all_historical_retained'] is False,
          'Chained historical gap changed model/retention claims')
    check(d['selection']['files'] == fixture[1]['controls-selection-FINAL.json']['files'], 'Selection changed')


def chain_source_binding(m, directory):
    fixture = synthetic_chain(m)
    fixture[2]['adapter_source']['sha256'] = '0' * 64
    rejected(lambda: m.validate_source_copy_chain(*fixture[:5]), 'Changed upstream source accepted')
    m.validate_copy_source_bindings(m.COPY_SOURCE, m.COPY_TEST)
    rejected(lambda: m.validate_copy_source_bindings({**m.COPY_SOURCE, 'sha256': '0' * 64}, m.COPY_TEST),
             'Changed pinned source-copy source accepted')
    rejected(lambda: m.validate_copy_source_bindings(m.COPY_SOURCE, {**m.COPY_TEST, 'bytes': m.COPY_TEST['bytes'] + 1}),
             'Changed pinned source-copy test accepted')


def chain_output_binding(m, directory):
    fixture = synthetic_chain(m)
    fixture[2]['original_outputs']['private-inventory-findings-FINAL.json']['sha256'] = '0' * 64
    rejected(lambda: m.validate_source_copy_chain(*fixture[:5]), 'Changed original output chain accepted')


def chain_extra_hold(m, directory):
    fixture = synthetic_chain(m)
    fixture[1]['private-inventory-findings-FINAL.json']['holds'][0]['source_relative_path'] = 'independent/unapproved-copy.csv.xz'
    rejected(lambda: m.validate_source_copy_chain(*fixture[:5]), 'Non-four-CSV HOLD accepted')
    fixture = synthetic_chain(m)
    fixture[0]['hold_count'] = 6
    fixture[1]['private-inventory-findings-FINAL.json']['holds'].append({'reason': 'Extra unresolved scanner closure'})
    rejected(lambda: m.validate_source_copy_chain(*fixture[:5]), 'Sixth HOLD accepted')


def chain_row_delta(m, directory):
    fixture = synthetic_chain(m)
    fixture[3]['inventory']['files'][0]['sha256'] = '0' * 64
    rejected(lambda: m.validate_source_copy_chain(*fixture[:5]), 'Nonwhitelisted row delta accepted')


def deferred_scope(m, directory):
    exact = sorted(m.DEFERRED_DIRECT)
    m.validate_deferred_sources(exact)
    rejected(lambda: m.validate_deferred_sources(exact[:-1]), 'Narrowed deferred set accepted')
    rejected(lambda: m.validate_deferred_sources(exact + ['independent/new-future-report.json']), 'Widened deferred set accepted')
    rejected(lambda: m.validate_deferred_sources(exact[:-1] + ['author/README.md']), 'Different base181 subset accepted')


def proof_gap(m, by_identity):
    row = copy.deepcopy(m.GAP)
    if by_identity:
        row['source_relative_path'] = 'independent/proof-using-old-metadata-identity.json'
    else:
        row.update(bytes=19, sha256=m.digest(b'new synthetic state'))
    rejected(lambda: m.protect_proof_references([row]), 'Historical gap required proof accepted')


def late_source_change(m, directory):
    out = directory / 'late-source-failure'
    def fail():
        raise ValueError('Synthetic late source mutation')
    rejected(lambda: m.write_fresh_bundle(out, {'synthetic-derived.json': b'{}\n',
             m.RESULT_NAME: b'{"passed": true}\n'}, before_commit=fail), 'Late source change accepted')
    check(not os.path.lexists(out / m.RESULT_NAME), 'Success report survived source refusal')


def failed_readback(m, directory):
    out = directory / 'failed-readback'
    original_read = m.read_at
    def corrupted_read(parent, leaf, keep=True):
        data, actual, sid = original_read(parent, leaf, keep)
        if leaf == 'synthetic-derived.json':
            actual = {**actual, 'sha256': '0' * 64}
        return data, actual, sid
    m.read_at = corrupted_read
    try:
        rejected(lambda: m.write_fresh_bundle(out, {'synthetic-derived.json': b'{}\n',
                 m.RESULT_NAME: b'{"passed": true}\n'}), 'Failed derived readback accepted')
    finally:
        m.read_at = original_read
    check(not os.path.lexists(out / m.RESULT_NAME), 'Success report survived readback refusal')
    out2 = directory / 'late-output-change'
    def mutate_output():
        (out2 / 'synthetic-derived.json').write_bytes(b'{"changed":true}\n')
    rejected(lambda: m.write_fresh_bundle(out2, {'synthetic-derived.json': b'{}\n',
             m.RESULT_NAME: b'{"passed": true}\n'}, before_commit=mutate_output), 'Late output mutation accepted')
    check(not os.path.lexists(out2 / m.RESULT_NAME), 'Success report survived changed output')


def private_reported_fixture(m, mode='normal'):
    # Descriptor-only synthetic graph: no gzip or other container is created.
    case_name = 'raw-identity-mutated'
    index, reported_name = m.PRIVATE_CASE_INPUTS[case_name]
    prefix = 'independent/package-controls-' + mode + '-v2'
    actual_identity = {'bytes': 477, 'sha256': m.digest(b'synthetic actual 477-byte identity')}
    reported = {'source_relative_path': reported_name, 'archive_path': 'selected/' + reported_name,
                **actual_identity, 'transformation': 'identity'}
    selected = {'passed': True, 'model_go': False, 'files': [copy.deepcopy(reported)]}
    selection_bytes = m.dump(selected)
    case = {'case': case_name, 'passed': True, 'expected_accept': False, 'returncode': 1,
            'expected_rejection_reason': 'Synthetic exact identity rejection'}
    proof = {'result': {'source_relative_path': prefix + '/results.json', 'bytes': 19404,
                        'sha256': m.PRIVATE_CASE_RESULT_SHAS[mode]},
             'generator_source': copy.deepcopy(m.PRIVATE_CASE_GENERATOR),
             'case_index': index, 'case_key': 'case', 'case': case,
             'case_selection': {'source_relative_path': prefix + '/' + case_name + '/selection.json',
                                'bytes': len(selection_bytes), 'sha256': m.digest(selection_bytes)},
             'case_input_row': copy.deepcopy(reported),
             'tested_source': {'source_relative_path': 'independent/archive-preparation/package_controls_v2.py',
                               'bytes': 47569, 'sha256': m.SCANNER_SHA}}
    row = {'source_relative_path': prefix + '/' + case_name + '/input/' + reported_name.split('/', 1)[1],
           **actual_identity, 'approved': True, 'category': 'private_control_fixture',
           'control_proof': proof}
    cases = [{'synthetic_unused_case': number} for number in range(101)]
    cases[index] = copy.deepcopy(case)
    result = {'passed': True, 'model_go': False, 'case_count': 101,
              'optimization_level': m.MODES.index(mode), 'package_source_sha256': m.SCANNER_SHA,
              'test_source_sha256': m.PRIVATE_CASE_GENERATOR['sha256'],
              'all_original_sources_unchanged': True, 'cases': cases}
    current = {r['source_relative_path']: m.ref(r) for r in [row] + [proof[key] for key in
               ('result', 'generator_source', 'tested_source', 'case_selection')]}
    current[reported_name] = {'source_relative_path': reported_name, 'bytes': 470,
                              'sha256': m.digest(b'synthetic separately current 470-byte identity')}
    return row, selected, result, current


def reported_namespace(m, directory):
    for mode in m.MODES:
        row, selection, result, current = private_reported_fixture(m, mode)
        refs = m.private_control_reported_case_refs('aeust-reviewed-exact-private-dispositions-v2',
                                                   row, selection, result)
        expected_names = {row['source_relative_path']} | {
            row['control_proof'][key]['source_relative_path'] for key in
            ('result', 'generator_source', 'tested_source', 'case_selection')}
        check({r['source_relative_path'] for r in refs} == expected_names and len(refs) == 5,
              'Actual private fixture or a true required proof escaped closure')
        reported_name = row['control_proof']['case_input_row']['source_relative_path']
        check(reported_name not in expected_names and current[reported_name]['bytes'] == 470
              and row['bytes'] == 477, 'Reported and current namespaces did not differ')
        for actual in refs:
            check(actual == current[actual['source_relative_path']], 'True required source identity differs')
    m.write_fresh_bundle(directory / 'descriptor-evidence', {'namespace-scope.json': m.dump({
        'synthetic_descriptor_only': True, 'actual_fixture_bytes': 477,
        'separate_current_reported_path_bytes': 470, 'required_actual_reference_count': 5,
        'reported_row_bound_in_original_case_selection': True, 'both_modes_exercised': True})})


def true_private_dependency(m, directory):
    schema = 'aeust-reviewed-exact-private-dispositions-v2'
    row, selection, result, current = private_reported_fixture(m)
    for key in ('generator_source', 'tested_source', 'result'):
        changed = copy.deepcopy(row)
        changed['control_proof'][key]['sha256'] = '0' * 64
        rejected(lambda: m.private_control_reported_case_refs(schema, changed, selection, result),
                 'Changed real private-control proof identity accepted')
    changed_selection = copy.deepcopy(selection)
    changed_selection['files'][0]['bytes'] = 470
    rejected(lambda: m.private_control_reported_case_refs(schema, row, changed_selection, result),
             'Reported row missing from exact case selection accepted')
    changed = copy.deepcopy(row)
    changed['bytes'] = 470
    rejected(lambda: m.private_control_reported_case_refs(schema, changed, selection, result),
             'Actual fixture mismatch accepted')
    rejected(lambda: m.private_control_reported_case_refs('unknown-schema', row, selection, result),
             'Same-named key in unknown document schema skipped')
    changed = copy.deepcopy(row)
    changed['category'] = 'duplicate_reproduction_or_scratch'
    rejected(lambda: m.private_control_reported_case_refs(schema, changed, selection, result),
             'Same-named key outside approved private-control context skipped')
    changed = copy.deepcopy(row)
    changed['control_proof']['extra_dependency'] = m.ref(row)
    rejected(lambda: m.private_control_reported_case_refs(schema, changed, selection, result),
             'Unknown private-control proof field skipped')


def main():
    os.umask(0o077)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    adapter_path = Path(__file__).parent / 'acknowledge_metadata_gap.py'
    own = bootstrap_read(Path(__file__))
    m, source = load_adapter(adapter_path)
    # Fresh output creation uses the adapter's fd-relative implementation.
    m.write_fresh_bundle(args.out, {})
    cases = [
        positive_exact, positive_current_path,
        lambda m, d: wrong_gap(m, 'source_relative_path', 'independent/WRONG.json'),
        lambda m, d: wrong_gap(m, 'bytes', 3815),
        lambda m, d: wrong_gap(m, 'sha256', '0' * 64),
        second_missing,
        lambda m, d: dependency(m, ['science']),
        lambda m, d: dependency(m, ['runner']),
        lambda m, d: dependency(m, ['public_base', 'public_active']),
        lambda m, d: dependency(m, ['replay', 'seed']),
        lambda m, d: dependency(m, ['malformed_proofs', 'negative_proofs', 'other_proofs']),
        extra_hold, current_unresolved, mutated_binding, source_changed, unsafe_and_strict,
        positive_chain, chain_source_binding, chain_output_binding, chain_extra_hold, chain_row_delta,
        deferred_scope, lambda m, d: proof_gap(m, False), lambda m, d: proof_gap(m, True),
        late_source_change, failed_readback, reported_namespace, true_private_dependency]
    check(len(cases) == len(CASE_NAMES) == len(EXPECTATIONS) == 28, 'Wrong case count')
    results = []
    for number, (name, operation) in enumerate(zip(CASE_NAMES, cases)):
        directory = args.out / ('case-' + str(number + 1).zfill(2))
        directory.mkdir()
        # The changed-source case creates a second independent fixture root.
        if name == 'source_changed_or_replaced_rejected':
            (directory / 'second').mkdir()
        try:
            operation(m, directory)
            results.append({'name': name, 'expected': EXPECTATIONS[number],
                            'passed': True, 'scope': 'synthetic_helper_level'})
        except Exception as error:
            # Exception class only: never leak a physical fixture directory.
            results.append({'name': name, 'expected': EXPECTATIONS[number],
                            'passed': False, 'error_type': type(error).__name__,
                            'scope': 'synthetic_helper_level'})
    unchanged = bootstrap_read(adapter_path) == source and bootstrap_read(Path(__file__)) == own
    passed = all(row['passed'] for row in results) and unchanged
    report = {'schema': 'aeust-metadata-gap-synthetic-controls-v2', 'passed': passed,
              'optimization_level': sys.flags.optimize, 'case_count': 28,
              'positive_count': 4, 'negative_count': 24, 'cases': results,
              'scope': 'synthetic_helper_level_not_real_cli', 'real_cli_success_exercised': False,
              'adapter_source_sha256': hashlib.sha256(source).hexdigest(),
              'test_source_sha256': hashlib.sha256(own).hexdigest(),
              'all_original_input_and_tool_bytes_unchanged': unchanged,
              'model_go': False, 'science_or_scanner_executed': False,
              'not_claimed': 'These small helpers do not establish full production CLI acceptance or complete real dependency coverage.'}
    m.write_fresh_bundle(args.out / 'report', {'results.json': m.dump(report)})
    print(json.dumps({'passed': passed, 'case_count': 28, 'positive_count': 4,
                      'negative_count': 24, 'scope': report['scope'], 'model_go': False}, allow_nan=False))
    if not passed:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
