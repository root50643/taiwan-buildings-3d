import gzip, hashlib, json, os, sys
from pathlib import Path
qa = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(qa / 'postflight-tools'))
from artifact_structure import validate_sections
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
files = {qa/'postflight-tools/artifact_structure.py', qa/'verification/check_sections.py',Path(__file__).resolve()}
result={'scope':'Existing section metadata readback only; no geometry recomputation or candidate pass.', 'optimization_level':sys.flags.optimize, 'cpu_affinity':sorted(os.sched_getaffinity(0)), 'modes':{}}
for mode in ('normal','optimized'):
    base=qa/'v15-full'/mode/'standard/sections'
    rp=base/'section-check.json'; report=json.loads(rp.read_text()); dp=base/report['detail_file']; fp=base/report['failure_file']
    files.update((rp,dp,fp))
    for p,expected in ((dp,report['detail_sha256']),(fp,report['failure_sha256'])):
        if sha(p)!=expected: raise RuntimeError('Artifact hash mismatch: '+str(p))
    with gzip.open(dp,'rt') as f: details=json.load(f)
    with gzip.open(fp,'rt') as f: failures=json.load(f)
    result['modes'][mode]=validate_sections(report,details,failures)
result['sources_and_artifacts_sha256']={str(p.relative_to(qa)):sha(p) for p in sorted(files)}
result['mode_science_equal']=result['modes']['normal']==result['modes']['optimized']
result['passed']=result['mode_science_equal'] and len(os.sched_getaffinity(0))==1
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2)); sys.exit(0 if result['passed'] else 1)
