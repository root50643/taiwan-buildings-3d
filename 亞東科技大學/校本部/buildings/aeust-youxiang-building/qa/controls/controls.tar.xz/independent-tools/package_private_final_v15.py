"""Exact private task-root checkpoint; all filesystem traversal is fd-anchored.
Original intentionally unsafe fixture bytes remain opaque. Symlinks are recorded
as descriptors only, and are never followed or recreated during restoration.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,io,json,os,re,stat,sys,zipfile

DIR_FLAGS=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW
READ_FLAGS=os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK

def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(data):return hashlib.sha256(data).hexdigest()
def encode(value):return (json.dumps(value,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
def safe(name):
 return isinstance(name,str) and bool(name) and not PurePosixPath(name).is_absolute() and PurePosixPath(name).as_posix()==name and all(x not in ('','.','..') for x in name.split('/')) and '\\' not in name and '\0' not in name
def absolute(path):return Path(os.path.abspath(os.fspath(path)))
def same_inode(a,b):return (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)
def fingerprint(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def exists_at(fd,name):
 try:os.stat(name,dir_fd=fd,follow_symlinks=False);return True
 except FileNotFoundError:return False
def check_binding(fd,name,child):
 s=os.stat(name,dir_fd=fd,follow_symlinks=False);require(stat.S_ISDIR(s.st_mode) and same_inode(s,os.fstat(child)),'Directory binding changed')

def open_directory(path,create=False):
 """Open every absolute component without following any ancestor symlink."""
 fd=os.open('/',DIR_FLAGS)
 try:
  for part in absolute(path).parts[1:]:
   if create:
    try:os.mkdir(part,0o700,dir_fd=fd)
    except FileExistsError:pass
   child=os.open(part,DIR_FLAGS,dir_fd=fd);os.close(fd);fd=child
  return fd
 except BaseException:os.close(fd);raise

def check_absolute_binding(path,fd):
 current=open_directory(path)
 try:require(same_inode(os.fstat(current),os.fstat(fd)),'Absolute directory binding changed')
 finally:os.close(current)

def parent_fd(rootfd,name):
 require(safe(name),'Unsafe relative path');parts=name.split('/');fd=os.dup(rootfd)
 try:
  for part in parts[:-1]:
   child=os.open(part,DIR_FLAGS,dir_fd=fd);os.close(fd);fd=child
  return fd,parts[-1]
 except BaseException:os.close(fd);raise

def read_regular_at(fd,name,expected_stat=None):
 before=os.stat(name,dir_fd=fd,follow_symlinks=False);require(stat.S_ISREG(before.st_mode),'Source path is not a regular file')
 if expected_stat is not None:require(fingerprint(before)==fingerprint(expected_stat),'Source changed before open')
 filefd=os.open(name,READ_FLAGS,dir_fd=fd)
 with os.fdopen(filefd,'rb') as stream:
  opened=os.fstat(stream.fileno());require(stat.S_ISREG(opened.st_mode) and fingerprint(opened)==fingerprint(before),'Source changed during open');data=stream.read();after=os.fstat(stream.fileno())
 require(fingerprint(after)==fingerprint(opened) and fingerprint(os.stat(name,dir_fd=fd,follow_symlinks=False))==fingerprint(opened),'Source changed during read')
 return data

def read_regular_path(rootfd,name):
 fd,leaf=parent_fd(rootfd,name)
 try:return read_regular_at(fd,leaf)
 finally:os.close(fd)

def read_regular_absolute(path):
 path=absolute(path);fd=open_directory(path.parent)
 try:return read_regular_at(fd,path.name)
 finally:os.close(fd)

def snapshot_fd(rootfd,excluded=None,private=False):
 files=[];links=[];directories=[];blobs={}
 def visit(fd,prefix):
  if private:
   s=os.fstat(fd);require(s.st_uid==os.getuid() and stat.S_IMODE(s.st_mode)&0o077==0,'Restored directory is not owner-only')
  for name in sorted(os.listdir(fd)):
   rel=prefix+name;require(safe(rel),'Unsafe source path');s=os.stat(name,dir_fd=fd,follow_symlinks=False)
   if rel==excluded:
    require(stat.S_ISDIR(s.st_mode),'Checkpoint exclusion is not directory');continue
   if private:require(s.st_uid==os.getuid() and stat.S_IMODE(s.st_mode)&0o077==0,'Restored member is not owner-only')
   if stat.S_ISLNK(s.st_mode):
    target=os.readlink(name,dir_fd=fd);require(fingerprint(os.stat(name,dir_fd=fd,follow_symlinks=False))==fingerprint(s),'Symlink changed during snapshot');links.append({'path':rel,'target_descriptor':target,'target_descriptor_sha256':sha(os.fsencode(target)),'policy':'Descriptor only; never follow or restore this link.'})
   elif stat.S_ISDIR(s.st_mode):
    child=os.open(name,DIR_FLAGS,dir_fd=fd)
    try:
     require(same_inode(s,os.fstat(child)),'Source directory changed during open');directories.append({'path':rel,'source_mode':stat.S_IMODE(s.st_mode)});visit(child,rel+'/');check_binding(fd,name,child)
    finally:os.close(child)
   elif stat.S_ISREG(s.st_mode):
    data=read_regular_at(fd,name,s);h=sha(data);files.append({'path':rel,'bytes':len(data),'sha256':h,'member':'blobs/'+h,'source_mode':stat.S_IMODE(s.st_mode)});blobs.setdefault(h,rel)
   else:raise RuntimeError('Unsupported special source file')
 visit(rootfd,'');return sorted(files,key=lambda x:x['path']),sorted(links,key=lambda x:x['path']),sorted(directories,key=lambda x:x['path']),blobs

def snapshot(root,excluded):
 fd=open_directory(root)
 try:
  result=snapshot_fd(fd,excluded);check_absolute_binding(root,fd);return result
 finally:os.close(fd)

def validate_index(index,names):
 require(index['format']=='aeust-independent-final-private-dedup-v1' and index['complete'] is True,'Invalid restore index')
 rows=index['files'];seen=set();expected={'RESTORE-INDEX.json'};sizes={}
 for row in rows:
  p=row['path'];h=row['sha256'];require(safe(p) and p not in seen and isinstance(h,str) and re.fullmatch('[0-9a-f]{64}',h) and type(row['bytes']) is int and row['bytes']>=0 and row['member']=='blobs/'+h,'Invalid restore reference');seen.add(p);expected.add(row['member']);require(h not in sizes or sizes[h]==row['bytes'],'Conflicting blob size');sizes[h]=row['bytes']
 for row in index['symlink_descriptors']:
  p=row['path'];require(safe(p) and p not in seen and isinstance(row['target_descriptor'],str) and sha(os.fsencode(row['target_descriptor']))==row['target_descriptor_sha256'],'Invalid symlink descriptor');seen.add(p)
 dirs=set()
 for row in index['directories']:
  p=row['path'];require(safe(p) and p not in seen and p not in dirs,'Invalid directory descriptor');dirs.add(p)
 for p in seen|dirs:
  for par in PurePosixPath(p).parents:
   if par.as_posix()=='.':continue
   require(par.as_posix() in dirs,'Missing safe parent directory')
 require(len(names)==len(set(names)) and set(names)==expected,'ZIP member set differs');require(index['regular_file_count']==len(rows) and index['unique_blob_count']==len(sizes) and index['symlink_descriptor_count']==len(index['symlink_descriptors']) and index['regular_file_bytes']==sum(r['bytes'] for r in rows),'Restore index count mismatch')
 return sizes

def secure_write(rootfd,name,data):
 fd,leaf=parent_fd(rootfd,name)
 try:
  filefd=os.open(leaf,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=fd)
  with os.fdopen(filefd,'wb') as stream:stream.write(data)
 finally:os.close(fd)

def restore_bytes(raw,parentfd,leaf,expected_sha):
 require(safe(leaf) and '/' not in leaf and not exists_at(parentfd,leaf),'Fresh restore destination required');require(sha(raw)==expected_sha,'ZIP hash differs');s=os.fstat(parentfd);require(s.st_uid==os.getuid() and stat.S_IMODE(s.st_mode)&0o022==0,'Restore parent must be owned and private');os.mkdir(leaf,0o700,dir_fd=parentfd);outfd=os.open(leaf,DIR_FLAGS,dir_fd=parentfd)
 try:
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   require(z.testzip() is None,'ZIP CRC failure');index=json.loads(z.read('RESTORE-INDEX.json'));sizes=validate_index(index,z.namelist())
   for info in z.infolist():require(stat.S_IFMT(info.external_attr>>16)==stat.S_IFREG and info.flag_bits&1==0,'Unexpected ZIP member type or encryption')
   for h,n in sizes.items():
    b=z.read('blobs/'+h);require(len(b)==n and sha(b)==h,'Blob integrity mismatch')
   for row in sorted(index['directories'],key=lambda r:(len(r['path'].split('/')),r['path'])):
    fd,name=parent_fd(outfd,row['path'])
    try:os.mkdir(name,0o700,dir_fd=fd)
    finally:os.close(fd)
   for row in index['files']:
    b=z.read(row['member']);require(sha(b)==row['sha256'] and len(b)==row['bytes'],'Restore member differs');secure_write(outfd,row['path'],b)
   for row in index['files']:
    b=read_regular_path(outfd,row['path']);require(len(b)==row['bytes'] and sha(b)==row['sha256'],'Actual restored bytes differ')
   actual,links,dirs,_=snapshot_fd(outfd,private=True);require(not links and {(r['path'],r['bytes'],r['sha256']) for r in actual}=={(r['path'],r['bytes'],r['sha256']) for r in index['files']},'Restored member set differs');require({r['path'] for r in dirs}=={r['path'] for r in index['directories']},'Restored directory set differs');check_binding(parentfd,leaf,outfd)
  return index
 finally:os.close(outfd)

def restore(archive,out,expected_sha):
 # Hash and decode the very same immutable bytes, never reopen a checked ZIP.
 raw=read_regular_absolute(archive);require(sha(raw)==expected_sha,'ZIP hash differs');out=absolute(out);parentfd=open_directory(out.parent,create=True)
 try:
  result=restore_bytes(raw,parentfd,out.name,expected_sha);check_absolute_binding(out.parent,parentfd);return result
 finally:os.close(parentfd)

def package(root,out):
 root=absolute(root);out=absolute(out);require(out.parent==root,'Fresh immediate-child checkpoint required');rootfd=open_directory(root)
 try:
  require(not exists_at(rootfd,out.name),'Fresh immediate-child checkpoint required');os.mkdir(out.name,0o700,dir_fd=rootfd);outfd=os.open(out.name,DIR_FLAGS,dir_fd=rootfd)
  try:
   files,links,dirs,blobs=snapshot_fd(rootfd,out.name);index={'format':'aeust-independent-final-private-dedup-v1','complete':True,'files':files,'symlink_descriptors':links,'directories':dirs,'regular_file_count':len(files),'regular_file_bytes':sum(r['bytes'] for r in files),'unique_blob_count':len(blobs),'symlink_descriptor_count':len(links),'self_reference_excluded_subtree':out.name,'scope':'Full original independent task-root regular payload snapshot, including frozen author handoff, all private original controls, failures, sources and science. Equal-content blobs stored once. Intentional symlinks preserved as descriptors only. This private restore package grants no public sharing or geometry verdict.'};ib=encode(index);archive='aeust-independent-final-private-v15.zip'
   def info(name):
    i=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16;return i
   archivefd=os.open(archive,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=outfd)
   with os.fdopen(archivefd,'wb') as stream,zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    z.writestr(info('RESTORE-INDEX.json'),ib)
    for h,name in sorted(blobs.items()):
     b=read_regular_path(rootfd,name);require(sha(b)==h,'Source changed during checkpoint');z.writestr(info('blobs/'+h),b)
   raw=read_regular_path(outfd,archive);h=sha(raw);restored=restore_bytes(raw,outfd,'restored',h);require(encode(restored)==ib,'Restored index differs');after,afterlinks,afterdirs,_=snapshot_fd(rootfd,out.name);require(after==files and afterlinks==links and afterdirs==dirs,'Original source member set/bytes changed during checkpoint');secure_write(outfd,'RESTORE-INDEX.json',ib)
   report={'passed':True,'zip_file':archive,'zip_sha256':h,'zip_bytes':len(raw),'index_sha256':sha(ib),'regular_file_count':len(files),'regular_file_bytes':index['regular_file_bytes'],'unique_blob_count':len(blobs),'symlink_descriptor_count':len(links),'all_zip_crc_verified':True,'all_blobs_and_references_verified':True,'all_original_regular_paths_actually_restored_byte_identically':True,'all_original_sources_unchanged':True,'no_symlink_followed_or_materialized':True,'restored_tree_owner_only_verified':True,'source_sha256':sha(read_regular_absolute(__file__)),'scope':'Private exact restoration only; not a public allowlist.'};require(read_regular_path(outfd,archive)==raw,'Final archive changed');check_binding(rootfd,out.name,outfd);check_absolute_binding(root,rootfd);secure_write(outfd,'CHECKPOINT-VERIFIED.json',encode(report));return report
  finally:os.close(outfd)
 finally:os.close(rootfd)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--public-verification-normal',type=Path,required=True);ap.add_argument('--public-verification-optimized',type=Path,required=True);a=ap.parse_args();require(len(os.sched_getaffinity(0))==1,'Single CPU required');root=absolute(a.root);require(json.loads(read_regular_absolute(root/'postflight-v15-r1/postflight-summary.json'))['passed'] is True,'Final independent postflight required')
 for p in [a.public_verification_normal,a.public_verification_optimized]:require(absolute(p).is_relative_to(root) and json.loads(read_regular_absolute(p))['passed'] is True,'Completed public verification required')
 print(json.dumps(package(root,a.out)))
if __name__=='__main__':main()
