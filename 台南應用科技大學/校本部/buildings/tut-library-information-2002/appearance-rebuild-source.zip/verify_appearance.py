from pathlib import Path
import json,numpy as np,zipfile,xml.etree.ElementTree as ET,subprocess,hashlib
R=Path(__file__).resolve().parent;O=R/'payload/台南應用科技大學/校本部/buildings/tut-library-information-2002';d=json.loads((O/'appearance-mesh.json').read_text());V=np.array(d['vertices']);F=np.array(d['faces']);M=np.array(d['material_indices']);ns={'m':'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'}
with zipfile.ZipFile(O/'appearance.3mf') as z:e=ET.fromstring(z.read('3D/3dmodel.model'))
v=np.array([[float(t.get(k)) for k in ['x','y','z']] for t in e.findall('.//m:vertex',ns)]);f=np.array([[int(t.get(k)) for k in ['v1','v2','v3']] for t in e.findall('.//m:triangle',ns)]);m=np.array([int(t.get('p1')) for t in e.findall('.//m:triangle',ns)])
assert np.array_equal(v,V) and np.array_equal(f,F) and np.array_equal(m,M)
expr="import bpy,json;from pathlib import Path;o=[x for x in bpy.context.scene.objects if x.type=='MESH'];assert len(o)==1;o=o[0];Path("+repr(str(R/'blend-readback.json'))+").write_text(json.dumps({'vertices':[list(v.co) for v in o.data.vertices],'faces':[list(p.vertices) for p in o.data.polygons],'mats':[p.material_index for p in o.data.polygons],'parents':[x.value for x in o.data.attributes['source_stl_triangle'].data]}))"
subprocess.run(['blender','-b',str(O/'appearance.blend'),'-t','2','--python-expr',expr],check=True,capture_output=True)
b=json.loads((R/'blend-readback.json').read_text());delta=np.max(abs(np.array(b['vertices'])-V));assert delta<4e-6 and np.array_equal(b['faces'],F) and np.array_equal(b['mats'],M) and b['parents']==d['source_triangle']
report={'three_mf_mesh_and_materials_exact':True,'blend_faces_materials_and_provenance_exact':True,'blend_float32_max_coordinate_error_mm':float(delta),'slicer_test_performed':False,'physical_print_test_performed':False}
(O/'appearance-roundtrip-qa.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
