"""Pure synthetic controls for the exact final-inventory generator.

Prepared for scheduled normal/-O execution. No model geometry, Blender or real
final inventory is used. Tiny duplicate controls build only synthetic archives.
Synthetic profile manifests exercise binding/coverage, not a decoder execution.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import os
import stat
import subprocess
import sys
import types

HERE = Path(__file__).resolve().parent
Q = HERE.parent
GENERATOR_SHA = '60633de97fbb0e39e565b44e94cc6f8174eb81405eca6ba246ff4fc11695d786'
SCANNER_SHA = '1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c'
SCANNER_TEST_SHA = 'ae4009249fa4acb6187221ff3dbe481b169be28f63545cf8dbfa1c6b3ae1200a'
PUBLIC_SHA = '75f1604d4f67e87906325c7394d39b96fad98e1c44ca59db862307b4a35b935a'
EXPECTED_CASE_COUNT = 45


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encoded(value))
    return path


def load(path, expected, name):
    data = path.read_bytes()
    require(sha(data) == expected, 'Unexpected exact source: ' + path.name)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__package__ = ''
    sys.modules[name] = module
    exec(compile(data, str(path), 'exec'), module.__dict__)
    return module


def expect_error(call, needle):
    try:
        call()
    except (ValueError, RuntimeError, OSError) as error:
        require(needle in str(error), 'Wrong rejection: ' + str(error))
        return {'rejected': True, 'expected_error': needle, 'actual_error_sha256': sha(str(error).encode()),
                '_private_error_text': str(error),
                'error_type': type(error).__name__}
    raise RuntimeError('Expected rejection was accepted: ' + needle)


class Fixture:
    def __init__(self, harness, name):
        self.h = harness
        self.g = harness.g
        self.root = harness.out / name
        self.payload = self.root / 'payload'
        self.evidence = self.root / 'evidence'
        self.out = self.root / 'generated'
        for path in (self.payload, self.evidence, self.out):
            path.mkdir(parents=True, exist_ok=False)
        self.raw = self.payload / 'raw.txt'
        self.raw.write_bytes(b'synthetic ordinary control payload\n')
        self.plan = {'schema': 'aeust-final-inventory-plan-v1', 'ready_for_terminal_inventory': True,
                     'model_go': False, 'inventory_scopes': ['fixture/payload'],
                     'logical_alias_prefixes': {}, 'baseline_inventories': [], 'seed_selections': [],
                     'malformed_allowlists': [], 'negative_archive_allowlists': [], 'privacy_allowlists': [],
                     'reviewed_private_omissions': [], 'reviewed_blend_profile_exclusions': [],
                     'private_scope_rules': [], 'deferred_direct_sources': [], 'replay_required_sources': [],
                     'archive_mapping_rules': [{'source_prefix': 'fixture', 'archive_prefix': 'observed-fixture'}]}
        self.plan['direct_path_contract'] = self.ref(write(self.evidence / 'direct.json', {'files': []}))
        gate = self.ref(write(self.evidence / 'terminal.json', {'passed': True, 'synthetic_only': True}))
        self.plan['terminal_requirements'] = [{'reference': gate, 'assertions': [{'pointer': '/passed', 'equals': True}]}]
        self.profiles = None

    def logical(self, path):
        return 'fixture/' + path.relative_to(self.root).as_posix()

    def ref(self, path):
        data = path.read_bytes()
        return {'source_relative_path': self.logical(path), 'bytes': len(data), 'sha256': sha(data)}

    def context(self, stage='finalize', roots=None):
        names = self.g.OUTPUT_NAMES[:2] if stage == 'roster' else self.g.OUTPUT_NAMES[2:]
        return self.g.Context(roots or {'fixture': self.root}, self.plan, self.out, names)

    def roster(self):
        result = self.g.roster(self.context('roster'))
        self.plan['source_roster'] = self.ref(self.out / 'private-source-roster-FINAL.json')
        self.plan['blend_candidate_roster'] = self.ref(self.out / 'blend-candidates-FINAL.json')
        return result

    def finish(self):
        return self.g.finalize(self.context(), HERE / 'package_controls_v2.py', SCANNER_SHA,
                               self.h.public, self.h.public_sha,
                               self.ref(self.profiles) if self.profiles else None)

    def findings(self):
        return json.loads((self.out / 'private-inventory-findings-FINAL.json').read_text())

    def positive(self):
        result = self.finish()
        require(result['passed'] is True and result['model_go'] is False, 'Tiny synthetic selection did not pass')
        require(not (self.out / 'controls.tar.xz').exists(), 'Inventory generator created an archive')
        return result

    def hold(self, needle):
        result = self.finish()
        findings = self.findings()
        require(result['passed'] is False and result['hold_count'] > 0 and needle in json.dumps(findings),
                'Expected exact HOLD was absent: ' + needle)
        omissions = json.loads((self.out / 'private-omissions-FINAL.json').read_text())
        require(omissions['ready_for_final_assembly'] is False, 'HOLD produced ready omissions')
        return {'expected_hold': needle, **result}


class Harness:
    def __init__(self, args):
        self.out = args.out.resolve()
        require(self.out.is_relative_to(HERE) and not self.out.exists(), 'Fresh test output inside archive preparation required')
        self.out.mkdir(parents=True, mode=0o700)
        self.generator = args.generator.resolve()
        self.public = args.public_helper.resolve()
        self.public_sha = args.public_helper_sha256
        self.g = load(self.generator, GENERATOR_SHA, 'controlled_final_generator')
        self.scanner = load(HERE / 'package_controls_v2.py', SCANNER_SHA, 'controlled_v2_scanner')
        self.scanner_test = load(HERE / 'test_package_controls_v2.py', SCANNER_TEST_SHA, 'controlled_v2_fixture_helper')
        require(sha(self.public.read_bytes()) == self.public_sha, 'Public helper source differs')
        self.tools = [self.generator, self.public, HERE / 'package_controls_v2.py',
                      HERE / 'test_package_controls_v2.py', Path(__file__),
                      Q / 'tooling/tools/archive_verify.py', Q / 'tooling/tools/build_controls_archive.py',
                      Q / 'independent-tools/audit_control_blend_sdna.py', Q / 'independent-tools/profile_control_blends.py']
        self.original = {str(path): sha(path.read_bytes()) for path in self.tools}
        self.rows = []

    def case(self, name, fn):
        f = Fixture(self, name)
        details = fn(f)
        if isinstance(details, dict) and '_private_error_text' in details:
            raw = details.pop('_private_error_text').encode()
            (f.root / 'negative-error.stderr.txt').write_bytes(raw)
            require(sha(raw) == details['actual_error_sha256'], 'Private negative diagnostic identity differs')
            details['private_diagnostic_path'] = 'negative-error.stderr.txt'
        row = {'name': name, 'passed': True, 'details': details or {}}
        write(f.root / 'control-result.json', row)
        self.rows.append(row)

    def cli(self, command, root, timeout=30):
        env = dict(os.environ)
        env.pop('PYTHONOPTIMIZE', None)
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        cp = subprocess.run([sys.executable, '-B', *(['-O'] if sys.flags.optimize else []), *command],
                            capture_output=True, text=True, env=env, timeout=timeout)
        (root / 'stdout.txt').write_text(cp.stdout)
        (root / 'stderr.txt').write_text(cp.stderr)
        return cp


def roster_cli(f):
    plan = write(f.evidence / 'plan.json', f.plan)
    cp = f.h.cli([str(f.h.generator), 'roster', '--plan', str(plan), '--root', 'fixture=' + str(f.root),
                  '--out', str(f.out)], f.root)
    require(cp.returncode == 0, 'Roster CLI failed: ' + cp.stderr)
    report = json.loads((f.out / 'private-source-roster-FINAL.json').read_text())
    require(report['regular_file_count'] == 1 and report['files'][0] == {'type': 'regular', **f.ref(f.raw)},
            'Roster CLI raw identity differs')
    return {'returncode': cp.returncode, 'regular_file_count': 1}


def canonical_overlap(f):
    frozen = f.payload / 'frozen'
    frozen.mkdir(); (frozen / 'one.bin').write_bytes(b'exact frozen bytes')
    f.plan['inventory_scopes'] = ['fixture/payload', 'author']
    f.plan['logical_alias_prefixes'] = {'fixture/payload/frozen': 'author'}
    c = f.context('roster', {'fixture': f.root, 'author': frozen})
    rows = c.walk()
    require(set(rows) == {'fixture/payload/raw.txt', 'author/one.bin'}, 'Canonical overlap duplicated a physical file')
    return {'canonical_paths': sorted(rows)}


def stage_metadata(f):
    f.plan['inventory_scopes'] = ['fixture']
    f.roster()
    rows = f.context().walk()
    require(f.logical(f.out / 'private-source-roster-FINAL.json') in rows
            and f.logical(f.out / 'blend-candidates-FINAL.json') in rows, 'Finalize omitted completed roster metadata')
    require(f.logical(f.out / 'controls-selection-FINAL.json') in f.context().excluded,
            'Current-stage self metadata not excluded')
    return {'prior_stage_metadata_included': True, 'current_stage_self_hash_excluded': True}


def historical_bytecode(f, retained):
    old = f.payload / 'negative.pyc'; old.write_bytes(b'intentional old bytecode fixture')
    old_ref = f.ref(old)
    baseline = {'files': [{'type': 'regular', 'disposition': 'omit_verifiable_log_or_cache', **old_ref}]}
    f.plan['baseline_inventories'] = [f.ref(write(f.evidence / 'baseline.json', baseline))]
    f.roster()
    old.write_bytes(b'new synthetic replacement')
    if retained:
        (f.payload / 'preserved-original.pyc').write_bytes(b'intentional old bytecode fixture')
    versions, missing = f.g.original_version_accounting(f.context(), f.context().walk())
    require(bool(missing) is (not retained), 'Historical bytecode was silently waived or lost its retained version')
    return {'missing_versions': missing, 'original_version_retained': retained, 'version_count': len(versions)}


def source_mutation(f):
    c = f.context(); before = c.walk(); f.raw.write_bytes(b'intentional source mutation')
    changed = c.unchanged(before)
    require(changed == [f.logical(f.raw)], 'Source mutation was not detected exactly')
    return {'changed_paths': changed}


def nofollow(f, ancestor):
    if ancestor:
        alias = f.root / 'linked-parent'; alias.symlink_to(f.payload, target_is_directory=True)
        target = alias / f.raw.name
    else:
        target = f.payload / 'leaf-link'; target.symlink_to(f.raw)
    return expect_error(lambda: f.g.descriptor(target), 'Too many levels' if not ancestor else 'Not a directory')


def fifo(f):
    target = f.payload / 'synthetic.fifo'; os.mkfifo(target)
    info = target.lstat()
    try:
        cp = f.h.cli([str(Path(__file__).resolve()), '--generator', str(f.h.generator), '--probe-read', str(target)],
                     f.root, timeout=5)
        require(cp.returncode != 0 and 'Nonregular file descriptor input' in cp.stderr,
                'FIFO was not promptly rejected as nonregular')
    finally:
        write(f.evidence / 'fifo-descriptor.json', {'type': 'FIFO', 'mode': info.st_mode,
              'path': 'payload/synthetic.fifo', 'payload_bytes': None, 'materialized_after_control': False})
        target.unlink()
    return {'nonblocking_rejection': True, 'returncode': cp.returncode, 'live_endpoint_removed': True}


def link_descriptor(f):
    link = f.payload / 'link'; link.symlink_to('missing-relative-fixture')
    rows = f.context().walk(); row = rows[f.logical(link)]
    require(row == {'source_relative_path': f.logical(link), 'type': 'symlink',
                    'target_descriptor_sha256': sha(b'missing-relative-fixture')}, 'Link descriptor differs or was followed')
    return row


def exclusion(f, change=None):
    blend = f.payload / 'intentional-unclassified.blend'; blend.write_bytes(b'synthetic malformed SDNA fixture')
    generator = f.evidence / 'test-source.py'; generator.write_bytes(b'# synthetic exclusion test generator\n')
    tested = f.evidence / 'batch-source.py'; tested.write_bytes(b'# synthetic tested batch source\n')
    case = {'name': 'unclassified_decoder_error_is_not_policy_success', 'passed': True,
            'expected_accept': False, 'accepted': False, 'returncode': 1,
            'fixture_sha256': f.ref(blend)['sha256'], 'expected_error': 'Unclassified decoder/infrastructure failure'}
    result = {'passed': True, 'optimization_level': 0, 'test_source_sha256': f.ref(generator)['sha256'],
              'source_sha256': f.ref(tested)['sha256'], 'cases': [case]}
    result_path = write(f.evidence / 'negative-result.json', result)
    row = {**f.ref(blend), 'approved': True, 'category': 'private_control_fixture',
           'reason': 'Synthetic exact negative fixture approved for exclusion binding controls only.',
           'proof': {'kind': 'unclassified_sdna_negative_control', 'generator_source': f.ref(generator),
                     'tested_source': f.ref(tested), 'result_proofs': [{'reference': f.ref(result_path), 'optimization_level': 0}]}}
    if change:
        change(row, result, generator)
        if change.__name__ != 'mutate_result_bytes':
            write(result_path, result)
            row['proof']['result_proofs'][0]['reference'] = f.ref(result_path)
    manifest = write(f.evidence / 'exclusions.json', {'files': [row]})
    f.plan['reviewed_blend_profile_exclusions'] = [f.ref(manifest)]
    if change and change.__name__ == 'mutate_result_bytes':
        result_path.write_bytes(result_path.read_bytes() + b' ')
    return row, blend


def exclusion_positive(f):
    row, blend = exclusion(f)
    r = f.roster(); doc = json.loads((f.out / 'blend-candidates-FINAL.json').read_text())
    require(r['excluded_blend_candidate_count'] == 1 and not doc['blend_candidates']
            and doc['files'][0]['sha256'] == row['sha256'] and doc['excluded_blend_candidates'] == [row],
            'Approved exclusion lost original payload or entered decoder worklist')
    return {'all_original_blend_count': 1, 'excluded_count': 1}


def exclusion_negative(f, change, needle):
    exclusion(f, change)
    return expect_error(lambda: f.g.blend_exclusions(f.context(), f.context().walk()), needle)


def profile_fixture(f, mutate=None):
    data, allowance = f.h.scanner_test.synthetic_blend_defaults()
    blend = f.payload / 'state.blend'; blend.write_bytes(data)
    allowance['source_relative_path'] = f.logical(blend)
    f.roster()
    directory = f.payload / 'profiles'; directory.mkdir()
    (directory / '00000-original.blend').write_bytes(data)
    diagnostics = []
    for mode, opt in [('normal', 0), ('optimized', 1)]:
        result = write(directory / ('00000-' + mode + '.json'), {'synthetic_only': True, 'optimization_level': opt})
        stdout = directory / ('00000-' + mode + '.stdout.txt'); stdout.write_bytes(b'')
        stderr = directory / ('00000-' + mode + '.stderr.txt'); stderr.write_bytes(b'')
        diagnostics.append({'mode': mode, 'returncode': 0, 'stdout_sha256': sha(stdout.read_bytes()),
                            'stderr_sha256': sha(stderr.read_bytes()), 'result_sha256': sha(result.read_bytes())})
    decoder = f.evidence / 'decoder.py'; decoder.write_bytes((Q / 'independent-tools/audit_control_blend_sdna.py').read_bytes())
    batch = f.evidence / 'batch.py'; batch.write_bytes((Q / 'independent-tools/profile_control_blends.py').read_bytes())
    f.plan['blend_decoder_source'] = f.ref(decoder); f.plan['blend_batch_source'] = f.ref(batch)
    allowance['independent_diagnostic_bindings'] = diagnostics
    report = {'passed': True, 'model_go': False, 'candidate_count': 1, 'files': [allowance], 'rejected': [],
              'roster_sha256': f.plan['blend_candidate_roster']['sha256'],
              'decoder_source_sha256': f.ref(decoder)['sha256'], 'batch_source_sha256': f.ref(batch)['sha256'],
              'all_source_bytes_unchanged': True, 'both_mode_profile_equivalence_verified': True,
              'synthetic_binding_control_only': True}
    if mutate:
        mutate(report)
    f.profiles = write(directory / 'blend-profiles.json', report)
    return report


def duplicate_fixture(f, kind='regular_identity_duplicate', mutate=None, excluded_dependency=None):
    selected_input = {**f.ref(f.raw), 'archive_path': 'raw.txt', 'transformation': 'identity'}
    selection_path = write(f.payload / 'original-selection.json', {'passed': True, 'model_go': False, 'files': [selected_input]})
    package_out = f.root / 'tiny-package'
    report = f.h.scanner.package(selection_path, package_out, Q / 'tooling', {'fixture': f.root})
    verifier = f.h.scanner.load_tool(Q / 'tooling/tools/archive_verify.py', 'tiny_duplicate_verifier',
                                    sha((Q / 'tooling/tools/archive_verify.py').read_bytes()))
    _, tarbytes, records = verifier.verify(package_out / 'controls.tar.xz', package_out / 'controls-index.json')
    scope = next(tarbytes[start:end] for path, start, end in records if path == 'ARCHIVE-SCOPE.json')
    scope_path = f.payload / 'retained-scope.json'; scope_path.write_bytes(scope)
    index_path = f.payload / 'original-index.json'; index_path.write_bytes((package_out / 'controls-index.json').read_bytes())
    result_path = f.payload / 'original-packaging-result.json'; result_path.write_bytes((package_out / 'packaging-result.json').read_bytes())
    generator = f.payload / 'generator.py'; generator.write_bytes((HERE / 'package_controls_v2.py').read_bytes())
    verify_source = f.payload / 'archive_verify.py'; verify_source.write_bytes((Q / 'tooling/tools/archive_verify.py').read_bytes())
    build_source = f.payload / 'build_controls_archive.py'; build_source.write_bytes((Q / 'tooling/tools/build_controls_archive.py').read_bytes())
    f.plan['archive_verifier_source'] = f.ref(verify_source); f.plan['archive_builder_source'] = f.ref(build_source)
    target = f.payload / ('duplicate.tar.xz' if kind == 'strict_archive_identity_duplicate' else 'duplicate.txt')
    target.write_bytes((package_out / 'controls.tar.xz').read_bytes() if kind == 'strict_archive_identity_duplicate' else f.raw.read_bytes())
    members = []
    for entry in json.loads(index_path.read_text())['members']:
        source = scope_path if entry['path'] == 'ARCHIVE-SCOPE.json' else f.raw
        m = {'path': entry['path'], **f.ref(source)}
        if entry['path'] == 'raw.txt':
            m['reported_source_relative_path'] = f.logical(f.raw)
        members.append(m)
    proof = {'kind': kind, 'raw_inputs': [f.ref(f.raw)], 'generator_source': f.ref(generator),
             'selection_input': f.ref(selection_path), 'archive_index': f.ref(index_path),
             'result_proofs': [{'schema': 'package_controls_v2_result', 'reference': f.ref(result_path)}],
             'member_bindings': members, 'reproduction_member_path': 'raw.txt'}
    row = {**f.ref(target), 'category': 'duplicate_reproduction_or_scratch',
           'reason': 'Exact synthetic reproduction with original raw inputs, controlled source, report and all-member closure retained.',
           'duplicate_proof': proof}
    dependencies = {'generator': generator, 'index': index_path, 'verifier': verify_source,
                    'builder': build_source, 'member': scope_path, 'selection': selection_path}
    if mutate:
        mutate(proof, report)
        write(result_path, report)
        proof['result_proofs'][0]['reference'] = f.ref(result_path)
    if excluded_dependency:
        omitted = dependencies[excluded_dependency]
        require(omitted.is_file(), 'Negative dependency fixture must remain readable')
        f.plan['inventory_scopes'] = [f.logical(path) for path in sorted(f.payload.iterdir()) if path != omitted]
    manifest = write(f.evidence / 'reviewed-duplicates.json', {'files': [row]})
    f.plan['reviewed_private_omissions'] = [f.ref(manifest)]
    f.roster()
    return target


def main():
    os.umask(0o077)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path)
    ap.add_argument('--generator', type=Path, default=HERE / 'generate_final_inventory.py')
    ap.add_argument('--public-helper', type=Path, default=Q / 'public-preparation/public_bundle_common_v15.py')
    ap.add_argument('--public-helper-sha256', default=PUBLIC_SHA)
    ap.add_argument('--probe-read', type=Path)
    args = ap.parse_args()
    if args.probe_read:
        g = load(args.generator, GENERATOR_SHA, 'fifo_probe_generator')
        g.descriptor(args.probe_read)
        raise RuntimeError('Unexpected nonregular probe acceptance')
    require(args.out is not None, '--out required')
    h = Harness(args)
    h.case('roster_cli_exact_positive', roster_cli)
    h.case('canonical_overlapping_frozen_root', canonical_overlap)
    h.case('stage_specific_metadata_accounting', stage_metadata)
    h.case('missing_historical_bytecode_is_not_waived', lambda f: historical_bytecode(f, False))
    h.case('historical_bytecode_retained_at_new_exact_path', lambda f: historical_bytecode(f, True))
    h.case('source_mutation_is_detected', source_mutation)
    h.case('ancestor_symlink_is_rejected', lambda f: nofollow(f, True))
    h.case('leaf_symlink_is_rejected', lambda f: nofollow(f, False))
    h.case('fifo_is_nonblocking_and_descriptor_only', fifo)
    h.case('symlink_descriptor_is_never_followed', link_descriptor)
    h.case('duplicate_json_key_rejected', lambda f: expect_error(lambda: h.g.parse(b'{"x":1,"x":2}'), 'Duplicate JSON object key'))
    h.case('nonfinite_json_overflow_rejected', lambda f: expect_error(lambda: h.g.parse(b'{"x":1e999}'), 'Nonfinite JSON float'))
    h.case('exact_helper_hash_required', lambda f: expect_error(lambda: h.g.loaded_source(h.generator, '0' * 64, 'bad_helper'), 'Helper source SHA256 differs'))
    def failed_terminal(f):
        path = write(f.evidence / 'terminal.json', {'passed': False})
        f.plan['terminal_requirements'][0]['reference'] = f.ref(path)
        return expect_error(lambda: f.g.terminal_gates(f.context()), 'Terminal assertion failed')
    h.case('failed_terminal_gate_rejected', failed_terminal)
    h.case('approved_exact_blend_exclusion', exclusion_positive)
    h.case('unapproved_blend_exclusion_rejected', lambda f: exclusion_negative(f, lambda r,d,p: r.update(approved=False), 'Explicit per-file private Blend exclusion approval required'))
    h.case('changed_blend_exclusion_raw_hash_rejected', lambda f: exclusion_negative(f, lambda r,d,p: r.update(sha256='0'*64), 'Excluded Blend identity differs'))
    def mutate_result_bytes(row, report, generator):
        pass
    h.case('mutated_exclusion_result_raw_bytes_rejected', lambda f: exclusion_negative(f, mutate_result_bytes, 'Referenced source identity differs'))
    h.case('wrong_exclusion_generator_result_binding_rejected', lambda f: exclusion_negative(f, lambda r,d,p: d.update(test_source_sha256='0'*64), 'negative-result source/mode binding differs'))
    h.case('accepted_exclusion_case_rejected', lambda f: exclusion_negative(f, lambda r,d,p: d['cases'][0].update(accepted=True), 'exact intended fail-closed rejection'))
    h.case('unrelated_exclusion_error_rejected', lambda f: exclusion_negative(f, lambda r,d,p: d['cases'][0].update(expected_error='unrelated error'), 'exact intended fail-closed rejection'))
    h.case('changed_exclusion_source_bytes_rejected', lambda f: exclusion_negative(f, lambda r,d,p: p.write_bytes(b'changed generator'), 'Referenced source identity differs'))
    def tiny_positive(f):
        f.roster(); return f.positive()
    h.case('tiny_synthetic_finalize_positive', tiny_positive)
    def tiny_cli_positive(f):
        f.roster()
        plan = write(f.evidence / 'final-plan.json', f.plan)
        cp = h.cli([str(h.generator), 'finalize', '--plan', str(plan),
                    '--root', 'fixture=' + str(f.root), '--out', str(f.out),
                    '--scanner', str(HERE / 'package_controls_v2.py'), '--scanner-sha256', SCANNER_SHA,
                    '--public-helper', str(h.public), '--public-helper-sha256', h.public_sha], f.root)
        require(cp.returncode == 0, 'Tiny finalize CLI failed: ' + cp.stderr)
        result = json.loads((f.out / 'final-inventory-generation-result.json').read_text())
        require(result['passed'] is True and result['model_go'] is False and result['archive_created'] is False,
                'Tiny finalize CLI semantics differ')
        return {'returncode': 0, 'synthetic_selection_passed': True, 'model_go': False}
    h.case('tiny_synthetic_finalize_cli_positive', tiny_cli_positive)
    def unknown_malformed(f):
        (f.payload / 'unknown.xz').write_bytes(b'not a valid compressed stream')
        f.roster(); return f.hold('Unapproved malformed compressed payload')
    h.case('unknown_malformed_payload_keeps_hold', unknown_malformed)
    def private_marker(f):
        p = f.payload / 'private-reference.txt'; p.write_bytes(b'/' + b'workspace/private-synthetic-reference')
        f.roster(); result = f.positive()
        omitted = json.loads((f.out / 'private-omissions-FINAL.json').read_text())['files']
        require(len(omitted) == 1 and all(omitted[0][k] == f.ref(p)[k] for k in ('source_relative_path','bytes','sha256')), 'Private omission did not bind exact original')
        return result
    h.case('private_marker_gets_exact_original_omission', private_marker)
    def unprofiled(f):
        (f.payload / 'missing-profile.blend').write_bytes(b'intentional unprofiled synthetic blend')
        f.roster(); return f.hold('Missing exact accepted/rejected Blend profile')
    h.case('unprofiled_blend_keeps_hold', unprofiled)
    def profile_positive(f):
        profile_fixture(f); return f.positive()
    h.case('synthetic_two_mode_profile_binding_positive', profile_positive)
    def bad_profile(f, mutation, needle):
        profile_fixture(f, mutation); return expect_error(f.finish, needle)
    h.case('profile_missing_optimized_diagnostic_rejected', lambda f: bad_profile(f, lambda r: r['files'][0]['independent_diagnostic_bindings'].pop(), 'Blend two-mode diagnostics differ'))
    h.case('profile_missing_candidate_coverage_rejected', lambda f: bad_profile(f, lambda r: r.update(files=[]), 'accepted/rejected coverage differs'))
    h.case('profile_mutated_raw_diagnostic_hash_rejected', lambda f: bad_profile(f, lambda r: r['files'][0]['independent_diagnostic_bindings'][0].update(stdout_sha256='0'*64), 'Blend raw diagnostic missing or changed'))
    h.case('profile_wrong_batch_source_hash_rejected', lambda f: bad_profile(f, lambda r: r.update(batch_source_sha256='0'*64), 'Blend batch tool binding differs'))
    h.case('profile_candidate_raw_identity_rejected', lambda f: bad_profile(f, lambda r: r['files'][0].update(sha256='0'*64), 'Blend outcome identity differs'))
    def duplicate_positive(f, kind):
        duplicate_fixture(f, kind); return f.positive()
    h.case('exact_regular_duplicate_generation_proof_positive', lambda f: duplicate_positive(f, 'regular_identity_duplicate'))
    h.case('exact_archive_duplicate_all_member_proof_positive', lambda f: duplicate_positive(f, 'strict_archive_identity_duplicate'))
    def duplicate_bad(f, mutation, needle):
        duplicate_fixture(f, mutate=mutation); return f.hold(needle)
    h.case('unrelated_passing_duplicate_report_keeps_hold', lambda f: duplicate_bad(f, lambda p,r: (r.clear(), r.update(passed=True)), 'Unbound or unsupported duplicate generation report'))
    def dependency_absent(f, name):
        duplicate_fixture(f, excluded_dependency=name)
        return expect_error(f.finish, 'Referenced required file absent from final roster')
    for dependency in ('generator', 'index', 'verifier', 'builder', 'member', 'selection'):
        h.case('readable_duplicate_' + dependency + '_outside_selection_rejected', lambda f, d=dependency: dependency_absent(f, d))
    h.case('duplicate_missing_tracked_binding_keeps_hold', lambda f: duplicate_bad(f, lambda p,r: r.update(proof_and_source_bindings=[]), 'unbound tracked dependencies'))
    h.case('duplicate_wrong_member_binding_keeps_hold', lambda f: duplicate_bad(f, lambda p,r: p['member_bindings'][0].update(sha256='0'*64), 'Duplicate all-member proof differs'))
    h.case('duplicate_wrong_generator_report_hash_keeps_hold', lambda f: duplicate_bad(f, lambda p,r: r.update(source_sha256='0'*64), 'Unbound or unsupported duplicate generation report'))
    require(len(h.rows) == EXPECTED_CASE_COUNT, 'Prepared exact case count differs')
    require(all(sha(Path(path).read_bytes()) == value for path, value in h.original.items()), 'Original generator/helper/tool source changed')
    inventory = []
    for path in sorted(h.out.rglob('*')):
        rel = path.relative_to(h.out).as_posix()
        if path.is_symlink():
            inventory.append({'path': rel, 'type': 'symlink', 'target_descriptor_sha256': sha(os.fsencode(os.readlink(path)))})
        elif path.is_file():
            data = path.read_bytes(); inventory.append({'path': rel, 'type': 'regular', 'bytes': len(data), 'sha256': sha(data)})
        else:
            require(path.is_dir(), 'Live special endpoint survived synthetic controls')
    write(h.out / 'fixture-inventory.json', {'files': inventory, 'all_regular_fixture_payloads_recorded': True,
          'scope': 'Exact test payloads before final result/fixture-inventory metadata. Links are descriptors only.'})
    result = {'passed': True, 'model_go': False, 'optimization_level': sys.flags.optimize,
              'case_count': len(h.rows), 'cases': h.rows, 'source_sha256': GENERATOR_SHA,
              'test_source_sha256': sha(Path(__file__).read_bytes()),
              'public_helper_source_sha256': h.public_sha, 'v2_scanner_source_sha256': SCANNER_SHA,
              'all_original_generator_helper_and_tool_bytes_unchanged': True,
              'fixture_inventory_sha256': sha((h.out / 'fixture-inventory.json').read_bytes()),
              'scope': 'Pure synthetic roster, source identity, privacy/profile binding and tiny archive evidence controls. No final-model inventory, geometry, Blender or real independent decoder execution is claimed.'}
    write(h.out / 'results.json', result)
    print(json.dumps({'passed': True, 'case_count': len(h.rows), 'model_go': False}))


if __name__ == '__main__':
    main()
