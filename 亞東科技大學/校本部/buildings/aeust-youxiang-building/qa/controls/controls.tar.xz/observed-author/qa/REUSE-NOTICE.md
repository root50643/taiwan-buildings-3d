# Generic verification-tool reuse

28 Python/C++ tool sources were freshly copied from the audited HDUT QA tool directories. The fresh upstream and AEUST hashes are in `TOOLING-REUSE-BINDING.json`. 25 files are byte-identical; 3 have only obsolete building names in report/error text changed to generic labels. Exact upstream bytes and diffs for those 3 are in `tool-reuse/`. No thresholds, predicates, control cases, geometry checks, camera checks, or report acceptance rules were relaxed.

No previous building's model, dimensions, result, sample count, exception, waiver, or pass status is reused. These tools do not approve architectural appearance or promise physical printability.

The fixed nine identifiers are `front`, `rear`, `east`, `west`, `south`, `north`, `top`, `courtyard-gallery`, and `courtyard-arcade`. For AEUST, directional-looking identifiers are model/paper-axis camera keys only, not geographic directions. X means paper right, Y means paper up, and Z means vertical. ORTHO/50 mm remains mandatory for the first seven views; PERSP/20 mm remains mandatory for the two courtyard views.

Only synthetic tool controls may run before a final frozen model is available. Final original-STL QA, full source/Blend/nine-PNG verification, final-scene negative controls, and independent architectural review remain separate requirements. The existence of these tools or a successful synthetic control run is not a model pass.
