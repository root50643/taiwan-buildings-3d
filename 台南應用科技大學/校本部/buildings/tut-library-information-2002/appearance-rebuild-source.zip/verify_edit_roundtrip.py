from pathlib import Path
import lib3mf,numpy as np,json,subprocess,trimesh
R=Path(__file__).resolve().parent;O=R/'payload/台南應用科技大學/校本部/buildings/tut-library-information-2002'
def geometry(v,f):
 v=np.array(v);f=np.array(f);area=np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)/2;m=trimesh.Trimesh(v,f,process=False)
 edges,counts=np.unique(np.sort(m.edges,axis=1),axis=0,return_counts=True)
 links=[[] for _ in v]
 for a,b,c in f:
  for t,u,w in [(a,b,c),(b,c,a),(c,a,b)]:links[t].append((int(u),int(w)))
 bad=0
 for pairs in links:
  adj={}
  for u,w in pairs:adj.setdefault(u,set()).add(w);adj.setdefault(w,set()).add(u)
  seen=set();todo=[next(iter(adj))]
  while todo:
   n=todo.pop()
   if n in seen:continue
   seen.add(n);todo.extend(adj[n]-seen)
  bad+=int(any(len(ns)!=2 for ns in adj.values()) or len(seen)!=len(adj))
 q={'bad_vertex_links':bad,'nonmanifold_edges':int(sum(counts!=2)),'duplicate_faces':int(len(f)-len(np.unique(np.sort(f,axis=1),axis=0))),'euler_number':int(m.euler_number),'surface_shells':len(m.split(only_watertight=False)),'triangles':len(f),'vertices':len(v),'zero_area_triangles':int(sum(area==0)),'min_triangle_area_mm2':float(area.min()),'duplicate_vertices':int(len(v)-len(np.unique(v,axis=0))),'watertight':bool(m.is_watertight),'consistent_winding':bool(m.is_winding_consistent)};assert q['bad_vertex_links']==0 and q['nonmanifold_edges']==0 and q['duplicate_faces']==0 and q['surface_shells']==1 and q['zero_area_triangles']==0 and q['duplicate_vertices']==0 and q['watertight'] and q['consistent_winding'];return q
w=lib3mf.Wrapper();m=w.CreateModel();r=m.QueryReader('3mf');r.SetStrictModeActive(True);r.ReadFromFile(str(O/'appearance.3mf'));assert r.GetWarningCount()==0
it=m.GetMeshObjects();assert it.MoveNext();o=it.GetCurrentMeshObject();v=[list(x.Coordinates) for x in o.GetVertices()];f=[list(x.Indices) for x in o.GetTriangleIndices()];qa={'lib3mf_version':w.GetLibraryVersion(),'lib3mf_strict_warnings':0,'lib3mf_object_valid':o.IsValid(),'lib3mf_import':geometry(v,f)}
g=m.GetBaseMaterialGroupByID(1);ids=g.GetAllPropertyIDs();pid=ids[0];color=g.GetDisplayColor(pid);original=color.Red;color.Red=(original+1)%256;g.SetDisplayColor(pid,color);m.QueryWriter('3mf').WriteToFile(str(R/'edited-test.3mf'))
m2=w.CreateModel();r2=m2.QueryReader('3mf');r2.SetStrictModeActive(True);r2.ReadFromFile(str(R/'edited-test.3mf'));i2=m2.GetMeshObjects();i2.MoveNext();o2=i2.GetCurrentMeshObject();v2=[list(x.Coordinates) for x in o2.GetVertices()];f2=[list(x.Indices) for x in o2.GetTriangleIndices()];qa['lib3mf_material_edit_roundtrip']=geometry(v2,f2);qa['lib3mf_edit_geometry_exact']=bool(np.array_equal(v,v2) and np.array_equal(f,f2));g2=m2.GetBaseMaterialGroupByID(1);qa['lib3mf_color_edit_persisted']=g2.GetDisplayColor(g2.GetAllPropertyIDs()[0]).Red==(original+1)%256;qa['lib3mf_edit_max_coordinate_delta_mm']=float(np.max(abs(np.array(v)-np.array(v2))));qa['lib3mf_edit_faces_exact']=bool(np.array_equal(f,f2));qa['lib3mf_writer_decimal_precision']=m.QueryWriter('3mf').GetDecimalPrecision();assert qa['lib3mf_edit_max_coordinate_delta_mm']<8e-6 and qa['lib3mf_edit_faces_exact'] and qa['lib3mf_color_edit_persisted'] and r2.GetWarningCount()==0
expr="import bpy;ob=[o for o in bpy.data.objects if o.type=='MESH'][0];ob.data.materials[0].diffuse_color=(0.1,0.2,0.3,1);bpy.ops.wm.save_as_mainfile(filepath="+repr(str(R/'edited-test.blend'))+")"
subprocess.run(['blender','-b',str(O/'appearance.blend'),'-t','2','--python-expr',expr],check=True,capture_output=True)
expr="import bpy,json;from pathlib import Path;o=[o for o in bpy.data.objects if o.type=='MESH'][0];Path("+repr(str(R/'edited-blend-readback.json'))+").write_text(json.dumps({'vertices':[list(v.co) for v in o.data.vertices],'faces':[list(p.vertices) for p in o.data.polygons],'color':list(o.data.materials[0].diffuse_color)}))"
subprocess.run(['blender','-b',str(R/'edited-test.blend'),'-t','2','--python-expr',expr],check=True,capture_output=True)
b=json.loads((R/'edited-blend-readback.json').read_text());before=json.loads((R/'blend-readback.json').read_text());qa['blender_material_edit_roundtrip']=geometry(b['vertices'],b['faces']);qa['blender_edit_geometry_exact']=b['vertices']==before['vertices'] and b['faces']==before['faces'];qa['blender_color_edit_persisted']=bool(np.allclose(b['color'],[.1,.2,.3,1],atol=1e-7));assert qa['blender_edit_geometry_exact'] and qa['blender_color_edit_persisted']
qa['limitations']='Tiny triangles remain; zero-area and duplicate-vertex checks passed at actual float32 reader precision. No slicer or physical print test.'
(O/'appearance-edit-roundtrip-qa.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa,indent=2))
