#!/usr/bin/env python3
"""Small synthetic parser tests only. Caller owns external shared lock and taskset."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
P=pathlib.Path;QA=P(__file__).resolve().parents[1];PY=QA.parents[1]/'modeling-toolchain/.venv/bin/python'
def sha(p):return hashlib.sha256(P(p).read_bytes()).hexdigest()
BOOT='''import sys,os,json,importlib,unittest,pathlib
p=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(p.parent));m=importlib.import_module(p.stem);s=unittest.defaultTestLoader.loadTestsFromModule(m);r=unittest.TextTestRunner(verbosity=2).run(s)
out.write_text(json.dumps({'passed':r.wasSuccessful(),'optimization_level':sys.flags.optimize,'cpu_affinity':sorted(os.sched_getaffinity(0)),'test_count':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped)},indent=2)+'\\n')
raise SystemExit(0 if r.wasSuccessful() else 1)
'''
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=P,required=True);a=ap.parse_args();a.out=a.out.resolve()
    if a.out.exists() or len(os.sched_getaffinity(0))!=1:raise RuntimeError('Need new output and one-CPU affinity')
    tests={'scene':QA/'scene-control-tools/test_orchestration.py','postflight':QA/'postflight-tools/test_review_bounded_evidence.py','artifacts':QA/'postflight-tools/test_artifact_structure.py'}
    for p in tests.values():
        if not p.is_file():raise RuntimeError('Missing prepared test '+str(p))
    a.out.mkdir(parents=True);launcher=a.out/'launcher.py';launcher.write_text(BOOT)
    source={str(p):sha(p) for d in ('scene-control-tools','postflight-tools','verification','tools','render-tools') for p in sorted((QA/d).glob('*')) if p.suffix in ('.py','.cpp')};rows=[]
    env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
    for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[k]='1'
    for mode,opt in [('normal',0),('optimized',1)]:
        for name,p in tests.items():
            stem=mode+'-'+name;result=a.out/(stem+'.json');command=[str(PY),'-B',*(['-O'] if opt else []),str(launcher),str(p),str(result)]
            with (a.out/(stem+'.stdout')).open('wb') as out,(a.out/(stem+'.stderr')).open('wb') as err:code=subprocess.run(command,stdout=out,stderr=err,env=env).returncode
            r=json.loads(result.read_text()) if result.is_file() else {};okay=type(code) is int and code==0 and r.get('passed') is True and type(r.get('optimization_level')) is int and r['optimization_level']==opt and r.get('cpu_affinity')==sorted(os.sched_getaffinity(0)) and type(r.get('test_count')) is int and r['test_count']>0 and r.get('failures')==r.get('errors')==r.get('skips')==0
            rows.append({'name':name,'mode':mode,'returncode':code,'passed':okay,'result':r,'command':command,'source_sha256':sha(p),'result_sha256':sha(result) if result.exists() else None});print(json.dumps(rows[-1]),flush=True)
    unchanged=all(P(p).is_file() and sha(p)==h for p,h in source.items());okay=all(r['passed'] for r in rows) and unchanged
    report={'passed':okay,'scope':'Synthetic parser/unit controls only. No project geometry recomputation or Blender execution. No model pass.','source_sha256':source,'all_sources_unchanged':unchanged,'executions':rows,'output_inventory':{p.name:sha(p) for p in sorted(a.out.iterdir()) if p.is_file()}}
    (a.out/'parser-controls.json').write_text(json.dumps(report,indent=2)+'\n');return 0 if okay else 1
if __name__=='__main__':raise SystemExit(main())
