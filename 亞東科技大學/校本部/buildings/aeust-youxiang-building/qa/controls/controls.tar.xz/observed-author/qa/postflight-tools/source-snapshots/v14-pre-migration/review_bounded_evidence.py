#!/usr/bin/env python3
"""Author-only v14 bounded recorded-ray review. Never changes producer strict=false.
No geometry is recast. Fresh CSV audit rechecks every recorded original predicate.
Caller MUST hold qa/.heavy.lock and single CPU; this program does not lock.
"""
import argparse, collections, gzip, hashlib, itertools, json, math, os, pathlib, re, sys
P=pathlib.Path; QA=P(__file__).resolve().parents[1]
STL_SHA='46649566e965a049e6e333e9d82b075407c8e926e55c9034f11fbe3dbdf15a5d'
REUSE_SHA='e7bfa693fac9533d68731fb07a43f28a1f89cf923251c19e9538e9ec6b256de2'
FREEZE_SHA='c21b0ee58fb907886b855fe44255c2db2d5600d5b97168324fdf1c64a6f39f53'
FACES=47770; RAYS=477700
DENSE_FALSE={'all_original_ray_intervals_and_controls_valid'}
AGG_FALSE={'all_gates_explicitly_pass','all_gate_check_flags_true','zero_short_or_flagged_dense_samples'}
EXACT_TRUE={'completed','all_selected_rays_exactly_classified','all_selected_first_chords_ge_0p8mm','all_original_inputs_and_sources_unchanged','original_raw_and_exact_intersection_prerequisites_passed','full_original_csv_exact_face_sample_coverage','all_flagged_samples_selected','all_selected_descriptors_match_original_full_csv'}
def require(x,msg):
    if not x:raise RuntimeError(msg)
def integer(x,msg,minimum=0):require(type(x) is int and x>=minimum,msg);return x
def finite(x,msg):require(type(x) in (int,float) and math.isfinite(x),msg);return x
def bools(d,keys,false=frozenset()):
    require(type(d) is dict and set(d)==set(keys),'Missing/extra check key')
    require(all(type(v) is bool and v is (k not in false) for k,v in d.items()),'Non-Boolean or unexpected check failure')
def clean(r):require(type(r) is dict and not {'error','error_type','failure_reason'}.intersection(r),'Error/incomplete report')
def pairs(p):
    d={}
    for k,v in p:require(k not in d,'Duplicate JSON key: '+k);d[k]=v
    return d
def parse(s):return json.loads(s,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(RuntimeError('Nonfinite JSON constant')))
def digest(p):
    with P(p).open('rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def confined(root,name,basename=False):
    require(type(name) is str and name and not P(name).is_absolute(),'Invalid artifact reference')
    require(not basename or P(name).name==name,'Artifact must use basename')
    p=(root/name).resolve();require(root.resolve() in p.parents,'Artifact escapes its directory');require(p.is_file(),'Missing artifact '+str(p));return p
class Evidence:
    def __init__(self):self.files={}
    def track(self,p,expected=None):
        p=P(p).resolve();require(p.is_file(),'Missing evidence '+str(p));h=digest(p)
        if expected is not None:require(type(expected) is str and re.fullmatch('[0-9a-f]{64}',expected) and h==expected,'Evidence hash differs: '+str(p))
        if str(p) in self.files:require(self.files[str(p)]['sha256']==h,'Evidence changed while being read: '+str(p))
        self.files[str(p)]={'bytes':p.stat().st_size,'sha256':h};return p
    def read(self,p,expected=None):return parse(self.track(p,expected).read_text())
    def artifact(self,root,name,h,basename=True):return self.track(confined(root,name,basename),h)
    def gz(self,p):return parse(gzip.decompress(self.track(p).read_bytes()))
    def jsonlines(self,p):
        with gzip.open(self.track(p),'rt') as h:
            for line in h:require(line.strip(),'Blank JSONL record');yield parse(line)
    def unchanged(self):return all(P(p).is_file() and P(p).stat().st_size==r['bytes'] and digest(p)==r['sha256'] for p,r in self.files.items())
def inventory(qa):return {str(p.relative_to(qa)):digest(p) for folder in ('verification','tools') for p in sorted((qa/folder).iterdir()) if p.is_file() and p.suffix in ('.py','.cpp')}
def validate_capture(e,path,kind,mode,stl,output,full,inv):
    import capture_process as cap
    c=e.read(path);clean(c);require(c.get('schema')=='aeust-v14-producer-capture-v1' and c.get('completed') is True,'Missing completed process capture')
    opt=0 if mode=='normal' else 1;expectedexit=1 if kind=='full' else 0
    require(c.get('kind')==kind and c.get('mode')==mode and type(c.get('returncode')) is int and c['returncode']==expectedexit,'Unexpected real producer exit/mode')
    require(c.get('stl_path')==str(stl) and c.get('stl_sha256')==STL_SHA and c.get('producer_output')==str(output),'Capture input/output binding differs')
    require(c.get('tool_sources_before')==inv==c.get('tool_sources_after'),'Capture tool inventory differs')
    require(c.get('capture_source_sha256')==digest(cap.__file__),'Capture code changed')
    bootstrap=e.track(path.parent/'runtime_launcher.py',c['bootstrap_sha256']);require(bootstrap.read_text()==cap.BOOT,'Capture bootstrap differs')
    if kind=='full':
        target=QA/'tools/run_full_qa.py';args=['--stl',str(stl),'--expected-sha256',STL_SHA,'--expected-longest-mm','219','--out',str(output)];report=output/'full-qa-summary.json';require(c.get('full_root') is None,'Unexpected full capture parent')
    else:
        base=full/mode;std=base/'standard';target=QA/'tools/diagnose_recorded_cpp_rays.py';args=['--stl',str(stl),'--expected-sha256',STL_SHA,'--flags',str(std/'dense/dense-flagged-samples.json.gz'),'--dense-report',str(std/'dense/dense-check.json'),'--raw-report',str(std/'raw/raw-mesh-check.json'),'--intersections-report',str(base/'intersections.json'),'--out',str(output)];report=output/'exact-recorded-ray-summary.json';require(c.get('full_root')==str(full),'Exact capture full root differs')
    require(c.get('target')==str(target) and c.get('target_sha256')==digest(target) and c.get('target_arguments')==args,'Capture producer arguments differ')
    runtime=e.read(path.parent/'runtime.json',c['runtime_sha256']);require(runtime==c.get('runtime'),'Runtime ledger differs')
    require(type(runtime.get('optimization_level')) is int and runtime['optimization_level']==opt,'Wrong actual Python mode')
    affinity=c.get('cpu_affinity');require(type(affinity) is list and len(affinity)==1 and type(affinity[0]) is int and affinity[0]>=0 and runtime.get('cpu_affinity')==affinity,'CPU runtime proof missing')
    require(runtime.get('target')==str(target) and runtime.get('target_sha256')==digest(target) and runtime.get('target_arguments')==args,'Runtime producer binding differs')
    require(runtime.get('python_executable')==str(cap.PYTHON),'Wrong Python interpreter')
    command=[str(cap.PYTHON),'-B',*(['-O'] if opt else []),str(bootstrap),str(path.parent/'runtime.json'),str(target),*args]
    require(c.get('command')==command,'Capture command differs')
    require(c.get('report_path')==str(report),'Capture report path differs');e.track(report,c['report_sha256'])
    for name in ('stdout','stderr'):e.track(path.parent/(name+'.txt'),c[name+'_sha256'])
    finite(c.get('started_unix'),'Missing capture start');finite(c.get('finished_unix'),'Missing capture end');require(c['finished_unix']>=c['started_unix'],'Capture timestamps reversed')
    return {'kind':kind,'mode':mode,'returncode':expectedexit,'execution_sha256':digest(path)}
def validate_full(r,inv,aggregate_keys):
    clean(r);require(r.get('completed') is True and r.get('passed') is False and r.get('strict_passed') is False,'Original completed full failure must remain false')
    require(r.get('stl_sha256')==STL_SHA and r.get('expected_longest_mm')==219 and r.get('tool_sources_sha256')==inv,'Full source/input binding differs')
    bools(r.get('checks'),{'both_modes_strictly_pass','normal_optimized_scientific_evidence_identical','original_stl_unchanged','tool_sources_unchanged'},{'both_modes_strictly_pass','normal_optimized_scientific_evidence_identical'})
    require(type(r.get('modes')) is dict and set(r['modes'])=={'normal','optimized'},'Missing/extra full mode')
    for state in r['modes'].values():
        require(state.get('strict_passed') is False and state.get('error_type')=='QAError' and state.get('error')=='Standard aggregate did not strictly pass' and 'science' not in state,'Unexpected full failure reason')
        exits=state.get('child_exit_codes');require(type(exits) is dict and set(exits)=={'standard','intersections','intersection-controls','dense-evidence'},'Missing/extra full child stage')
        require(all(type(v) is int and v==(1 if k=='standard' else 0) for k,v in exits.items()),'Child exit mismatch')
def validate_generic_controls(e,base,r,inv):
    sys.path.insert(0,str(QA/'verification'))
    from run_qa import REQUIRED_CHECKS
    expected={}
    roster=[('normal_box','check_raw_mesh.py',True,None),('normal_box','check_sections.py',True,None),('normal_box','check_dense_surface.py',True,None),('missing_original_triangle','check_raw_mesh.py',False,'exact_coordinate_edges_two_faces'),('duplicate_original_triangle','check_raw_mesh.py',False,'exact_coordinate_edges_two_faces'),('one_reversed_face','check_raw_mesh.py',False,'exact_coordinate_consistent_winding'),('all_faces_inverted','check_raw_mesh.py',False,'positive_signed_volume'),('separate_closed_shell','check_raw_mesh.py',False,'single_surface_no_internal_shell'),('internal_closed_shell','check_raw_mesh.py',False,'single_surface_no_internal_shell'),('vertex_only_touching_shells','check_raw_mesh.py',False,'exact_coordinate_vertex_links_single_cycles'),('narrow_0p6mm_root','check_sections.py',False,'no_original_polygon_splits_after_erosion_or_opening'),('narrow_0p6mm_root','check_dense_surface.py',False,'all_first_original_chords_ge_0p8mm'),('tiny_original_polygon','check_sections.py',False,'all_original_polygons_survive_erosion_and_opening'),('thin_0p6mm_slab','check_dense_surface.py',False,'all_first_original_chords_ge_0p8mm'),('truncated_binary_record','check_raw_mesh.py',False,'completed_without_error')]
    for m in ('python_B','python_B_O'):
        for name,checker,expect,false in roster:expected[(m,name,checker)]=(expect,false)
    require(integer(r.get('control_runs'),'Bad control count')==30 and integer(r.get('fixtures'),'Bad fixture count')==12 and type(r.get('controls')) is list and len(r['controls'])==30,'Incomplete control roster')
    seen=set()
    for row in r['controls']:
        key=(row.get('mode'),row.get('fixture'),row.get('checker'));require(key in expected and key not in seen,'Unexpected/duplicate generic control');seen.add(key);expect,false=expected[key]
        require(row.get('expected_pass') is expect and row.get('expected_false_check')==false and row.get('expectation_verified') is True,'Control expectation altered')
        require(type(row.get('returncode')) is int and row['returncode']==(0 if expect else 1),'Control exit differs')
        path=e.artifact(base,row['report_file'],row['report_sha256'],False);child=e.read(path);require(child.get('passed') is expect and child.get('strict_passed') is expect and child.get('checker_sources_sha256')==inv,'Control child result/source differs')
        fixture=e.track(base/key[0]/key[1]/'fixture.stl',row['fixture_sha256']);require(child.get('stl_sha256')==digest(fixture),'Control fixture binding differs')
        require(false is None or child.get('checks',{}).get(false) is False,'Control rejected for wrong predicate')
        require(type(child.get('checks')) is dict and all(type(v) is bool for v in child['checks'].values()),'Control check is not Boolean')
        gate={'check_raw_mesh.py':'raw','check_sections.py':'sections','check_dense_surface.py':'dense'}[key[2]]
        expected_keys={'completed_without_error'} if false=='completed_without_error' else REQUIRED_CHECKS[gate]
        require(set(child['checks'])==set(expected_keys),'Control child missing/extra check keys')
        require(not expect or all(v is True for v in child['checks'].values()),'Positive control contains false check')
        require(row.get('actual_false_checks')==[k for k,v in child['checks'].items() if v is False],'Control false-check ledger differs')
    require(seen==set(expected),'Omitted generic control')
def validate_intersection_controls(e,base,opt,inv):
    from check_intersection_controls import base_cases
    r=e.read(base/'controls-summary.json');clean(r);require(r.get('passed') is True and type(r.get('optimization_level')) is int and r['optimization_level']==opt,'Intersection controls mode/pass differs')
    require(r.get('checker_sha256')==inv['check_original_intersections.py'] and r.get('controls_source_sha256')==inv['check_intersection_controls.py'],'Intersection controls source differs')
    cases={name:(expect,reason) for name,triangles,expect,reason,tiny in base_cases()}
    expected={(n,t,pa,pb,s) for n in cases for t in ('identity','oblique_or_tiny_reversible') for pa in itertools.permutations(range(3)) for pb in itertools.permutations(range(3)) for s in (False,True)}
    rows=r.get('predicate_cases');require(type(rows) is list and len(rows)==integer(r.get('predicate_case_count'),'Bad predicate count')==2736,'Predicate cases incomplete');seen=set()
    for row in rows:
        orders=row.get('vertex_orders');require(type(orders) is list and len(orders)==2 and all(type(p) is list and all(type(i) is int for i in p) for p in orders),'Invalid vertex-order control')
        require(type(row.get('pair_swapped')) is bool,'Non-Boolean swap');key=(row.get('case'),row.get('transform'),tuple(orders[0]),tuple(orders[1]),row['pair_swapped']);require(key in expected and key not in seen,'Predicate omitted/duplicated');seen.add(key);expect,reason=cases[key[0]];require(row.get('expected_pass') is expect and type(row.get('actual_reason')) is str and row['actual_reason'].startswith(reason),'Predicate truth differs')
    require(seen==expected,'Predicate roster incomplete')
    rows=r.get('broad_phase_bruteforce_cases');require(type(rows) is list and len(rows)==36,'Broadphase controls incomplete');seen=set()
    for row in rows:
        key=(integer(row.get('trial'),'Bad trial'),integer(row.get('axis'),'Bad axis'));require(key not in seen and key in {(t,a) for t in range(12) for a in range(3)} and row.get('matches_bruteforce') is True,'Broadphase roster differs');seen.add(key);integer(row.get('exact_pairs'),'Bad brute pair count')
    expectedsub={**{n:(x[0],False) for n,x in cases.items()},'normal_box':(True,False),'oblique_box':(True,False),'degenerate_face':(False,False),'malformed_count':(False,True),'nonfinite':(False,True)}
    rows=r.get('subprocess_executions');require(type(rows) is list and len(rows)==integer(r.get('subprocess_execution_count'),'Bad subprocess count')==48,'Subprocess controls incomplete');seen=set()
    for row in rows:
        flags=row.get('interpreter_flags');require(flags in (['-B'],['-B','-O']),'Wrong subprocess flags');o=1 if '-O' in flags else 0;name=row.get('case');key=(name,o);require(name in expectedsub and key not in seen,'Unexpected/duplicate subprocess');seen.add(key);expect,error=expectedsub[name]
        require(row.get('expected_pass') is expect and type(row.get('exit_code')) is int and row['exit_code']==(0 if expect else 2 if error else 1),'Intersection child exit differs')
        p=e.artifact(base,row['report'],row['report_sha256']);child=e.read(p);require(child.get('passed') is expect and child.get('strict_passed') is expect and child.get('stl_sha256')==row['stl_sha256'],'Intersection child result differs');e.track(base/(name+'.stl'),row['stl_sha256'])
        if error:require('error_type' in child and child.get('checker_source_sha256')==inv['check_original_intersections.py'],'Expected parse-error source differs')
        else:require(type(child.get('tools',{}).get('optimization_level')) is int and child['tools']['optimization_level']==o and child['tools'].get('source_sha256')==inv['check_original_intersections.py'],'Intersection child source/mode differs')
    return {'predicate_cases':2736,'subprocess_executions':48,'broad_phase_cases':36}
def validate_exact_summary(r,opt,count,binding):
    clean(r);require(all(r.get(k) is True for k in EXACT_TRUE),'Incomplete exact summary')
    require(type(r.get('optimization_level')) is int and r['optimization_level']==opt and r.get('original_numerical_strict_passed') is False,'Exact summary mode/strict differs')
    require(integer(r.get('full_original_csv_rows_verified'),'Bad CSV coverage')==RAYS and integer(r.get('selected_samples'),'Bad selected count')==integer(r.get('total_flagged_samples'),'Bad flag count')==count>0,'Exact flag coverage differs')
    require(type(r.get('input_and_tool_sha256')) is dict and r['input_and_tool_sha256']==binding,'Exact input/source binding differs')
def inspect_mode(e,full,exact,opt,stl,inv,required,aggregate_keys,out):
    from validate_dense_evidence import audit
    from check_dense_surface import WEIGHTS
    from artifact_structure import validate_sections,validate_exact_rows,validate_intersection_contacts
    mode='normal' if opt==0 else 'optimized';base=full/mode;std=base/'standard';summary=e.read(std/'qa-summary.json');clean(summary)
    require(summary.get('passed') is False and summary.get('strict_passed') is False,'Original standard strict failure was changed');bools(summary.get('checks'),aggregate_keys,AGG_FALSE)
    require(summary.get('optimized_python') is bool(opt) and summary.get('stl_sha256')==STL_SHA and summary.get('checker_sources_sha256')==inv and summary.get('expected_longest_mm')==219,'Standard mode/input/source binding differs')
    names={'raw':'raw-mesh-check.json','sections':'section-check.json','dense':'dense-check.json','controls':'control-check.json'};ledger=summary.get('gate_reports');require(type(ledger) is list and len(ledger)==4 and {x.get('gate') for x in ledger}==set(names),'Gate roster incomplete');reports={}
    for name,file in names.items():
        row=next(x for x in ledger if x['gate']==name);expect=name!='dense';path=std/name/file;r=e.read(path,row['report_sha256']);clean(r);reports[name]=r
        require(row.get('report_file')==str(path.relative_to(std)) and type(row.get('returncode')) is int and row['returncode']==(0 if expect else 1) and row.get('passed') is expect,'Gate process ledger differs')
        require(r.get('passed') is expect and r.get('strict_passed') is expect and r.get('checker_sources_sha256')==inv,'Gate source/strict differs')
        bools(r.get('checks'),required[name],DENSE_FALSE if name=='dense' else frozenset());require(row.get('failed_checks')==[k for k,v in r['checks'].items() if v is False],'Gate failure ledger differs')
        if name!='controls':require(r.get('stl_sha256')==STL_SHA,'Wrong gate STL')
    raw,sec,dense=reports['raw'],reports['sections'],reports['dense']
    require(integer(raw.get('triangles'),'Raw face count')==FACES and integer(raw.get('surface_shells'),'Raw shells')==1 and raw.get('extents_mm')==[219.,107.,119.] and raw.get('bounds_mm')==[[-5.,-102.,0.],[214.,5.,119.]] and raw.get('expected_longest_mm')==219,'Frozen raw dimensions/counts differ')
    require(raw.get('shell_face_counts')==[FACES],'Raw shell face coverage differs')
    for values in [raw['extents_mm'],*raw['bounds_mm']]:
        for value in values:finite(value,'Raw bound/extent is not a finite number')
    for k in ('bad_edges','bad_winding_edges','bad_vertex_links','degenerate_original_face_indices','bad_stored_normal_face_indices'):require(raw.get(k)==[],'Raw defect list nonempty/missing')
    require(finite(raw.get('signed_volume_mm3'),'Raw volume nonfinite')>0,'Raw volume nonpositive')
    details=e.artifact(std/'sections',sec['detail_file'],sec['detail_sha256']);failures=e.artifact(std/'sections',sec['failure_file'],sec['failure_sha256']);section_info=validate_sections(sec,e.gz(details),e.gz(failures))
    require(integer(dense.get('original_triangles'),'Dense face count')==FACES and integer(dense.get('samples'),'Dense ray count')==RAYS and integer(dense.get('samples_per_original_face'),'Dense per-face count')==10,'Dense original coverage differs')
    require(dense.get('barycentric_weights')==WEIGHTS.tolist() and dense.get('minimum_required_chord_mm')==.8 and dense.get('origin_outside_offset_mm')==1e-5,'Dense policy changed')
    require(integer(dense.get('under_0p8mm_count'),'Dense short count')==0 and finite(dense.get('minimum_first_chord_mm'),'Dense min nonfinite')>=.8,'Actual short rays remain')
    flags_path=e.artifact(std/'dense',dense['flagged_samples_file'],dense['flagged_samples_sha256']);flags=e.gz(flags_path);require(type(flags) is list and len(flags)==integer(dense.get('flagged_sample_count'),'Flag count',1),'Flag count differs')
    short_path=e.artifact(std/'dense',dense['short_chords_file'],dense['short_chords_sha256']);require(e.gz(short_path)==[],'Short evidence is not empty')
    csv_path=e.artifact(std/'dense',dense['csv_file'],dense['csv_compressed_sha256']);require(integer(dense.get('csv_compressed_bytes'),'Bad compressed bytes')==csv_path.stat().st_size,'CSV compressed byte count differs');integer(dense.get('uncompressed_csv_bytes'),'Bad decoded bytes',1)
    from qa_common import open_compressed_csv
    with open_compressed_csv(csv_path,dense.get('csv_compression')) as stream:
        decoded_bytes=sum(len(block) for block in iter(lambda:stream.read(1024*1024),b''))
    require(decoded_bytes==dense['uncompressed_csv_bytes'],'Decoded CSV byte count differs')
    require(dense.get('cpp_source_sha256')==inv['dense_original.cpp'] and type(dense.get('compiled_executable_sha256')) is str and re.fullmatch('[0-9a-f]{64}',dense['compiled_executable_sha256']),'Dense compiled/source binding missing')
    original_audit=e.read(base/'dense-evidence.json');clean(original_audit)
    # This is the unchanged audited core, applied to all actual records, not a summary-only acceptance.
    fresh_audit=audit(std/'dense/dense-check.json',stl);require(original_audit==fresh_audit,'Fresh CSV audit differs from original full audit')
    require(fresh_audit.get('passed') is True and fresh_audit.get('completed') is True and fresh_audit.get('all_original_numerical_flag_predicates_recomputed') is True and fresh_audit.get('all_expected_flag_indices_and_reasons_match') is True and fresh_audit.get('original_numerical_strict_passed') is False,'CSV audit did not preserve/completely recompute numerical flags')
    require(integer(fresh_audit.get('csv_rows_verified'),'Audit rows')==RAYS and integer(fresh_audit.get('lossless_descriptors_verified'),'Audit descriptors')==12*RAYS and integer(fresh_audit.get('flagged_samples_matched'),'Matched flags')==len(flags) and integer(fresh_audit.get('short_samples_matched'),'Matched short')==0,'CSV counts differ')
    write(out/(mode+'-fresh-csv-audit.json'),fresh_audit)
    validate_generic_controls(e,std/'controls',reports['controls'],inv)
    intersection=e.read(base/'intersections.json');clean(intersection)
    require(all(intersection.get(k) is True for k in ('passed','strict_passed','completed','input_unchanged_during_check')) and intersection.get('stl_sha256')==intersection.get('stl_sha256_after_check')==STL_SHA,'Exact original intersections failed/incomplete/wrong STL')
    require(intersection.get('tools',{}).get('source_sha256')==inv['check_original_intersections.py'] and type(intersection.get('tools',{}).get('optimization_level')) is int and intersection['tools']['optimization_level']==opt,'Intersection source/mode differs')
    contact=intersection['all_actual_intersections'];contact_path=e.artifact(base,contact['path'],contact['sha256']);contact_info=validate_intersection_contacts(intersection,e.jsonlines(contact_path))
    ic=validate_intersection_controls(e,base/'intersection-controls',opt,inv)
    exdir=exact/mode;ex=e.read(exdir/'exact-recorded-ray-summary.json')
    inputs={'stl':stl,'flags':flags_path,'dense_report':std/'dense/dense-check.json','raw_report':std/'raw/raw-mesh-check.json','intersections_report':base/'intersections.json','exact_core_source':QA/'tools/exact_ray_diagnosis.py','diagnostic_source':QA/'tools/diagnose_recorded_cpp_rays.py','original_csv':csv_path}
    binding={k:digest(e.track(p)) for k,p in inputs.items()};validate_exact_summary(ex,opt,len(flags),binding)
    ep=e.artifact(exdir,ex['detail_file'],ex['detail_sha256']);exactrows=list(e.jsonlines(ep));exact_info=validate_exact_rows(exactrows,flags)
    science={'stl_sha256':STL_SHA,'triangles':FACES,'rays':RAYS,'bounds_mm':raw['bounds_mm'],'extents_mm':raw['extents_mm'],'raw_report_sha256':digest(std/'raw/raw-mesh-check.json'),'section_detail_sha256':sec['detail_sha256'],'section_failure_sha256':sec['failure_sha256'],'section_structure':section_info,'dense_decoded_csv_sha256':dense['uncompressed_csv_sha256'],'dense_flags_sha256':dense['flagged_samples_sha256'],'dense_short_sha256':dense['short_chords_sha256'],'dense_minimum_first_chord_mm':dense['minimum_first_chord_mm'],'dense_cpp_executable_sha256':dense['compiled_executable_sha256'],'flag_count':len(flags),'short_count':0,'lossless_descriptors_verified':12*RAYS,'contact_sha256':contact['sha256'],'candidate_sequence_sha256':intersection['broad_phase']['candidate_sequence_sha256'],'intersection_structure':contact_info,'intersection_broad_phase':intersection['broad_phase'],'intersection_lattice':intersection['lattice'],'intersection_classification_counts':intersection['classification_counts'],'exact_details_sha256':ex['detail_sha256'],'exact_structure':exact_info,'controls':ic,'original_numerical_strict_passed':False}
    return science

def validate_synthetic_evidence(e,inv):
    # Fresh project-independent controls already run in both modes on these exact tools.
    summary=e.read(QA/'TOOL-CONTROLS-SUMMARY.json');require(summary.get('passed') is True and summary.get('tool_binding_sha256')==REUSE_SHA and summary.get('all_upstream_and_copied_tools_still_match_binding') is True,'Generic controls summary failed/source differs')
    toolmap=summary.get('tool_source_sha256');require(type(toolmap) is dict and all(toolmap.get(k)==v for k,v in inv.items()),'Synthetic tool hashes differ')
    for k,h in toolmap.items():e.artifact(QA,k,h,False)
    for outer in ('normal','optimized'):
        base=QA/'tool-controls'/('synthetic-'+outer);outer_ledger=next((x for x in summary['executions'] if x.get('stage')=='synthetic-'+outer),None);require(outer_ledger is not None,'Missing synthetic outer ledger');r=e.read(base/'controls-suite-summary.json');clean(r);require(r.get('passed') is True and r.get('strict_passed') is True and r.get('all_sources_unchanged') is True and r.get('tool_sources_sha256')==inv,'Synthetic suite source/pass differs')
        names={'positive-full'}|{m+'-'+t for m in ('normal','optimized') for t in ('fail-closed','dense-descriptors','archive')};rows=r.get('executions');require(type(rows) is list and len(rows)==7 and {x.get('name') for x in rows}==names and all(type(x.get('returncode')) is int and x['returncode']==0 for x in rows),'Synthetic process roster differs')
        for mode in ('normal','optimized'):
            for kind,n,script in [('fail-closed',26,'test_fail_closed.py'),('dense-descriptors',30,'test_dense_evidence.py')]:
                cr=e.read(base/(mode+'-'+kind)/'results.json',outer_ledger['cases'][mode][kind]['report_sha256']);require(cr.get('passed') is True and cr.get('source_sha256')==inv['tools/'+script] and integer(cr.get('case_count'),'Synthetic case count')==n and type(cr.get('cases')) is list and len(cr['cases'])==n,'Synthetic controls incomplete')
                require(len({x.get('case') for x in cr['cases']})==n and all(x.get('passed') is True and type(x.get('expected_accept')) is bool for x in cr['cases']),'Synthetic case result invalid')
            archive=e.read(base/(mode+'-archive')/'results.json',outer_ledger['cases'][mode]['archive']['report_sha256'])
            require(archive.get('passed') is True and archive.get('python_optimized') is (mode=='optimized') and archive.get('tool')=='archive_verify.py' and archive.get('tool_sha256')==inv['tools/archive_verify.py'],'Archive control source/mode differs')
            require(integer(archive.get('case_count'),'Archive case count')==65 and type(archive.get('cases')) is list and len(archive['cases'])==65 and len({x.get('case') for x in archive['cases']})==65,'Archive case roster incomplete')
            for case in archive['cases']:
                require(type(case.get('case')) is str and case['case'] and case.get('passed') is True and type(case.get('expected_accept')) is bool,'Archive case expectation/result invalid')
                if 'returncode' in case:require(type(case['returncode']) is int and case['returncode']==(0 if case['expected_accept'] else 1),'Archive case exit differs')
                if 'report' in case:require(type(case['report']) is dict and case['report'].get('passed') is case['expected_accept'],'Archive child outcome differs')
        ledger=next((x for x in summary['executions'] if x.get('stage')=='synthetic-'+outer),None);require(ledger is not None and type(ledger.get('exit_code')) is int and ledger['exit_code']==0 and ledger.get('passed') is True and ledger.get('source_inventory_unchanged') is True,'Synthetic outer process ledger differs');e.track(base/'controls-suite-summary.json',ledger['summary_sha256']);e.track(base/'positive-full/full-qa-summary.json',ledger['full_summary_sha256'])
    return {'original_gate_executions_per_mode':30,'intersection_predicate_cases_per_mode':2736,'intersection_subprocesses_per_mode':48,'fail_closed_cases_per_mode':26,'dense_descriptor_cases_per_mode':30,'archive_cases_per_mode':65}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=P,required=True,help='Source freeze root containing models/v14');ap.add_argument('--full',type=P,required=True);ap.add_argument('--exact',type=P,required=True);ap.add_argument('--captures',type=P,required=True);ap.add_argument('--out',type=P,required=True);ap.add_argument('--expect-review-opt',type=int,choices=[0,1],required=True);a=ap.parse_args()
    for k in ('root','full','exact','captures','out'):setattr(a,k,getattr(a,k).resolve())
    require(not a.out.exists(),'Review output must be NEW');require(QA in a.out.parents,'Review output must stay within author QA')
    for inp in (a.root/'models/v14',a.full,a.exact,a.captures):require(a.out!=inp and inp not in a.out.parents,'Review output overlaps input evidence tree')
    a.out.mkdir(parents=True);e=Evidence();report={'schema':'aeust-v14-author-bounded-supplement-v1','review_completed':False,'bounded_supplemental_pass':False,'original_numerical_strict_passed':False,'all_original_flags_exactly_resolved':False,'independent_qa_pass':False,'stl_sha256':STL_SHA,'review_optimization_level':sys.flags.optimize,'modes':{},'scope':'Author evidence aggregation only. Preserves original generic strict=false and all flags. Finite 1785 XY sections, 477700 original recorded rays and complete exact original-triangle contacts; no global wall-thickness, architectural, saved-scene/image, slicer, strength or physical-print guarantee. Independent QA remains required.'}
    try:
        require(type(sys.flags.optimize) is int and sys.flags.optimize==a.expect_review_opt,'Wrong reviewer optimization mode');require(len(os.sched_getaffinity(0))==1,'Apply single-CPU taskset and external shared lock');report['cpu_affinity']=sorted(os.sched_getaffinity(0))
        for p in sorted(P(__file__).parent.glob('*.py')):e.track(p)
        reuse=e.read(QA/'TOOLING-REUSE-BINDING.json',REUSE_SHA)
        for row in reuse['rows']:e.artifact(QA,row['path'],row['copied_sha256'],False)
        source=inventory(QA);require(set(source)=={row['path'] for row in reuse['rows'] if row['path'].startswith(('tools/','verification/'))},'Unbound additional/missing generic source');inv={P(k).name:v for k,v in source.items() if k.startswith('verification/')}
        freeze=e.read(QA/'V14-AUTHOR-SOURCE-FREEZE.json',FREEZE_SHA)
        for name,meta in freeze['files'].items():p=e.artifact(a.root,name,meta['sha256'],False);require(p.stat().st_size==meta['bytes'],'Frozen input byte count differs')
        stl=(a.root/'models/v14/model.stl').resolve();e.track(stl,STL_SHA)
        lattice=e.read(P(__file__).parent/'V14-LATTICE-BINDING.json','f79c62c4a0f3c5a1e47350e6ca0a48b5f21ce529bfed32a7bd1834f1233b0e74');require(lattice.get('completed') is True and lattice.get('stl_sha256')==STL_SHA and lattice.get('original_face_count')==FACES and lattice.get('coordinate_count')==9*FACES and lattice.get('maximum_float32_coordinate_as_integer_ratio_denominator')=='1073741824' and lattice.get('denominator_power_of_two')==30,'Frozen v14 lattice metadata differs')
        sys.path[:0]=[str(QA/'verification'),str(QA/'tools')]
        from run_full_qa import AGGREGATE_CHECKS
        from run_qa import REQUIRED_CHECKS
        required={k:set(v) for k,v in REQUIRED_CHECKS.items()};required['raw'].add('requested_longest_extent_mm')
        full=e.read(a.full/'full-qa-summary.json');validate_full(full,source,AGGREGATE_CHECKS)
        ledger=full.get('evidence_inventory');require(type(ledger) is dict and ledger,'Full output evidence inventory absent')
        actual={str(p.relative_to(a.full)) for p in a.full.rglob('*') if p.is_file()};require(actual==set(ledger)|{'full-qa-summary.json'},'Full evidence missing/extra files')
        for name,meta in ledger.items():p=e.artifact(a.full,name,meta['sha256'],False);require(type(meta.get('bytes')) is int and meta['bytes']==p.stat().st_size,'Full evidence byte count differs')
        report['process_captures']=[validate_capture(e,a.captures/'full/execution.json','full','normal',stl,a.full,None,source)]
        report['synthetic_controls']=validate_synthetic_evidence(e,source)
        for opt,mode in enumerate(('normal','optimized')):
            report['process_captures'].append(validate_capture(e,a.captures/('exact-'+mode)/'execution.json','exact',mode,stl,a.exact/mode,a.full,source))
            report['modes'][mode]=inspect_mode(e,a.full,a.exact,opt,stl,inv,required,AGGREGATE_CHECKS,a.out)
            write(a.out/'review-progress.json',report)
        require(report['modes']['normal']==report['modes']['optimized'],'Normal/-O SCIENTIFIC evidence differs')
        require(inventory(QA)==source and e.unchanged(),'Original evidence/tools changed during review')
        report.update(review_completed=True,bounded_supplemental_pass=True,all_original_flags_exactly_resolved=True,normal_optimized_scientific_evidence_identical=True,all_bound_inputs_unchanged=True,unresolved=False,original_flags_count=report['modes']['normal']['flag_count'])
    except Exception as err:report.update(error_type=type(err).__name__,error=str(err),unresolved=True)
    report['evidence_inventory']=e.files;report['source_qa_root']=str(QA);report['review_inputs']={k:str(getattr(a,k)) for k in ('root','full','exact','captures')};write(a.out/'bounded-review.json',report)
    print(json.dumps({'bounded_supplemental_pass':report['bounded_supplemental_pass'],'review_completed':report['review_completed'],'report':str(a.out/'bounded-review.json'),'error':report.get('error')}));return 0 if report['bounded_supplemental_pass'] else 1
if __name__=='__main__':raise SystemExit(main())
