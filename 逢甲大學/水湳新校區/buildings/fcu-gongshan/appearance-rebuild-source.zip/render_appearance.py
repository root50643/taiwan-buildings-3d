import bpy,json,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;O=R/'payload/逢甲大學/水湳新校區/buildings/fcu-gongshan';d=json.loads((O/'appearance-mesh.json').read_text());P=O/'previews';P.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
me=bpy.data.meshes.new('Original STL surface, conforming planar material subdivisions');me.from_pydata(d['vertices'],[],d['faces']);me.update();ob=bpy.data.objects.new('FCU Gongshan appearance, original geometry',me);bpy.context.collection.objects.link(ob)
def linear(c):return c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4
for name,col in d['palette']:
 m=bpy.data.materials.new(name);rgb=[int(col[i:i+2],16)/255 for i in (1,3,5)];m.diffuse_color=tuple(linear(c) for c in rgb)+(1,);me.materials.append(m)
for p,i in zip(me.polygons,d['material_indices']):p.material_index=i
# Persist source triangle provenance in Blender face attributes.
a=me.attributes.new('source_stl_triangle','INT','FACE')
for item,i in zip(a.data,d['source_triangle']):item.value=i
s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';sh=s.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.15;sh.curvature_valley_factor=1;sh.show_specular_highlight=True;sh.background_type='WORLD';s.world.color=(.12,.14,.16);s.view_settings.view_transform='Standard';s.view_settings.exposure=1.0
s.render.resolution_x=1400;s.render.resolution_y=1050;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.unit_settings.system='METRIC';s.unit_settings.scale_length=.001
for p in s.render.bl_rna.properties:
 if p.identifier.startswith('use_stamp') and p.type=='BOOLEAN':setattr(s.render,p.identifier,False)
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.type='ORTHO'
views=[('appearance-front',(150,230,145)),('appearance-rear',(-170,-240,150)),('appearance-aerial',(150,220,290)),('appearance-top',(0,0,350))]
manifest=[]
for name,loc in views:
 cam.location=loc;cam.rotation_euler=(Vector((0,0,10))-cam.location).to_track_quat('-Z','Y').to_euler();inv=cam.rotation_euler.to_matrix().transposed();pts=[inv@Vector(c) for c in ob.bound_box];w=max(v.x for v in pts)-min(v.x for v in pts);h=max(v.y for v in pts)-min(v.y for v in pts);cam.data.ortho_scale=max(w,h*4/3)*1.13;s.render.filepath=str(P/(name+'.png'));bpy.ops.render.render(write_still=True);manifest.append({'view':name,'camera':list(loc),'ortho_scale':cam.data.ortho_scale})
cam.location=views[0][1];cam.rotation_euler=(Vector((0,0,10))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=manifest[0]['ortho_scale'];s.render.filepath='//previews/appearance-front.png';ob['source_stl_sha256']='b81c4c9b53abc38982bc69a5cffb6742871a04e352ab5a1bf60929a649f8bc4d';ob['limitations']='Photo dates unknown. Approximate materials. Original 62 warnings/3 exception classes retained. Not a print test.'
for screen in bpy.data.screens:
 for area in screen.areas:
  for sp in area.spaces:
   if sp.type=='FILE_BROWSER' and sp.params:sp.params.directory=b'//'
bpy.ops.wm.save_as_mainfile(filepath=str(O/'appearance.blend'));(O/'appearance-render-manifest.json').write_text(json.dumps({'blender_version':bpy.app.version_string,'views':manifest},indent=2))
