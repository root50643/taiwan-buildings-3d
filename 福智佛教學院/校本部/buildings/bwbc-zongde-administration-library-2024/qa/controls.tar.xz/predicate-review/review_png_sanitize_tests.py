"""Small lossless-whitelist controls; no real images or Blender."""
import argparse,hashlib,importlib.util,json,pathlib,struct
from png_fixture_helpers import *

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--module',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
 source=pathlib.Path(args.module).resolve();out=pathlib.Path(args.out).resolve();out.mkdir(parents=True,exist_ok=False)
 spec=importlib.util.spec_from_file_location('png_sanitize_target',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 rows=[]
 def check(name,fn):
  row={'name':name}
  try:fn();row['ok']=True
  except Exception as e:row.update(ok=False,error=type(e).__name__+': '+str(e))
  rows.append(row)
 def require(v,msg):
  if not v:raise RuntimeError(msg)
 whitelist=['File','Date','Time','RenderTime','cycles.ViewLayer.total_time','cycles.ViewLayer.render_time','cycles.ViewLayer.synchronization_time']
 stable=[chunk(b'gAMA',struct.pack('>I',45455)),chunk(b'pHYs',struct.pack('>IIB',1000,1000,1)),text('Software','Blender'),text('Comment','keep'),chunk(b'vpAg',b'unknown-metadata')]
 for index,key in enumerate(whitelist):
  def run(index=index,key=key):
   a=out/(str(index)+'-raw.png');b=out/(str(index)+'-clean.png');raw=png(filters=(4,3,2),before=[stable[0],text(key,'private-path-or-time'),*stable[1:]],split=5);a.write_bytes(raw)
   proof=m.sanitize(a,b,hashlib.sha256(raw).hexdigest());expected=png(filters=(4,3,2),before=stable,split=5)
   require(proof['passed'] is True and b.read_bytes()==expected and a.read_bytes()==raw,'Whole surviving chunk identity failed')
   require(all(proof['checks'].values()),'Proof flags false');require('private-path-or-time' not in json.dumps(proof),'Removed plaintext leaked into proof')
  check('remove-only-'+key,run)
 def all_keys():
  a=out/'all-raw.png';b=out/'all-clean.png';raw=png(before=stable+[text(k,'private') for k in whitelist],after=[text('After','stay')],split=1);a.write_bytes(raw)
  proof=m.sanitize(a,b,hashlib.sha256(raw).hexdigest());require(b.read_bytes()==png(before=stable,after=[text('After','stay')],split=1),'Combined sanitize changed survivors')
  require(set(x['key'] for x in proof['removed_fields'])==set(whitelist),'Whitelist removed mismatch')
 check('remove-all-seven',all_keys)
 def no_removal():
  a=out/'no-removal-raw.png';b=out/'no-removal-clean.png';raw=png(before=stable+[text('FileName','stay'),text('TimeTaken','stay'),text('cycles.OtherLayer.total_time','stay')]);a.write_bytes(raw)
  proof=m.sanitize(a,b,hashlib.sha256(raw).hexdigest());require(a.read_bytes()==b.read_bytes() and proof['removed_fields']==[],'Unexpected removal')
 check('retain-nonallowlisted',no_removal)
 def reject(name,raw,expected_hash=None,preexisting=False):
  a=out/(name+'-raw.png');b=out/(name+'-clean.png');a.write_bytes(raw)
  if preexisting:b.write_bytes(b'sentinel')
  try:m.sanitize(a,b,expected_hash or hashlib.sha256(raw).hexdigest())
  except Exception:
   require(a.read_bytes()==raw,'Original mutated');require(not preexisting or b.read_bytes()==b'sentinel','Existing output overwritten');return
  raise RuntimeError('Invalid sanitize unexpectedly succeeded')
 check('wrong-sha',lambda:reject('wrong-sha',png(),expected_hash='0'*64))
 check('no-overwrite',lambda:reject('no-overwrite',png(),preexisting=True))
 check('bad-crc',lambda:reject('bad-crc',png()[:-1]+b'x'))
 check('bad-private-text',lambda:reject('bad-private-text',png(before=[chunk(b'tEXt',b'File\0path\0junk')])))
 for tag,payload in [(b'zTXt',b'File\0\0'+__import__('zlib').compress(b'path')),(b'iTXt',b'File\0\0\0\0\0path')]:
  check('private-'+tag.decode(),lambda tag=tag,payload=payload:reject('private-'+tag.decode(),png(before=[chunk(tag,payload)])))
 def compare_cleaned(change_stable=False):
  stem='stable-difference' if change_stable else 'private-difference'
  a=out/(stem+'-a.png');b=out/(stem+'-b.png');ca=out/(stem+'-ca.png');cb=out/(stem+'-cb.png')
  a.write_bytes(png(before=[text('File','/private/a.blend'),text('Date','old'),text('Comment','same')],level=0))
  b.write_bytes(png(before=[text('File','/private/b.blend'),text('Date','new'),text('Comment','changed' if change_stable else 'same')],filters=(1,2,4),level=9))
  require(m.compare(a,b,hashlib.sha256(a.read_bytes()).hexdigest())['passed'] is False,'Raw File difference accepted')
  m.sanitize(a,ca,hashlib.sha256(a.read_bytes()).hexdigest());m.sanitize(b,cb,hashlib.sha256(b.read_bytes()).hexdigest())
  result=m.compare(ca,cb,hashlib.sha256(ca.read_bytes()).hexdigest())
  require(result['passed'] is (not change_stable),'Sanitized comparison changed strict metadata policy')
  require(result['whole_png_file_bytes_identical'] is False,'Different IDAT bytes claimed identical')
 check('compare-sanitized-private-only-difference',compare_cleaned)
 check('compare-sanitized-retains-stable-difference',lambda:compare_cleaned(True))
 # Inject a deterministic concurrent output alteration immediately after its
 # validation parse. A final on-disk digest check must fail closed.
 def output_mutation():
  a=out/'mutation-raw.png';b=out/'mutation-clean.png';raw=png(before=[text('File','private')]);a.write_bytes(raw);original_parse=m.parse
  def changed_parse(path):
   result=original_parse(path)
   if pathlib.Path(path)==b:b.write_bytes(b.read_bytes()+b'corruption')
   return result
  m.parse=changed_parse
  try:
   try:proof=m.sanitize(a,b,hashlib.sha256(raw).hexdigest())
   except Exception:return
   raise RuntimeError('Returned passed=true after output changed; reported_sha='+proof['sanitized_png_sha256']+' actual_sha='+hashlib.sha256(b.read_bytes()).hexdigest())
  finally:m.parse=original_parse
 check('output-mutation-final-hash',output_mutation)
 result={'module_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'optimized':not __debug__,'case_count':len(rows),'passed_count':sum(x['ok'] for x in rows),'cases':rows}
 (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return 0 if all(x['ok'] for x in rows) else 1
if __name__=='__main__':raise SystemExit(main())
