"""Prepared small normal/-O packager controls; never runs geometry or Blender.

Run manually with --out NEW_DIRECTORY. This file is NOT executed as part of
archive preparation. Original fixtures and tools are read-only; mutation cases
use isolated copies. Every accepted package must pass the unchanged outer
verifier, fd-relative safe extraction, all-member readback and exact rebuild.
"""
from pathlib import Path
import argparse
import copy
import gzip
import hashlib
import io
import importlib.util
import json
import lzma
import marshal
import os
import shutil
import subprocess
import struct
import sys
import tarfile
import zipfile

HERE = Path(__file__).resolve().parent

def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def manifest_row(logical, target, data):
    return {'source_relative_path': logical, 'archive_path': target,
            'bytes': len(data), 'sha256': sha(data), 'transformation': 'identity'}


def tar_bytes(name, payload, symlink=False):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w', format=tarfile.USTAR_FORMAT) as stream:
        info = tarfile.TarInfo(name)
        if symlink:
            info.type = tarfile.SYMTYPE
            info.linkname = payload.decode()
            stream.addfile(info)
        else:
            info.size = len(payload)
            stream.addfile(info, io.BytesIO(payload))
    return buf.getvalue()


def zip_bytes(name, payload):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED) as stream:
        stream.writestr(name, payload)
    return buf.getvalue()


def synthetic_blend_defaults(extra=b'', tail_mutation=False, wrong_sdna_name=False):
    """Minimal SDNA fixture, never interpreted or loaded by Blender.

    The two full buffers reproduce reviewed generic defaults byte-for-byte,
    including all 29 nonzero residual bytes after the home buffer's first NUL.
    """
    home = (b'/' + b'home/agent' + b'\0azquez/\0ig/\0lender/\0.80/\0onfig/\0s/').ljust(1090, b'\0')
    output = (b'/' + b'tmp/' + b'\0').ljust(1024, b'\0')
    require(sha(home) == '2d1dc02e846e766c501535dfda01be83adbdea6d8e03a42e4e5df5377da744d1'
            and sha(output) == 'a27bf0cff013ac91d264ac7f6b87fe91b392cee0ed657588929e56c4f0b4d07d',
            'Synthetic known default buffer changed')
    if tail_mutation:
        home = home[:-1] + b'x'
    names = ['bad[1090]' if wrong_sdna_name else 'dir[1090]', 'pic[1024]', 'r']
    types = ['char', 'FileSelectParams', 'RenderData', 'Scene']
    def string_table(values):
        raw = struct.pack('<I', len(values)) + b''.join(s.encode() + b'\0' for s in values)
        return raw + b'\0' * ((-len(raw)) % 4)
    dna = b'SDNANAME' + string_table(names) + b'TYPE' + string_table(types)
    dna += b'TLEN' + struct.pack('<4H', 1, 1090, 1024, 1024) + b'STRC' + struct.pack('<I', 3)
    for type_id, fields in [(1, [(0, 0)]), (2, [(0, 1)]), (3, [(2, 2)])]:
        dna += struct.pack('<HH', type_id, len(fields))
        dna += b''.join(struct.pack('<HH', *field) for field in fields)
    def block(code, payload, sdna=0, count=1):
        return struct.pack('<4sIQII', code, len(payload), 0, sdna, count) + payload
    data = b'BLENDER-v403' + block(b'DATA', home) + block(b'SC\0\0', output, 2)
    if extra:
        data += block(b'TEST', extra, count=0)
    data += block(b'DNA1', dna) + block(b'ENDB', b'', count=0)
    findings = []
    for label, code, st, field, start, raw in [
            ('generic_file_browser_home', 'DATA', 'FileSelectParams', 'dir[1090]', 36, home),
            ('generic_unrendered_output_default', 'SC\0\0', 'Scene', 'r.pic[1024]', 1150, output)]:
        findings.append({'classification': label, 'block_code': code, 'struct': st, 'field': field,
                         'field_type': 'char', 'field_absolute_byte_offset': start,
                         'marker_absolute_byte_offset': start, 'marker_offset_in_field': 0,
                         'field_buffer_bytes': len(raw), 'field_buffer_sha256': sha(raw),
                         'after_first_nul_nonzero_bytes': sum(v != 0 for v in raw.split(b'\0', 1)[1])})
    allowance = {'source_relative_path': 'synthetic/state.blend', 'kind': 'blend_generic_defaults',
                 'bytes': len(data), 'sha256': sha(data),
                 'sdna_profile': {'blend_sha256': sha(data), 'version': '403', 'pointer_bytes': 8,
                                  'byte_order': 'little', 'field_findings': findings}}
    return data, allowance


class Harness:
    def __init__(self, out, original, allowlist, tool, source_map=None):
        self.out = out
        self.original = original
        self.allowlist = allowlist
        self.tool = tool
        self.rows = []
        self.original_hashes = {}
        self.source_map = source_map or {}

    def original_read(self, logical):
        label, relative = logical.split('/', 1)
        require(label in ('independent', 'v2-suite'), 'Unknown test source scope')
        base = self.out if label == 'v2-suite' else self.original
        if self.source_map and label == 'independent':
            require(logical in self.source_map, 'Original proof/source not publicly mapped: ' + logical)
            relative = self.source_map[logical]['archive_path']
        p = base / relative
        require(p.is_file() and not p.is_symlink(), 'Nonregular original fixture')
        data = p.read_bytes()
        self.original_hashes[str(p)] = sha(data)
        return data

    def execute(self, name, selection, roots, allowlist=None, privacy=None,
                expected=True, needle=None, pre=None, negative_archives=None, tooling=None):
        case = self.out / name
        case.mkdir(parents=True, exist_ok=True)
        selection_path = case / 'selection.json'
        write_json(selection_path, selection)
        command = [sys.executable, '-B', *(['-O'] if sys.flags.optimize else []),
                   str(self.tool), '--selection', str(selection_path),
                   '--out', str(case / 'package'), '--tooling', str(tooling or self.original / 'tooling')]
        for label, root in roots.items():
            command += ['--source-root', label + '=' + str(root)]
        if allowlist is not None:
            write_json(case / 'malformed.json', {'files': allowlist})
            command += ['--malformed-allowlist', str(case / 'malformed.json')]
        if negative_archives is not None:
            write_json(case / 'negative-archives.json', {'files': negative_archives})
            command += ['--negative-archive-allowlist', str(case / 'negative-archives.json')]
        if privacy is not None:
            write_json(case / 'privacy.json', {'files': privacy})
            command += ['--privacy-allowlist', str(case / 'privacy.json')]
        if pre:
            pre(case)
        run = subprocess.run(command, capture_output=True, text=True)
        (case / 'stdout.txt').write_text(run.stdout)
        (case / 'stderr.txt').write_text(run.stderr)
        if expected:
            require(run.returncode == 0, name + ' positive rejected: ' + run.stderr[-2000:])
            report = json.loads((case / 'package/packaging-result.json').read_text())
            require(report.get('passed') is True and report.get('model_go') is False
                    and report.get('sources_unchanged') is True
                    and report.get('all_tracked_dependencies_selected_and_copied') is True
                    and report.get('safe_extract_all_member_hashes_verified') is True
                    and report.get('bitwise_rebuild_verified') is True,
                    name + ' accepted without all archive checks')
        else:
            require(run.returncode != 0 and needle and needle in run.stderr,
                    name + ' did not fail closed for intended reason: ' + run.stderr[-2000:])
            require(not (case / 'package/controls.tar.xz').exists(),
                    name + ' exposed final archive despite failed validation')
        require(not (self.out / 'escape.txt').exists()
                and not (case / 'escape.txt').exists(), 'Nested member was extracted unsafely')
        self.rows.append({'case': name, 'passed': True, 'expected_accept': expected,
                          'returncode': run.returncode, 'expected_rejection_reason': needle})

    def simple(self, name, filename, data, expected=True, needle=None, tweak=None, privacy=None, pre=None):
        root = self.out / name / 'input'
        root.mkdir(parents=True)
        p = root / filename
        p.write_bytes(data)
        row = manifest_row('synthetic/' + filename, 'fixtures/' + filename, data)
        selection = {'passed': True, 'model_go': False, 'scope': 'Small isolated packager controls.', 'files': [row]}
        if tweak:
            tweak(selection)
        self.execute(name, selection, {'synthetic': root}, privacy=privacy,
                     expected=expected, needle=needle, pre=pre)

    def bound(self, name, entry, mutation=None, expected=True, needle=None, structural=False):
        root = self.out / name / 'input'
        root.mkdir(parents=True)
        record = copy.deepcopy(entry)
        proof = record['proof']
        names = {record['source_relative_path'], proof['result_path'], proof['generator_path']}
        if 'local_result_path' in proof:
            names.add(proof['local_result_path'])
        # The exact archive test generator is always present for structural-tar
        # rejection proof inspection, including legacy safe-replay fixtures.
        names.add('independent/tooling/tools/test_archive_verify.py')
        files = []
        roots = {'independent': root}
        for logical in sorted(names):
            data = self.original_read(logical)
            label, relative = logical.split('/', 1)
            base = root if label == 'independent' else root / label
            roots[label] = base
            p = base / relative
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
            # v1 packaging privacy-test source stays private proof material.
            if logical == proof['generator_path'] and proof.get('generator_public') is False:
                continue
            files.append(manifest_row(logical, 'selected/' + logical, data))
        selection = {'passed': True, 'model_go': False,
                     'scope': 'Exact copied negative fixture and bound original proof only.', 'files': files}
        if mutation:
            mutation(root, record, selection)
        self.execute(name, selection, roots, [] if structural else [record], expected=expected, needle=needle,
                     negative_archives=[record] if structural else None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--original-root', type=Path, default=HERE.parent)
    parser.add_argument('--allowlist', type=Path, default=HERE / 'malformed-fixture-allowlist-v1.json')
    parser.add_argument('--tool', type=Path, default=HERE / 'package_controls_v2.py')
    parser.add_argument('--source-map', type=Path)
    parser.add_argument('--negative-archive-allowlist', type=Path, default=HERE / 'negative-archive-fixture-allowlist-v1.json')
    args = parser.parse_args()
    require(not args.out.exists(), 'Fresh test output required')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    original = args.original_root.resolve()
    tool = args.tool.resolve()
    original_tool_hash = sha(tool.read_bytes())
    original_test_hash = sha(Path(__file__).read_bytes())
    allowlist_bytes = args.allowlist.read_bytes()
    entries = json.loads(allowlist_bytes)['files']
    require(len(entries) == 36 and all(e.get('proof') for e in entries),
            'Expected complete frozen 36-fixture allowlist')
    map_path = args.source_map or (original / 'ARCHIVE-SCOPE.json' if (original / 'ARCHIVE-SCOPE.json').is_file() else None)
    source_map = {}
    if map_path:
        mapped = json.loads(map_path.read_text())
        map_rows = mapped.get('copies', mapped.get('files'))
        require(isinstance(map_rows, list), 'Public replay source-map schema differs')
        source_map = {r['source_relative_path']: r for r in map_rows}
        require(len(source_map) == len(map_rows), 'Duplicate public replay source map')
    h = Harness(out, original, entries, tool, source_map)
    # Retest the exact six-byte payload with public v2 source. Original v1
    # generator contains private-marker literals and remains privately accounted;
    # never pretend that this new proof rewrites or reproduces its original run.
    h.simple('public-rejection-not-xz', 'fixture.xz', b'not xz',
             False, 'Unapproved malformed compressed payload')
    proof_path = out / 'public-rejection-not-xz/public-proof.json'
    write_json(proof_path, {'passed': True, 'case_count': 1,
               'optimization_level': sys.flags.optimize,
               'test_source_sha256': original_test_hash,
               'payload_sha256': sha(b'not xz'), 'payload_bytes': 6,
               'scope': 'New v2 rejection of the same exact six-byte input. Original v1 proof is unchanged and separately accounted.',
               'cases': [{'case': 'unapproved_bad_compression', 'passed': True,
                          'expected_accept': False, 'returncode': h.rows[-1]['returncode'],
                          'expected_rejection_reason': 'Unapproved malformed compressed payload'}]})
    public_generator = out / 'sources/test_package_controls_v2.py'
    public_generator.parent.mkdir()
    public_generator.write_bytes(Path(__file__).read_bytes())
    public_entries = copy.deepcopy(entries)
    rebinding = []
    for entry in public_entries:
        if entry['proof']['expected_rejection_case'] != 'unapproved_bad_compression':
            continue
        original_proof = entry.get('original_private_proof', entry['proof'])
        entry['proof'] = {'proof_kind': 'packager_expected_failure',
                          'expected_rejection_case': 'unapproved_bad_compression',
                          'expected_rejection_error': 'Unapproved malformed compressed payload',
                          'result_path': 'v2-suite/public-rejection-not-xz/public-proof.json',
                          'result_sha256': sha(proof_path.read_bytes()),
                          'generator_path': 'v2-suite/sources/test_package_controls_v2.py',
                          'generator_sha256': original_test_hash, 'generator_public': True}
        entry['original_private_proof'] = original_proof
        rebinding.append({'source_relative_path': entry['source_relative_path'],
                          'bytes': entry['bytes'], 'sha256': entry['sha256'],
                          'original_private_proof': original_proof,
                          'new_public_proof': entry['proof'],
                          'same_input_bytes': entry['bytes'] == 6 and entry['sha256'] == sha(b'not xz'),
                          'original_result_rewritten': False})
    require(len(rebinding) == 2 and all(r['same_input_bytes'] for r in rebinding),
            'Expected exactly two original-private-generator payload rebindings')
    write_json(out / 'public-malformed-fixture-allowlist.json', {'schema': 'aeust-v2-current-public-replay-fixtures-v1',
               'files': public_entries, 'original_payload_coverage_unchanged': True,
               'original_private_proof_rebinding_count': len(rebinding)})
    write_json(out / 'original-to-public-replay-binding.json', {'passed': True, 'bindings': rebinding,
               'scope': 'Complete original input-byte coverage is distinct from the current public replay suite. Two v1 generator-dependent rejection proofs are replaced for PUBLIC REPLAY ONLY by new v2 rejection runs on identical inputs.'})
    for index, entry in enumerate(public_entries):
        h.bound('exact-malformed-' + str(index).zfill(2), entry)
    structural_entries = json.loads(args.negative_archive_allowlist.read_text())['files']
    for case in ['forbidden_type_pax', 'member_padding', 'one_block_tar_terminator', 'header_checksum']:
        entry = next(r for r in structural_entries if r['proof']['expected_rejection_case'] == case)
        h.bound('exact-structural-' + case, entry, structural=True)
    samples = {}
    for entry in public_entries:
        samples.setdefault(entry['proof']['expected_rejection_case'], entry)
    chosen = samples['late_input_mutation']

    def mutate_raw(root, entry, selection):
        p = root / entry['source_relative_path'].split('/', 1)[1]
        data = p.read_bytes() + b'changed'
        p.write_bytes(data)
        for row in selection['files']:
            if row['source_relative_path'] == entry['source_relative_path']:
                row.update(bytes=len(data), sha256=sha(data))
    h.bound('raw-identity-mutated', chosen, mutate_raw, False, 'Malformed fixture raw identity differs')

    def missing_proof(root, entry, selection):
        (root / entry['proof']['result_path'].split('/', 1)[1]).unlink()
    h.bound('proof-file-missing', chosen, missing_proof, False, 'Missing/nonregular source')

    def mutate_proof(root, entry, selection):
        p = root / entry['proof']['result_path'].split('/', 1)[1]
        p.write_bytes(p.read_bytes() + b' ')
    h.bound('proof-bytes-mutated', chosen, mutate_proof, False, 'Bound source SHA256 differs')

    def mutate_generator(root, entry, selection):
        p = root / entry['proof']['generator_path'].split('/', 1)[1]
        p.write_bytes(p.read_bytes() + b'\n# changed\n')
    h.bound('generator-bytes-mutated', chosen, mutate_generator, False, 'Bound source SHA256 differs')

    def generator_present_but_unselected(root, entry, selection):
        logical = entry['proof']['generator_path']
        label, relative = logical.split('/', 1)
        source = (root if label == 'independent' else root / label) / relative
        require(source.is_file() and sha(source.read_bytes()) == entry['proof']['generator_sha256'],
                'Negative control requires the exact generator to remain readable')
        before = len(selection['files'])
        selection['files'] = [r for r in selection['files'] if r['source_relative_path'] != logical]
        require(len(selection['files']) == before - 1, 'Generator selection was not removed exactly once')
    h.bound('wrapper-generator-present-but-unselected', chosen,
            generator_present_but_unselected, False, 'Required dependency absent from selection')
    h.bound('packager-generator-present-but-unselected', samples['unapproved_bad_compression'],
            generator_present_but_unselected, False, 'Required dependency absent from selection')

    def bad_semantics(root, entry, selection):
        logical = entry['proof']['result_path']
        p = root / logical.split('/', 1)[1]
        obj = json.loads(p.read_text())
        row = next(r for r in obj['cases'] if r['test'] == 'late_input_mutation')
        row['exit_code'] = 0
        write_json(p, obj)
        data = p.read_bytes()
        entry['proof']['result_sha256'] = sha(data)
        for r in selection['files']:
            if r['source_relative_path'] == logical:
                r.update(bytes=len(data), sha256=sha(data))
    h.bound('proof-updated-hash-wrong-semantics', chosen, bad_semantics,
            False, 'Wrapper expected-rejection semantics differ')

    def remove_proof_mapping(root, entry, selection):
        entry['proof'] = None
    h.bound('proof-object-missing', chosen, remove_proof_mapping, False, 'Missing expected-failure proof')

    def wrong_tail_record(root, entry, selection):
        entry['anomaly'][0]['trailing_sha256'] = '0' * 64
    h.bound('trailing-identity-mismatch', chosen, wrong_tail_record,
            False, 'Malformed fixture trailing bytes differ')

    h.simple('ordinary-positive', 'ordinary.txt', b'clean synthetic evidence\n')
    h.simple('keyword-token-is-not-secret', 'source.py', b'token = None\napi_token = None\n')
    h.simple('unknown-malformed-xz', 'bad.xz', b'not xz', False, 'Unapproved malformed compressed payload')
    h.simple('unknown-malformed-gzip', 'bad.gz', b'not gzip', False, 'Unapproved malformed compressed payload')
    h.simple('unapproved-xz-tail', 'bad.xz', lzma.compress(b'clean') + b'x',
             False, 'Unapproved malformed compressed payload')
    h.simple('unapproved-gzip-tail', 'bad.gz', gzip.compress(b'clean', mtime=0) + b'x',
             False, 'Unapproved malformed compressed payload')
    h.simple('unapproved-extra-xz-stream', 'bad.xz', lzma.compress(b'clean') + lzma.compress(b''),
             False, 'Unapproved malformed compressed payload')
    h.simple('unapproved-malformed-nested-gzip', 'outer.tar', tar_bytes('bad.gz', b'not gzip'),
             False, 'Unapproved malformed nested compressed payload')
    private = b'/' + b'workspace/example/private'
    h.simple('private-plain', 'secret.txt', private, False, 'Private path marker')
    h.simple('private-gzip', 'secret.gz', gzip.compress(private, mtime=0), False, 'Private path marker')
    h.simple('private-xz', 'secret.xz', lzma.compress(private), False, 'Private path marker')
    h.simple('private-nested-tar-gzip', 'outer.tar', tar_bytes('inner.gz', gzip.compress(private, mtime=0)),
             False, 'Private path marker')
    h.simple('private-nested-zip-gzip', 'outer.zip', zip_bytes('inner.gz', gzip.compress(private, mtime=0)),
             False, 'Private path marker')
    h.simple('credential-shaped-dummy', 'dummy.txt', b'sk-proj-' + b'A' * 32,
             False, 'Credential-shaped content')
    h.simple('nested-zip-credential', 'dummy.zip', zip_bytes('fake.txt', b'xoxb-' + b'1234-' * 8),
             False, 'Credential-shaped content')
    h.simple('unsafe-nested-name-stays-data', 'outer.tar', tar_bytes('../escape.txt', b'harmless fixture'))
    h.simple('nested-symlink-stays-data', 'outer.tar', tar_bytes('link', b'../escape.txt', True))
    h.simple('unsafe-nested-zip-name-stays-data', 'outer.zip', zip_bytes('../escape.txt', b'harmless fixture'))
    h.simple('unknown-broken-zip', 'broken.zip', b'not zip', False, 'Invalid/unsupported nested zip')
    h.simple('unknown-broken-tar', 'broken.tar', b'not tar', False, 'Unapproved malformed nested tar')
    padded = bytearray(tar_bytes('a', b'x'))
    hidden = gzip.compress(private, mtime=0)
    padded[513:513 + len(hidden)] = hidden
    h.simple('private-hidden-in-tar-padding', 'outer.tar', bytes(padded),
             False, 'Unapproved malformed nested tar: member padding')
    one_terminator = tar_bytes('a', b'x')[:1536]
    h.simple('unknown-single-block-terminator', 'outer.tar', one_terminator,
             False, 'Unapproved malformed nested tar: terminator')
    h.simple('zip-directory-cannot-hide-payload', 'outer.zip', zip_bytes('hidden/', private),
             False, 'Nested zip directory contains payload')
    # Even an old genuine rejection report cannot waive an unlisted tar payload.
    name = 'forged-sibling-does-not-authorize-tar'
    root = out / name / 'input'
    root.mkdir(parents=True)
    hidden_tar = b'\0' * 512 + hidden
    hidden_tar += b'\0' * ((-len(hidden_tar)) % 512)
    payloads = {'spoof/controls.tar.xz': lzma.compress(hidden_tar),
                'spoof/result.json': h.original_read(samples['compressed_truncation']['proof']['result_path']),
                'tooling/tools/test_archive_verify.py': h.original_read('independent/tooling/tools/test_archive_verify.py')}
    selected = []
    for relative, data in payloads.items():
        p = root / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        selected.append(manifest_row('independent/' + relative, relative, data))
    h.execute(name, {'passed': True, 'model_go': False, 'files': selected},
              {'independent': root}, expected=False, needle='Unapproved malformed nested tar: terminator')
    # Path-object ordering differs from POSIX member-name ordering for this pair.
    name = 'posix-string-member-order'
    root = out / name / 'input'
    root.mkdir(parents=True)
    selected = []
    for relative in ['a/file.txt', 'a-b.txt']:
        p = root / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b'clean')
        selected.append(manifest_row('synthetic/' + relative, relative, b'clean'))
    h.execute(name, {'passed': True, 'model_go': False, 'files': selected}, {'synthetic': root})

    h.simple('unsafe-outer-target', 'ordinary.txt', b'clean', False, 'Unsafe relative path',
             tweak=lambda s: s['files'][0].__setitem__('archive_path', '../escape.txt'))
    h.simple('duplicate-target', 'ordinary.txt', b'clean', False, 'Duplicate logical source selection',
             tweak=lambda s: s['files'].append(dict(s['files'][0])))
    h.simple('selection-false', 'ordinary.txt', b'clean', False, 'Explicit passed file selection required',
             tweak=lambda s: s.__setitem__('passed', False))
    h.simple('model-go-forbidden', 'ordinary.txt', b'clean', False, 'Control archive must not claim model GO',
             tweak=lambda s: s.__setitem__('model_go', True))
    h.simple('source-symlink-forbidden', 'ordinary.txt', b'clean', False, 'Symlink in source path',
             pre=lambda case: ((case / 'input/ordinary.txt').unlink(),
                               (case / 'input/ordinary.txt').symlink_to('missing-target')))
    tmp = '/' + 'tmp/'
    data = (json.dumps({'render': {'filepath': tmp}}, indent=2) + '\n').encode()
    allowance = [{'source_relative_path': 'synthetic/state.json', 'bytes': len(data),
                  'sha256': sha(data), 'kind': 'json_blender_render_default',
                  'json_pointer': '/render/filepath'}]
    h.simple('exact-reviewed-blender-default', 'state.json', data, privacy=allowance)
    h.simple('unreviewed-generic-temporary-path', 'state.json', data,
             False, 'Unreviewed temporary path')
    other = (json.dumps({'render': {'filepath': tmp + 'private'}}) + '\n').encode()
    changed = copy.deepcopy(allowance)
    changed[0].update(bytes=len(other), sha256=sha(other))
    h.simple('different-temporary-path-not-waived', 'state.json', other,
             False, 'Known Blender render default field differs', privacy=changed)
    extra = (json.dumps({'render': {'filepath': tmp}, 'other': tmp + 'private'}) + '\n').encode()
    changed = copy.deepcopy(allowance)
    changed[0].update(bytes=len(extra), sha256=sha(extra))
    h.simple('extra-temporary-path-not-waived', 'state.json', extra,
             False, 'Temporary path outside exact Blender default', privacy=changed)

    blend, blend_allowance = synthetic_blend_defaults()
    h.simple('blend-exact-sdna-defaults-positive', 'state.blend', blend, privacy=[blend_allowance])
    h.simple('blend-public-profile-metadata-positive', 'allowance.json',
             (json.dumps({'files': [blend_allowance]}, indent=2) + '\n').encode())
    for case, key, value in [('whole-hash', 'sha256', '0' * 64),
                              ('whole-bytes', 'bytes', len(blend) + 1)]:
        changed = copy.deepcopy(blend_allowance)
        changed[key] = value
        h.simple('blend-wrong-' + case, 'state.blend', blend, False,
                 'Exact Blend privacy allowance identity differs', privacy=[changed])
    for case, key, value in [('buffer-hash', 'field_buffer_sha256', '0' * 64),
                              ('offset', 'field_absolute_byte_offset', 37),
                              ('field-name', 'field', 'arbitrary[1090]'),
                              ('field-type', 'field_type', 'int'),
                              ('classification', 'classification', 'arbitrary_default')]:
        changed = copy.deepcopy(blend_allowance)
        changed['sdna_profile']['field_findings'][0][key] = value
        h.simple('blend-wrong-' + case, 'state.blend', blend, False,
                 'Exact Blend SDNA profile differs', privacy=[changed])
    changed_blob, changed_allowance = synthetic_blend_defaults(tail_mutation=True)
    h.simple('blend-nul-tail-mutated-and-all-hashes-rebound', 'state.blend', changed_blob, False,
             'Generic-default full buffer hash differs', privacy=[changed_allowance])
    changed_blob, changed_allowance = synthetic_blend_defaults(extra=b'/' + b'tmp/extra')
    h.simple('blend-extra-temporary-path-outside-fields', 'state.blend', changed_blob, False,
             'Unreviewed temporary path', privacy=[changed_allowance])
    changed_blob, changed_allowance = synthetic_blend_defaults(extra=b'/' + b'home/extra')
    h.simple('blend-extra-home-path-outside-fields', 'state.blend', changed_blob, False,
             'Private path marker', privacy=[changed_allowance])
    h.simple('blend-missing-exact-allowance', 'state.blend', blend, False, 'Private path marker')
    changed_blob, changed_allowance = synthetic_blend_defaults(wrong_sdna_name=True)
    h.simple('blend-caller-profile-cannot-invent-sdna-field', 'state.blend', changed_blob, False,
             'Required SDNA field absent', privacy=[changed_allowance])

    for label, literal in [('positive', '1e999'), ('negative', '-1e999')]:
        def overflow_selection(case, value=literal):
            path = case / 'selection.json'
            text = path.read_text()
            require('"scope":' in text, 'Overflow control selection scope missing')
            path.write_text(text.replace('"scope":', '"overflow": ' + value + ', "scope":', 1))
        h.simple('nonfinite-json-exponent-' + label, 'ordinary.txt', b'clean', False,
                 'Nonfinite JSON float', pre=overflow_selection)

    name = 'timestamp-matching-bytecode-cache-never-loaded'
    case = out / name
    input_root = case / 'input'
    input_root.mkdir(parents=True)
    (input_root / 'ordinary.txt').write_bytes(b'clean')
    copied_tooling = case / 'copied-tooling'
    (copied_tooling / 'tools').mkdir(parents=True)
    for filename in ['archive_verify.py', 'build_controls_archive.py']:
        source = h.original_read('independent/tooling/tools/' + filename)
        target = copied_tooling / 'tools' / filename
        target.write_bytes(source)
        info = target.stat()
        poison = compile("raise RuntimeError('STALE_TOOL_CACHE_EXECUTED')\n", str(target), 'exec')
        cache = Path(importlib.util.cache_from_source(str(target),
                     optimization=str(sys.flags.optimize) if sys.flags.optimize else None))
        cache.parent.mkdir(exist_ok=True)
        cache.write_bytes(importlib.util.MAGIC_NUMBER
                          + struct.pack('<III', 0, int(info.st_mtime) & 0xffffffff, len(source))
                          + marshal.dumps(poison))
    h.execute(name, {'passed': True, 'model_go': False, 'files': [
        manifest_row('synthetic/ordinary.txt', 'ordinary.txt', b'clean')]},
        {'synthetic': input_root}, tooling=copied_tooling)
    require(sha(tool.read_bytes()) == original_tool_hash
            and sha(Path(__file__).read_bytes()) == original_test_hash
            and args.allowlist.read_bytes() == allowlist_bytes,
            'Test, packager or frozen allowlist changed')
    require(all(sha(Path(p).read_bytes()) == hsh for p, hsh in h.original_hashes.items()),
            'Original fixture/proof source changed')
    result = {'passed': True, 'model_go': False, 'optimization_level': sys.flags.optimize,
              'case_count': len(h.rows), 'exact_original_malformed_fixture_cases': len(entries),
              'original_private_proof_rebinding_count': len(rebinding),
              'package_source_sha256': original_tool_hash, 'test_source_sha256': original_test_hash,
              'allowlist_sha256': sha(allowlist_bytes), 'all_original_sources_unchanged': True,
              'no_geometry_or_blender_executed': True, 'cases': h.rows}
    write_json(out / 'results.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'cases'}))


if __name__ == '__main__':
    main()
