"""One-time metadata preparation only; no producer imports, scans or execution.

Requires all named original terminal results; writes new plan/decision metadata
inside archive-preparation. Never executes the final inventory generator.
"""
from pathlib import Path
import copy,hashlib,json,os,stat
Q=Path(__file__).resolve().parents[1]
P=Path(__file__).resolve().parent
TRACKED={}
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(p):
 need(not p.is_symlink() and p.is_file(),'Nonregular metadata input')
 a=p.stat();b=p.read_bytes();z=p.stat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),'Source changed while reading');TRACKED[p]=sha(b);return b
def logical(p):
 frozen=Q/'final-v15-r1/frozen'
 return 'author/'+p.relative_to(frozen).as_posix() if p.is_relative_to(frozen) else 'independent/'+p.relative_to(Q).as_posix()
def ref(p):
 b=raw(p);return {'source_relative_path':logical(p),'bytes':len(b),'sha256':sha(b)}
def read(p):return json.loads(raw(p))
def output(name,d):
 with (P/name).open('x') as f:json.dump(d,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')

def main():
 template=read(P/'final-inventory-plan-TEMPLATE.json');plan=copy.deepcopy(template)
 plan['ready_for_terminal_inventory']=False
 plan['scope']='Exact completed-terminal roster plan for parent review/execution. Finalize remains disabled until actual roster/profile identities and all per-file publication dispositions are reviewed.'
 plan['planned_output_source_prefix']='independent/archive-preparation/final-inventory-r1'
 plan['source_roster']={'source_relative_path':plan['planned_output_source_prefix']+'/private-source-roster-FINAL.json','bytes':None,'sha256':'PENDING_ACTUAL_ROSTER'}
 plan['blend_candidate_roster']={'source_relative_path':plan['planned_output_source_prefix']+'/blend-candidates-FINAL.json','bytes':None,'sha256':'PENDING_ACTUAL_ROSTER'}
 plan['logical_alias_prefixes']['v2-suite']='independent/package-controls-normal-v2'
 plan['malformed_allowlists']=[ref(Q/'package-controls-normal-v2/public-malformed-fixture-allowlist.json')]
 for key in ('blend_decoder_source','blend_batch_source','archive_verifier_source','archive_builder_source'):
  plan[key]=ref(Q/plan[key]['source_relative_path'].split('/',1)[1])
 test=ref(Q/'independent-tools/test_control_blend_profiles.py');batch=plan['blend_batch_source'];proofs=[];bad=set()
 for mode,opt in [('normal',0),('optimized',1)]:
  rp=Q/f'control-blend-profile-controls-{mode}-v15/results.json';r=read(rp)
  need(r['passed'] is True and r['optimization_level']==opt and r['case_count']==11,'Batch controls not terminal')
  need(r['source_sha256']==batch['sha256'] and r['test_source_sha256']==test['sha256'],'Batch control source differs')
  cases=[c for c in r['cases'] if c['name']=='unclassified_decoder_error_is_not_policy_success'];need(len(cases)==1,'Missing exact negative case');c=cases[0]
  need(c['passed'] is True and c['expected_accept'] is False and c['accepted'] is False and c['returncode']==1 and c['expected_error']=='Unclassified decoder/infrastructure failure','Negative rejection semantics differ')
  bad.add(c['fixture_sha256']);proofs.append({'reference':ref(rp),'optimization_level':opt})
 need(len(bad)==1,'Negative fixture identity differs between modes')
 rows=[];blend_count=0
 for base,dirs,files in os.walk(Q,followlinks=False):
  dirs[:]=[n for n in dirs if not (Path(base)/n).is_symlink()]
  for name in sorted(files):
   p=Path(base)/name
   if not name.lower().endswith('.blend') or p.is_symlink():continue
   s=p.lstat();need(stat.S_ISREG(s.st_mode),'Nonregular Blend candidate');blend_count+=1
   descriptor=ref(p)
   if descriptor['sha256'] not in bad:continue
   rows.append({**descriptor,'approved':True,'category':'private_control_fixture',
    'reason':'Exact original intentionally out-of-range SDNA-index negative fixture. Both completed controlled batch modes prove that this unclassified decoder failure must stop rather than masquerade as a policy rejection; retain every original byte privately and exclude only this exact path/hash from ordinary profile execution.',
    'proof':{'kind':'unclassified_sdna_negative_control','generator_source':test,'tested_source':batch,'result_proofs':proofs}})
 need(rows,'No original malformed SDNA fixtures found')
 rows.sort(key=lambda r:r['source_relative_path'])
 exclusion={'schema':'aeust-exact-reviewed-blend-profile-exclusions-v1','model_go':False,'prepared_for_parent_exact_review':True,
  'execution_authority':'Parent requested preparation of exact terminal exclusions; parent reviews this file and plan before invoking the roster. No profile or roster was executed by this metadata writer.',
  'files':rows,'matching_original_file_count':len(rows),'current_regular_blend_paths_examined':blend_count,
  'scope':'Only exact negative SDNA-index fixtures with completed normal and optimized rejection proofs. All remain in full original inventory; no directory, extension or generic malformed exception.'}
 output('blend-profile-exclusions-r1.json',exclusion)
 plan['reviewed_blend_profile_exclusions']=[ref(P/'blend-profile-exclusions-r1.json')]
 requirements=[]
 def gate(rel,assertions):
  p=Q/rel;d=read(p)
  for pointer,expected in assertions:
   value=d
   for part in pointer[1:].split('/'):
    k=part.replace('~1','/').replace('~0','~');value=value[int(k)] if isinstance(value,list) else value[k]
   need(type(value) is type(expected) and value==expected,'Terminal gate differs: '+rel+pointer)
  requirements.append({'reference':ref(p),'assertions':[{'pointer':k,'equals':v} for k,v in assertions]})
 gate('final-v15-r1/independent-execution-summary.json',[('/completed',True),('/all_frozen_inputs_and_tools_unchanged',True),('/strict_passed',False),('/stl_sha256','46649566e965a049e6e333e9d82b075407c8e926e55c9034f11fbe3dbdf15a5d')])
 gate('postflight-v15-r1/postflight-summary.json',[('/passed',True),('/completed',True),('/original_numerical_strict_passed',False),('/all_sources_unchanged',True),('/local_bytecode_cache_absent_before_and_after_every_stage',True),('/bytecode_guard_control_count',4)])
 for rel,count in [('postflight-v15-r1/postflight-summary.json',14),('packaging-controls-v15-r1/results.json',8),('inventory-controls-v15-r1/results.json',2)]:
  d=read(Q/rel);need(len(d['executions'])==count,'Terminal execution count differs')
  checks=[('/passed',True),('/all_sources_unchanged',True)]+[(f'/executions/{i}/returncode',0) for i in range(count)]
  if 'tooling_freeze_sha256' in d:
   freeze=Q/('INVENTORY-CONTROLS-TOOLING-FREEZE-v15.json' if rel.startswith('inventory-') else 'PACKAGING-CONTROLS-TOOLING-FREEZE-v15.json')
   checks.append(('/tooling_freeze_sha256',ref(freeze)['sha256']))
  gate(rel,checks)
 suites=[
  ('package-controls-{mode}-v2/results.json','case_count',101,{'package_source_sha256':P/'package_controls_v2.py','test_source_sha256':P/'test_package_controls_v2.py'},'all_original_sources_unchanged'),
  ('public-bundle-controls-{mode}-v15/results.json','test_methods',27,{'source_sha256':Q/'public-preparation/test_public_bundle_tools.py','helper_sha256':Q/'public-preparation/public_bundle_common_v15.py','scanner_sha256':P/'package_controls_v2.py'},None),
  ('control-blend-profile-controls-{mode}-v15/results.json','case_count',11,{'source_sha256':Q/'independent-tools/profile_control_blends.py','test_source_sha256':Q/'independent-tools/test_control_blend_profiles.py'},None),
  ('private-checkpoint-controls-{mode}-v15/results.json','case_count',28,{'source_sha256':Q/'independent-tools/package_private_final_v15.py','test_source_sha256':Q/'independent-tools/test_private_final_checkpoint.py'},'all_original_tool_and_baseline_archive_bytes_unchanged'),
  ('archive-preparation/generator-controls-{mode}-v1/results.json','case_count',45,{'source_sha256':P/'generate_final_inventory.py','test_source_sha256':P/'test_generate_final_inventory.py','public_helper_source_sha256':Q/'public-preparation/public_bundle_common_v15.py','v2_scanner_source_sha256':P/'package_controls_v2.py'},'all_original_generator_helper_and_tool_bytes_unchanged'),
  ('blend-sdna-controls-{mode}-v15/results.json','case_count',9,{'source_sha256':Q/'independent-tools/audit_blend_sdna.py','test_source_sha256':Q/'independent-tools/test_blend_sdna.py'},'all_original_input_and_tool_bytes_unchanged'),
  ('control-blend-sdna-controls-{mode}-v15/results.json','case_count',11,{'source_sha256':Q/'independent-tools/audit_control_blend_sdna.py','test_source_sha256':Q/'independent-tools/test_control_blend_sdna.py'},'all_original_input_and_tool_bytes_unchanged')]
 for mode,opt in [('normal',0),('optimized',1)]:
  for pattern,countkey,count,sources,unchanged in suites:
   rel=pattern.format(mode=mode);checks=[('/passed',True),('/optimization_level',opt),('/'+countkey,count)]
   checks += [('/'+key,ref(path)['sha256']) for key,path in sources.items()]
   if unchanged:checks.append(('/'+unchanged,True))
   if countkey=='test_methods':checks.append(('/subtest_count',124))
   gate(rel,checks)
 plan['terminal_requirements']=requirements
 plan['completed_control_scope_notes']={'actual_new_suite_counts_per_mode':{'packager':101,'public_bundle_methods':27,'public_bundle_subtests':124,'blend_profile_batch':11,'private_checkpoint':28,'inventory_generator':45},'all_current_malformed_fixtures_classified':False,'new_malformed_and_nested_policy':'The original 36 compression and 372 structural allowlist rows are historical exact subsets only. Every new suite input must be scanned and bound by exact raw identity/case result/source, or receive an individually reviewed private disposition. Unknown/new nested payloads stay HOLD.','private_backup_controls_scope':'Public replay executes only the synthetic 28-case checkpoint suite; the actual private QA backup is never selected for public release.'}
 required=['independent/archive-preparation/generate_final_inventory.py','independent/archive-preparation/test_generate_final_inventory.py','independent/independent-tools/package_private_final_v15.py','independent/independent-tools/test_private_final_checkpoint.py','author/models/v15/scene.blend']
 for name in ['assemble_public_v15.py','verify_public_v15.py','public_bundle_common_v15.py','test_public_bundle_tools.py']:
  source='independent/public-preparation/'+name;required.append(source);plan['archive_mapping_rules'].append({'source_prefix':source,'archive_prefix':'public-preparation/'+name})
 for name in ['generate_final_inventory.py','test_generate_final_inventory.py']:
  plan['archive_mapping_rules'].append({'source_prefix':'independent/archive-preparation/'+name,'archive_prefix':'independent-tools/'+name})
 plan['replay_required_sources']=sorted(set(plan['replay_required_sources']+required))
 replay=copy.deepcopy(plan['replay']);replay['schema']='aeust-terminal-controls-public-replay-plan-r1';replay['status']='COMMANDS_PREPARED_AFTER_ORIGINAL_TERMINAL_CONTROLS_PUBLIC_ARCHIVE_REPLAY_PENDING';replay['model_go']=False
 replay['archive_layout']['public-preparation/']='Exact four publication helper/test sources, kept as siblings for original relative imports.'
 replay['fresh_output_reservations'] += ['independent-tools/generator-controls-replay-normal-v1','independent-tools/generator-controls-replay-optimized-v1']
 steps=[
  ('public-bundle-27','public-preparation/test_public_bundle_tools.py --scanner independent-tools/package_controls_v2.py --scanner-sha256 1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c --out replay-results/public-bundle-{mode}',27),
  ('control-blend-profile-batch-11','independent-tools/test_control_blend_profiles.py --blend observed-author/models/v15/scene.blend --out replay-results/control-blend-profile-{mode}',11),
  ('private-checkpoint-synthetic-28','independent-tools/test_private_final_checkpoint.py --out replay-results/private-checkpoint-{mode}',28),
  ('inventory-generator-45','independent-tools/test_generate_final_inventory.py --public-helper public-preparation/public_bundle_common_v15.py --public-helper-sha256 75f1604d4f67e87906325c7394d39b96fad98e1c44ca59db862307b4a35b935a --out independent-tools/generator-controls-replay-{mode}-v1',45),
  ('primary-blend-sdna-9','independent-tools/test_blend_sdna.py --blend observed-author/models/v15/scene.blend --out replay-results/primary-blend-sdna-{mode}',9),
  ('control-blend-sdna-11','independent-tools/test_control_blend_sdna.py --blend observed-author/models/v15/scene.blend --out replay-results/control-blend-sdna-{mode}',11)]
 for ident,command,count in steps:
  replay['steps'].append({'id':ident,'commands':['taskset -c "$CPU" python -B '+command.format(mode='normal'),'taskset -c "$CPU" python -B -O '+command.format(mode='optimized')],'expected_cases_or_methods_per_mode':count,'notes':'Run serially under the approved shared lock on one allowed CPU. Create replay-results only at execution. Outputs must be new and never replace observed originals. Synthetic success is not model GO.'})
 replay['not_claimed']=['No final public archive has been built or replayed by this plan preparation.','Original completed control counts do not substitute for an actual public archive safe replay.','No model GO is granted; original numerical strict=false remains unchanged.','Private QA backup payloads and raw diagnostics remain private even though their synthetic mechanism is reproducible.']
 output('replay-plan-FINAL-CANDIDATE-r1.json',replay);plan['replay']=replay;plan['replay_attachment']=ref(P/'replay-plan-FINAL-CANDIDATE-r1.json')
 plan['unresolved_path_notes']=['Only source_roster and blend_candidate_roster descriptors are intentionally pending actual first-stage output.','Finalization remains disabled; import actual two-mode profiles and exact original per-file omissions/allowlists in a new final plan.','Unknown current malformed/nested fixtures remain HOLD; historical allowlist counts are not complete-current coverage.','All sources already captured by a roster must retain original bytes at the same path or another exact preserved identity.']
 need(all(sha(p.read_bytes())==h for p,h in TRACKED.items()),'Metadata input or Blend bytes changed during static preparation')
 output('final-roster-plan-r1.json',plan)
 summary={'schema':'aeust-terminal-roster-plan-static-review-r1','model_go':False,'roster_executed':False,'profile_batch_executed':False,'generator_or_scanner_executed':False,'terminal_requirement_entries':len(requirements),'approved_exact_negative_blend_rows_prepared_for_parent_review':len(rows),'current_regular_blend_paths_examined_in_exclusion_identity_search':blend_count,'expected_profile_candidates_if_snapshot_unchanged':blend_count-len(rows),'all_read_inputs_unchanged':True,'files':{name:ref(P/name) for name in ['final-roster-plan-r1.json','blend-profile-exclusions-r1.json','replay-plan-FINAL-CANDIDATE-r1.json']},'scope':'Metadata fill and exact known-negative Blend identity search only. Parent reviews the four exact exclusions and runs the formal full roster and independent profile batch.'}
 output('final-roster-plan-static-review-r1.json',summary)
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
