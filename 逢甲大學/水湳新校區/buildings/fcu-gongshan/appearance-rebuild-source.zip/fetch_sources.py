import json,urllib.request,pathlib,hashlib,concurrent.futures
root=pathlib.Path(__file__).parent; tree=json.loads((root/'source/tree.json').read_text())['tree']; prefix='逢甲大學/水湳新校區/buildings/fcu-gongshan/'
def fetch(t):
 p=t['path']; dst=root/'source/repo'/p;dst.parent.mkdir(parents=True,exist_ok=True)
 data=urllib.request.urlopen('https://raw.githubusercontent.com/root50643/taiwan-buildings-3d/8388c665eb19c2857a0f29143a8713b801c3cea1/'+urllib.parse.quote(p),timeout=60).read()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==t['sha'],p
 dst.write_bytes(data)
sel=[t for t in tree if t['type']=='blob' and ((t['path'].startswith(prefix) and '/previews/' not in t['path'] and not t['path'].endswith('.blend')) or t['path'] in ['README.md','README.zh-TW.md','model-packages.json','逢甲大學/README.md','逢甲大學/README.zh-TW.md','逢甲大學/水湳新校區/README.md','逢甲大學/水湳新校區/README.zh-TW.md'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:list(ex.map(fetch,sel))
for name,sha in [('hero-2-day-aerial.jpg','1376541beb0bc99660a30001650d9cb76044ba6b175ca8fe3f7341756b1f2ab8'),('hero-3-skyline-aerial.jpg','ba9d4d28356413149faf262ccb4c95f1e7423785232d5ab59acfe4b52d301a22')]:
 data=urllib.request.urlopen('https://focus.fcu.edu.tw/virtuosihall/images/'+name,timeout=60).read(); assert hashlib.sha256(data).hexdigest()==sha;(root/'source'/name).write_bytes(data)
print('Verified',len(sel),'Git blobs and two photos')
