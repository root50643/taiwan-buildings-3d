"""Fresh serial packaging/privacy/restore controls; caller holds shared lock.
These controls do not grant geometry acceptance or permission to publish.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
Q=Path(__file__).resolve().parents[1]
def require(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def main():
 require(len(os.sched_getaffinity(0))==1,'One CPU required');out=Q/'packaging-controls-v15-r1';require(not out.exists(),'Fresh control ledger required');require(json.loads((Q/'postflight-v15-r1/postflight-summary.json').read_text())['passed'] is True,'Completed full postflight required');out.mkdir();freeze=json.loads((Q/'PACKAGING-CONTROLS-TOOLING-FREEZE-v15-r2.json').read_text());require(all(sha(Q/k)==v['sha256'] and (Q/k).stat().st_size==v['bytes'] for k,v in freeze['files'].items()),'Frozen packaging/control sources differ');env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None);rows=[]
 def run(name,command,result,field,count):
  start=time.time();log=out/(name+'.log');write(out/'running-stage.json',{'name':name,'started_unix':start,'finished':False})
  with log.open('w') as stream:cp=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=Q)
  row={'name':name,'returncode':cp.returncode,'elapsed_seconds':time.time()-start,'command':command,'log_sha256':sha(log),'log_file':log.name};rows.append(row);write(out/'executions.json',rows);write(out/'running-stage.json',{**row,'finished':True});print(json.dumps({'stage':name,'returncode':cp.returncode}),flush=True);require(cp.returncode==0,'Fresh packaging control failed '+name);d=json.loads(result.read_text());require(d['passed'] is True and d[field]==count,'Unexpected complete control count '+name);row['result_sha256']=sha(result);row['verified_case_count']=count
 for mode,opts in [('normal',[]),('optimized',['-O'])]:
  py=[sys.executable,'-B',*opts]
  run(mode+'-public-control-packager',py+[str(Q/'archive-preparation/test_package_controls_v2.py'),'--out',str(Q/('package-controls-'+mode+'-v2'))],Q/('package-controls-'+mode+'-v2/results.json'),'case_count',101)
  run(mode+'-public-bundle',py+[str(Q/'public-preparation/test_public_bundle_tools.py'),'--scanner',str(Q/'archive-preparation/package_controls_v2.py'),'--scanner-sha256','1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c','--out',str(Q/('public-bundle-controls-'+mode+'-v15'))],Q/('public-bundle-controls-'+mode+'-v15/results.json'),'test_methods',27)
  run(mode+'-control-blend-profile-batch',py+[str(Q/'independent-tools/test_control_blend_profiles.py'),'--blend',str(Q/'final-v15-r1/frozen/models/v15/scene.blend'),'--out',str(Q/('control-blend-profile-controls-'+mode+'-v15'))],Q/('control-blend-profile-controls-'+mode+'-v15/results.json'),'case_count',11)
  run(mode+'-private-checkpoint',py+[str(Q/'independent-tools/test_private_final_checkpoint.py'),'--out',str(Q/('private-checkpoint-controls-'+mode+'-v15'))],Q/('private-checkpoint-controls-'+mode+'-v15/results.json'),'case_count',freeze['private_checkpoint_cases_per_mode'])
 require(all(sha(Q/k)==v['sha256'] and (Q/k).stat().st_size==v['bytes'] for k,v in freeze['files'].items()),'Packaging/control sources changed');report={'passed':True,'model_go':False,'all_sources_unchanged':True,'tooling_freeze_sha256':sha(Q/'PACKAGING-CONTROLS-TOOLING-FREEZE-v15-r2.json'),'executions':rows,'scope':'Fresh synthetic archive, publication, privacy-profile and private-restoration controls only. Complete model reports, actual controls archive replay, final exact public coverage and actual private checkpoint remain separately required.'};write(out/'results.json',report);print(json.dumps({'passed':True,'stages':len(rows)}))
if __name__=='__main__':main()
