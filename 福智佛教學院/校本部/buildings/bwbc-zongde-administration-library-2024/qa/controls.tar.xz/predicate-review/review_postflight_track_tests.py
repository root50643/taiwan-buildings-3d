"""Extract only actual nested hash helpers; never execute the model audit."""
from pathlib import Path
import argparse,ast,gzip,hashlib,json,sys

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=False)
 source=args.source.read_bytes();tree=ast.parse(source);main_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
 names={'key','track','read','decode_json'};nodes=[n for n in main_node.body if isinstance(n,ast.FunctionDef) and n.name in names]
 helpers=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));rows=[]
 def fresh():
  def require(v,m):
   if not v:raise RuntimeError(m)
  def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
  g={'Path':Path,'json':json,'gzip':gzip,'hashlib':hashlib,'qa':args.out.resolve(),'author':args.out.resolve()/'author','tracked':{},'sha':sha,'require':require}
  exec(compile(helpers,str(args.source),'exec'),g);return g
 for scenario in ['unchanged-repeat','changed-repeat','changed-after-expected-before-read']:
  g=fresh();p=args.out/(scenario+'.json');p.write_text('{"v":1}');original=g['sha'](p);g['track'](p,original)
  if scenario!='unchanged-repeat':p.write_text('{"v":2}')
  rejected=False;error=None
  try:
   if scenario=='changed-after-expected-before-read':g['read'](p)
   else:g['track'](p)
   final_check=all(g['sha'](args.out/logical.split('/',1)[1])==r['sha256'] for logical,r in g['tracked'].items())
  except Exception as exc:rejected=True;error=str(exc);final_check=False
  expected_rejection=scenario!='unchanged-repeat'
  rows.append({'scenario':scenario,'expected_rejection':expected_rejection,'rejected':rejected,'final_inventory_check_passes':final_check,'ok':rejected==expected_rejection,'error':error})
 for method in ['read','decode_json']:
  if method not in [n.name for n in nodes]:continue
  g=fresh();p=args.out/(method+'-read-window.json'+('.gz' if method=='decode_json' else ''))
  before=b'{"v":1}';after=b'{"v":2}'
  if method=='decode_json':before=gzip.compress(before,mtime=0);after=gzip.compress(after,mtime=0)
  p.write_bytes(before);plain_sha=g['sha'];changed=[False]
  def injected_sha(path):
   if Path(path)==p and not changed[0]:p.write_bytes(after);changed[0]=True
   return plain_sha(path)
  g['sha']=injected_sha;rejected=False;error=None
  try:g[method](p)
  except Exception as exc:rejected=True;error=str(exc)
  rows.append({'scenario':method+'-changes-between-bytes-and-track','expected_rejection':True,'rejected':rejected,'ok':rejected,'error':error})
 result={'source_sha256':hashlib.sha256(source).hexdigest(),'optimization_level':sys.flags.optimize,'scope':'Only AST-extracted key/track/read helpers on tiny JSON fixtures; main never runs.','case_count':len(rows),'passed_count':sum(x['ok'] for x in rows),'cases':rows}
 (args.out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return 0 if all(x['ok'] for x in rows) else 1
if __name__=='__main__':raise SystemExit(main())
