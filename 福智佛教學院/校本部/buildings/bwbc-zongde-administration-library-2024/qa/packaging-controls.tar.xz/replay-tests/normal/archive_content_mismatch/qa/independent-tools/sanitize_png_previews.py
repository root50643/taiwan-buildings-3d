# synthetic helper independent-tools/sanitize_png_previews.py
