"""Offline appearance rebuild; install pinned dependencies and Blender 4.3.2."""
from pathlib import Path
import subprocess,sys,json,hashlib
R=Path(__file__).resolve().parent
manifest=json.loads((R/'manifest-source.json').read_text())
for x in manifest['files']:
 p=R/x['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],str(p)
for cmd in [[sys.executable,str(R/'build_appearance.py')],['blender','-b','-t','2','--python-exit-code','1','-P',str(R/'render_appearance.py')],[sys.executable,str(R/'verify_appearance.py')],[sys.executable,str(R/'verify_edit_roundtrip.py')]]:
 subprocess.run(cmd,cwd=R,check=True)
print('Offline appearance rebuild and actual format/material-edit tests passed. No physical print test.')
