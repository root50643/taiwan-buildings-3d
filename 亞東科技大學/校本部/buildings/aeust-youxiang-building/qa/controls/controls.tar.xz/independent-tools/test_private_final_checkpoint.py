"""Synthetic integrity/safe-restore controls for the private final checkpoint."""
from pathlib import Path
import argparse,copy,hashlib,json,os,stat,sys,types,zipfile

def require(v,m):
 if not v:raise RuntimeError(m)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();require(not a.out.exists() and len(os.sched_getaffinity(0))==1,'Fresh output and one CPU required');a.out.mkdir(mode=0o700,parents=True);p=Path(__file__).with_name('package_private_final_v15.py');source=p.read_bytes();m=types.ModuleType('private_checkpoint');m.__file__=str(p);exec(compile(source,str(p),'exec'),m.__dict__);rows=[]
 def case(name,fn,accept,needle=''):
  error='';result=None
  try:result=fn();accepted=True
  except Exception as e:accepted=False;error=str(e)
  passed=accepted is accept and (accept or needle in error);rows.append({'name':name,'expected_accept':accept,'accepted':accepted,'expected_error':needle or None,'observed_error':error or None,'passed':passed});require(passed,'Control failed '+name);return result
 root=a.out/'original';root.mkdir();(root/'sub').mkdir();(root/'empty').mkdir();(root/'one.bin').write_bytes(b'original payload');(root/'sub/two.bin').write_bytes(b'original payload');(root/'negative.pyc').write_bytes(b'original intentional cache fixture');(root/'bad.zip').write_bytes(b'PK\x03\x04intentionally truncated archive');(root/'control.bin').write_bytes(bytes(range(256)));(root/'link').symlink_to('missing-private-fixture-target');out=root/'checkpoint';report=case('exact_complete_checkpoint_and_restore',lambda:m.package(root,out),True);archive=out/report['zip_file'];original=archive.read_bytes();index=json.loads((out/'RESTORE-INDEX.json').read_text());require(report['regular_file_count']==5 and report['unique_blob_count']==4 and report['symlink_descriptor_count']==1,'Positive dedup/fixture/link coverage differs');rows.append({'name':'dedup_preserves_all_paths_and_intentional_bytecode_fixture','passed':True,'expected_accept':True,'accepted':True});require(not (out/'restored/link').exists() and not (out/'restored/link').is_symlink(),'Symlink materialized');rows.append({'name':'symlink_descriptor_only_never_followed_or_materialized','passed':True,'expected_accept':True,'accepted':True})
 def opaque_restore():
  for name in ['negative.pyc','bad.zip','control.bin']:require((out/'restored'/name).read_bytes()==(root/name).read_bytes(),'Opaque fixture changed')
  require((out/'restored/empty').is_dir(),'Empty directory lost')
  for path in [out/'restored',*(out/'restored').rglob('*')]:require(path.stat().st_uid==os.getuid() and stat.S_IMODE(path.stat().st_mode)&0o077==0,'Restore is not owner-only')
 case('opaque_private_payloads_empty_directory_and_owner_only_restore',opaque_restore,True)
 case('existing_checkpoint_rejected',lambda:m.package(root,out),False,'Fresh immediate-child')
 case('existing_restore_rejected',lambda:m.restore(archive,out/'restored',m.sha(original)),False,'Fresh restore')
 case('wrong_zip_hash_rejected',lambda:m.restore(archive,a.out/'wrong-hash-restore','0'*64),False,'ZIP hash differs')
 def rewrite(name,change,extra=False,corrupt=False):
  zpath=a.out/(name+'.zip');idx=copy.deepcopy(index);change(idx)
  with zipfile.ZipFile(archive) as src,zipfile.ZipFile(zpath,'x') as dst:
   for info in src.infolist():
    b=src.read(info.filename)
    if info.filename=='RESTORE-INDEX.json':b=m.encode(idx)
    elif corrupt:b=b'changed original payload'
    dst.writestr(info,b)
   if extra:
    info=zipfile.ZipInfo('unexpected');info.create_system=3;info.external_attr=(stat.S_IFREG|0o644)<<16;dst.writestr(info,b'extra')
  return lambda:m.restore(zpath,a.out/(name+'-restore'),m.sha(zpath.read_bytes()))
 case('mutated_blob_rejected',rewrite('mutated-blob',lambda d:None,corrupt=True),False,'Blob integrity mismatch')
 case('extra_archive_member_rejected',rewrite('extra-member',lambda d:None,extra=True),False,'ZIP member set differs')
 case('parent_path_escape_rejected',rewrite('parent-path',lambda d:d['files'][0].__setitem__('path','../outside')),False,'Invalid restore reference')
 case('absolute_path_rejected',rewrite('absolute-path',lambda d:d['files'][0].__setitem__('path','/outside')),False,'Invalid restore reference')
 case('duplicate_restore_path_rejected',rewrite('duplicate-path',lambda d:d['files'][1].__setitem__('path',d['files'][0]['path'])),False,'Invalid restore reference')
 case('wrong_reference_size_rejected',rewrite('wrong-size',lambda d:next(r for r in d['files'] if r['path']=='one.bin').__setitem__('bytes',len(b'original payload')+1)),False,'Conflicting blob size')
 case('missing_parent_directory_rejected',rewrite('missing-dir',lambda d:d.__setitem__('directories',[])),False,'Missing safe parent directory')
 case('changed_link_descriptor_rejected',rewrite('changed-link',lambda d:d['symlink_descriptors'][0].__setitem__('target_descriptor','changed')),False,'Invalid symlink descriptor')
 case('orphan_empty_directory_rejected',rewrite('orphan-dir',lambda d:d['directories'].append({'path':'missing-parent/empty','source_mode':0o755})),False,'Missing safe parent directory')
 def duplicate_zip_member():
  zpath=a.out/'duplicate-member.zip'
  with zipfile.ZipFile(archive) as src,zipfile.ZipFile(zpath,'x') as dst:
   for info in src.infolist():dst.writestr(info,src.read(info.filename))
   info=src.getinfo('RESTORE-INDEX.json');dst.writestr(info,src.read(info.filename))
  return m.restore(zpath,a.out/'duplicate-member-restore',m.sha(zpath.read_bytes()))
 case('duplicate_zip_member_rejected',duplicate_zip_member,False,'ZIP member set differs')
 def bad_crc():
  zpath=a.out/'bad-crc.zip'
  with zipfile.ZipFile(archive) as src,zipfile.ZipFile(zpath,'x') as dst:
   for info in src.infolist():
    b=src.read(info.filename);info.compress_type=zipfile.ZIP_STORED;dst.writestr(info,b)
  with zipfile.ZipFile(zpath) as z:info=z.getinfo(index['files'][0]['member']);offset=info.header_offset
  raw=bytearray(zpath.read_bytes());start=offset+30+int.from_bytes(raw[offset+26:offset+28],'little')+int.from_bytes(raw[offset+28:offset+30],'little');raw[start]^=1;zpath.write_bytes(raw)
  return m.restore(zpath,a.out/'bad-crc-restore',m.sha(raw))
 case('actual_zip_crc_failure_rejected',bad_crc,False,'ZIP CRC failure')
 def symlink_parent():
  real=a.out/'real-parent';real.mkdir(mode=0o700);alias=a.out/'parent-alias';alias.symlink_to(real.resolve(),target_is_directory=True)
  try:return m.restore(archive,alias/'restored',m.sha(original))
  finally:require(not (real/'restored').exists(),'Restore traversed a parent symlink')
 case('restore_parent_symlink_rejected',symlink_parent,False,'Not a directory')
 def symlink_ancestor():
  real=a.out/'real-ancestor';real.mkdir(mode=0o700);(real/'private').mkdir(mode=0o700);alias=a.out/'ancestor-alias';alias.symlink_to(real.resolve(),target_is_directory=True)
  try:return m.restore(archive,alias/'private/restored',m.sha(original))
  finally:require(not (real/'private/restored').exists(),'Restore traversed an ancestor symlink')
 case('restore_ancestor_symlink_rejected',symlink_ancestor,False,'Not a directory')
 def source_swap(blob_phase):
  base=a.out/('blob-swap' if blob_phase else 'snapshot-swap');base.mkdir();victim=base/'victim.bin';payload=b'unchanged private source';victim.write_bytes(payload);target=a.out/('blob-target' if blob_phase else 'snapshot-target');target.write_bytes(b'outside source');saved=base/'saved-victim';hook='read_regular_path' if blob_phase else 'read_regular_at';original_reader=getattr(m,hook);triggered=[]
  def swapped(fd,name,*args):
   if name!='victim.bin':return original_reader(fd,name,*args)
   triggered.append(True);victim.rename(saved);victim.symlink_to(target.resolve())
   try:return original_reader(fd,name,*args)
   finally:victim.unlink();saved.rename(victim)
  setattr(m,hook,swapped)
  try:return m.package(base,base/'checkpoint')
  finally:
   setattr(m,hook,original_reader);require(triggered and victim.read_bytes()==payload and target.read_bytes()==b'outside source','Swap control did not preserve originals')
 case('snapshot_source_symlink_swap_rejected',lambda:source_swap(False),False,'Source path is not a regular file')
 case('blob_reread_symlink_swap_rejected',lambda:source_swap(True),False,'Source path is not a regular file')
 def source_open_swap():
  base=a.out/'open-swap';base.mkdir();victim=base/'victim.bin';victim.write_bytes(b'unchanged');external=a.out/'open-swap-target';external.write_bytes(b'outside');saved=base/'saved-victim';original_open=m.os.open;triggered=[]
  def swapped(name,flags,*args,**kwargs):
   if name=='victim.bin' and 'dir_fd' in kwargs and not triggered:
    triggered.append(True);victim.rename(saved);victim.symlink_to(external.resolve())
    try:return original_open(name,flags,*args,**kwargs)
    finally:victim.unlink();saved.rename(victim)
   return original_open(name,flags,*args,**kwargs)
  m.os.open=swapped
  try:return m.snapshot(base,None)
  finally:m.os.open=original_open;require(triggered and victim.read_bytes()==b'unchanged' and external.read_bytes()==b'outside','Open-swap control did not preserve originals')
 case('source_lstat_to_open_symlink_swap_rejected',source_open_swap,False,'Too many levels of symbolic links')
 def source_directory_swap():
  base=a.out/'directory-swap';base.mkdir();(base/'sub').mkdir();(base/'sub/source').write_bytes(b'unchanged');external=a.out/'directory-target';external.mkdir();(external/'source').write_bytes(b'outside');saved=base/'saved-sub';original_open=m.os.open;triggered=[]
  def swapped(name,flags,*args,**kwargs):
   if name=='sub' and flags&m.os.O_DIRECTORY and 'dir_fd' in kwargs and not triggered:
    triggered.append(True);(base/'sub').rename(saved);(base/'sub').symlink_to(external.resolve(),target_is_directory=True)
    try:return original_open(name,flags,*args,**kwargs)
    finally:(base/'sub').unlink();saved.rename(base/'sub')
   return original_open(name,flags,*args,**kwargs)
  m.os.open=swapped
  try:return m.snapshot(base,None)
  finally:m.os.open=original_open;require(triggered and (base/'sub/source').read_bytes()==b'unchanged','Directory swap control did not restore original')
 case('snapshot_directory_symlink_swap_rejected',source_directory_swap,False,'Not a directory')
 def archive_path_swap():
  first=a.out/'archive-before-swap.zip';first.write_bytes(original);replacement=a.out/'archive-replacement.zip';replacement_bytes=b'not a ZIP';replacement.write_bytes(replacement_bytes);saved=a.out/'archive-saved.zip';original_restore=m.restore_bytes;triggered=[]
  def swapped(raw,fd,leaf,expected):
   triggered.append(True);first.rename(saved);replacement.rename(first)
   try:return original_restore(raw,fd,leaf,expected)
   finally:first.rename(replacement);saved.rename(first)
  m.restore_bytes=swapped
  try:
   result=m.restore(first,a.out/'immutable-archive-restore',m.sha(original));require(result==index,'Verified archive bytes were replaced');return result
  finally:m.restore_bytes=original_restore;require(triggered and first.read_bytes()==original and replacement.read_bytes()==replacement_bytes,'Archive swap control did not preserve originals')
 case('archive_decode_uses_identical_hash_verified_bytes',archive_path_swap,True)
 def restore_directory_swap():
  external=a.out/'restore-directory-target';external.mkdir(mode=0o700);restoreout=a.out/'restore-directory-swap';original_writer=m.secure_write;triggered=[]
  def swapped(fd,name,data):
   if not name.startswith('sub/'):return original_writer(fd,name,data)
   triggered.append(True);os.rename('sub','saved-sub',src_dir_fd=fd,dst_dir_fd=fd);os.symlink(str(external.resolve()),'sub',dir_fd=fd)
   try:return original_writer(fd,name,data)
   finally:os.unlink('sub',dir_fd=fd);os.rename('saved-sub','sub',src_dir_fd=fd,dst_dir_fd=fd)
  m.secure_write=swapped
  try:return m.restore(archive,restoreout,m.sha(original))
  finally:m.secure_write=original_writer;require(triggered and not list(external.iterdir()),'Restore wrote through swapped directory')
 case('restore_directory_symlink_swap_rejected',restore_directory_swap,False,'Not a directory')
 def restore_readback_swap():
  external=a.out/'restore-readback-target';external.mkdir(mode=0o700);(external/'two.bin').write_bytes(b'original payload');original_reader=m.read_regular_path;triggered=[]
  def swapped(fd,name):
   if name!='sub/two.bin':return original_reader(fd,name)
   triggered.append(True);os.rename('sub','saved-sub',src_dir_fd=fd,dst_dir_fd=fd);os.symlink(str(external.resolve()),'sub',dir_fd=fd)
   try:return original_reader(fd,name)
   finally:os.unlink('sub',dir_fd=fd);os.rename('saved-sub','sub',src_dir_fd=fd,dst_dir_fd=fd)
  m.read_regular_path=swapped
  try:return m.restore(archive,a.out/'restore-readback-swap',m.sha(original))
  finally:m.read_regular_path=original_reader;require(triggered and (external/'two.bin').read_bytes()==b'original payload','Readback swap control did not preserve target')
 case('restore_readback_symlink_swap_rejected',restore_readback_swap,False,'Not a directory')
 def restore_root_swap():
  external=a.out/'restore-root-target';external.mkdir(mode=0o700);restoreout=a.out/'restore-root-swap';saved=a.out/'restore-root-saved';original_writer=m.secure_write;triggered=[]
  def swapped(fd,name,data):
   if not triggered:
    triggered.append(True);restoreout.rename(saved);restoreout.symlink_to(external.resolve(),target_is_directory=True)
   return original_writer(fd,name,data)
  m.secure_write=swapped
  try:return m.restore(archive,restoreout,m.sha(original))
  finally:
   m.secure_write=original_writer
   if triggered:restoreout.unlink();saved.rename(restoreout)
   require(triggered and not list(external.iterdir()),'Restore escaped its original root fd')
 case('restore_root_replacement_rejected_without_following',restore_root_swap,False,'Directory binding changed')
 require(p.read_bytes()==source and archive.read_bytes()==original,'Original tool/archive changed');result={'passed':True,'optimization_level':sys.flags.optimize,'case_count':len(rows),'cases':rows,'source_sha256':m.sha(source),'test_source_sha256':m.sha(Path(__file__).read_bytes()),'all_original_tool_and_baseline_archive_bytes_unchanged':True,'scope':'Synthetic private backup integrity and actual safe-restore controls only. Not model acceptance or permission to publish the private contents.'};(a.out/'results.json').write_bytes(m.encode(result));print(json.dumps({'passed':True,'case_count':len(rows)}))
if __name__=='__main__':main()
