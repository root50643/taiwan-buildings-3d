# synthetic helper verification/dense_original.cpp
