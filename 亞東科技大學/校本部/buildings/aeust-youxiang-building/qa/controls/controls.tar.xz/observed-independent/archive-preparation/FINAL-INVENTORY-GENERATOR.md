# Final controls inventory preparation

Status: **prepared, not executed**. No generator run, scanner run, archive build,
safe extraction, geometry, Blender or control test was performed here. The v2
packager remains frozen at `1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c`.
Final publication remains HOLD until the formal terminal evidence and exact
per-file decisions are supplied. This document grants no model GO.

## Inputs and stages

`generate_final_inventory.py` has two explicit stages. Both require quiescent
source writers and fresh named outputs. It uses fd-relative, no-follow file
reads; leaf opens are nonblocking and must be regular files. Source paths are
hashed twice, with inode/size/time checks, before output. Links are recorded by
target-descriptor hash only. No link is followed or materialized.

1. `roster` inventories every regular file and link descriptor under the declared
   scopes. Every original Blend remains in `files`. `blend_candidates` contains
   the exact per-file decoder worklist. The total is discovered, never fixed at
   16. Individually approved negative fixtures may appear instead in
   `excluded_blend_candidates`, with their original identity and proof retained.
2. The parent's independent batch profiles that worklist in both Python modes.
   The batch's original copies and all raw diagnostics remain privately
   inventoried. Accepted public rows contain classification and field hashes,
   never effective private path strings.
3. `finalize` takes a new complete snapshot after the batch, verifies terminal
   gates and the batch's exact roster/tool/diagnostic bindings, and scans each
   archive candidate with the exact v2 scanner plus the current public helper.
   It emits an identity selection, full private original inventory and exact
   per-file omissions. Unknown malformed payloads, absent proofs, mismatches or
   unresolved dispositions keep `passed=false`, `ready_for_final_assembly=false`
   and exit status 2. No archive is produced.

`final-inventory-plan-TEMPLATE.json` is intentionally inactive. It contains
future hashes and paths that must be replaced after the formal runs. In
particular, confirm the public helper's large-science r2 controls and final
public-suite count/path. The four narrowly bound direct science CSVs are the
public worker's responsibility; generic archive limits are unchanged.

## CLI, for the parent's scheduled execution only

These commands are examples, not a record of execution. Define `Q` as the
independent QA directory and `P="$Q/archive-preparation"`. Preserve the original
template and every reviewed plan revision as separate files; do not rewrite a
plan whose bytes have already been inventoried.

```sh
python -B "$P/generate_final_inventory.py" roster \
  --plan "$P/final-roster-plan-r1.json" \
  --root "independent=$Q" \
  --root "author=$Q/final-v15-r1/frozen" \
  --out "$P/final-inventory-r1"
```

The plan must canonicalize `independent/final-v15-r1/frozen` to `author`.
The current v2 public-proof label `v2-suite` is normalized to
`independent/package-controls-normal-v2`; confirm the runner's final path.
Actual hardlink fixture paths remain separate original regular-file rows.

```sh
taskset -c "$CPU" python -B "$Q/independent-tools/profile_control_blends.py" \
  --roster "$P/final-inventory-r1/blend-candidates-FINAL.json" \
  --source-root "independent=$Q" \
  --source-root "author=$Q/final-v15-r1/frozen" \
  --out "$Q/control-blend-actual-profiles-v15-r1"
```

The parent's source-frozen batch SHA is
`6085726c97cf51d17b0f674dc17641d1cf8d9a9c1fb44f1c5ad8646d0c386335`.
Create a **new** reviewed final plan with exact references to both roster files,
all terminal reports, the actual batch manifest and reviewed decisions. The
generator's `--blend-profiles` input is bound by its actual raw bytes; the plan
binds its candidate roster and decoder/batch source bytes separately.

```sh
python -B "$P/generate_final_inventory.py" finalize \
  --plan "$P/final-selection-plan-r1.json" \
  --root "independent=$Q" \
  --root "author=$Q/final-v15-r1/frozen" \
  --scanner "$P/package_controls_v2.py" \
  --scanner-sha256 1402e983241d78d19969380b45ce79b7cd3936207a4324710a17b094f5ac256c \
  --public-helper "$Q/public-preparation/public_bundle_common_v15.py" \
  --public-helper-sha256 "$FINAL_PUBLIC_HELPER_SHA256" \
  --blend-profiles "$Q/control-blend-actual-profiles-v15-r1/blend-profiles.json" \
  --out "$P/final-inventory-r1"
```

Only the current stage's finite generated metadata names are excluded from its
snapshot, preventing self-hash cycles. Thus finalize inventories the already
completed roster files. Its inventory also accounts for every original version
in the historical baseline and the complete first-stage roster. Missing prior
bytes, including logs or bytecode, are reported as HOLD rather than silently
inheriting the old broad cache/log omission category.

## Reviewed Blend profile exclusion schema

`reviewed_blend_profile_exclusions` is a list of exact JSON-file references.
Each referenced document has `files` rows with:

- `source_relative_path`, integer `bytes`, lowercase `sha256`;
- `approved: true`, `category: "private_control_fixture"`, a specific reason;
- `proof.kind: "unclassified_sdna_negative_control"`;
- exact `proof.generator_source` and `proof.tested_source` references;
- nonempty `proof.result_proofs`, each with exact `reference` and integer
  `optimization_level`.

The result must bind the generator and tested batch SHA, pass overall, and have
one `unclassified_decoder_error_is_not_policy_success` case with the exact
fixture SHA, expected/actual rejection, return code 1, passed true, and the
explicit unclassified-decoder error. Any absent, changed or unapproved evidence
rejects exclusion. The same bytes at another original path need another exact
approved row. Exclusions are privately retained original fixtures, never public
Blend privacy allowances.

## Exact publication and duplicate decisions

The final private inventory retains `files`, `regular_file_count`,
`all_snapshot_paths_accounted: true` and
`source_changes_during_static_read: []`. Every regular row has logical path,
type, bytes and SHA. Final omissions retain the public worker's eight allowed
categories and a specific reason of at least 20 characters. There is no scope,
directory, `.pyc` or private-fixture blanket exemption.

Reviewed duplicate-reproduction omissions additionally require a
`duplicate_proof` with `kind`, exact `raw_inputs`, `generator_source`,
`selection_input`, `archive_index`, `result_proofs` and complete
`member_bindings`. Each result declares `schema: "package_controls_v2_result"`.
Only the controlled current v2 generator is supported. Its exact source,
selection, archive, index and original archive-tool SHA bindings, complete
copies, unchanged/safeextract/rebuild flags and full tracked dependency set are
checked. Every dependency and member is also required as an exact public
selected source. Member rows contain `path`, `source_relative_path`, bytes, SHA
and, for copied inputs, `reported_source_relative_path`. Regular duplicates
also declare `reproduction_member_path`; strict archive duplicates additionally
undergo the original verifier's in-memory all-member check, never extraction.
Unknown historical proof schemas remain HOLD. An unrelated passing report is
insufficient. Unapproved exact-byte duplicate suggestions are separate private
rows and do not grant omission.

The original v2 packager keeps `ARCHIVE-SCOPE.json` inside the archive after its
temporary staging directory is removed. Full duplicate proof therefore needs
that exact member retained by the formally verified safe replay as a separately
hash-bound selected file. This generator does not silently skip it or invent a
replacement. Without that file, duplicate omission stays HOLD, including a
regular-member duplicate that relies on the same complete archive evidence.

## Outputs and assembly handoff

- `private-source-roster-FINAL.json`, `blend-candidates-FINAL.json`
- `private-original-payload-inventory-FINAL.json`
- `controls-selection-FINAL.json`
- `private-omissions-FINAL.json`
- `private-inventory-findings-FINAL.json`
- `private-duplicate-candidates-FINAL.json`
- `malformed-fixture-allowlist-FINAL.json`
- `negative-archive-allowlist-FINAL.json`
- `privacy-allowlist-FINAL.json`
- `final-inventory-generation-result.json`

The public selected sidecar destinations are exactly
`malformed-fixture-allowlist.json`, `negative-archive-allowlist.json` and
`privacy-allowlist.json`. They are new clean metadata with original input
provenance; no old source/result bytes are rewritten. The final selection itself
stays an external packaging input to avoid a self-reference cycle.

Update the public contract's `control_source_inventory.source_relative_path`
to the actual fresh subdirectory, e.g.
`independent/archive-preparation/final-inventory-r1/private-original-payload-inventory-FINAL.json`.
The exact 181-path direct contract remains authoritative; its nine future
public-controls outputs are explicitly deferred, never represented as existing
raw payload. Current observed outputs map below `observed-independent/`; the
original `tooling/`, `independent-tools/`, `synthetic-recorded-ray/` replay roots
remain usable. Fixed fresh output roots cannot preexist in the archive.

## Suggested pure controls, not prepared or executed here

If the parent schedules generator controls, cover: exact canonical overlap;
source mutation; ancestor/leaf symlink and FIFO rejection; stage-specific
self-metadata exclusion; missing historical bytecode; accepted exclusion and
mutated/missing source/result/case exclusion proofs; full profile candidate
coverage and both-mode diagnostics; unknown malformed HOLD; private markers;
unrelated passing duplicate proof; unselected generator/index/verifier/builder;
all-member duplicate mismatch; direct/archive overlap; and derived-sidecar
dependency closure. These are proposed cases, not claimed runtime evidence.
